"""Mechanical packet presentation and exact-duplicate expansion only."""
import argparse,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
FIELDS=('sample_id','answerer_answer_mode','answerer_judgment','answerer_stance','limit_owners','other_answer','character_description','note')
def rows(p):return [json.loads(l) for l in p.read_text().splitlines() if l.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def packet():
 m=json.loads((ROOT/'packet_manifest.json').read_text())
 for name,digest in m['input_sha256'].items():assert sha(ROOT/name)==digest,name
 return rows(ROOT/'unique_blind.jsonl'),m

def validate(c):
 assert set(c)=={'case_index',*FIELDS[1:]},'Every manual row must explicitly provide case_index and seven rubric fields'
 assert type(c['case_index']) is int and c['case_index']>=0
 assert c['answerer_answer_mode'] in {'direct','reported','both','none'}
 assert c['answerer_judgment'] in {'support','reject','withhold','mixed','none'}
 assert c['answerer_stance'] in {'decisive','tentative','mixed','none'}
 assert isinstance(c['limit_owners'],list) and len(c['limit_owners'])==len(set(c['limit_owners'])) and set(c['limit_owners'])<={'answerer_direct','answerer_reported','other','unclear'}
 assert type(c['other_answer']) is bool and type(c['character_description']) is bool
 assert isinstance(c['note'],str) and c['note'].strip()
 assert (c['answerer_answer_mode']=='none')==(c['answerer_judgment']=='none')==(c['answerer_stance']=='none')
 assert (c['answerer_judgment']=='mixed')==(c['answerer_stance']=='mixed')
 assert c['answerer_judgment']!='withhold' or c['answerer_stance']=='tentative'

def main():
 p=argparse.ArgumentParser();s=p.add_subparsers(dest='command',required=True)
 show=s.add_parser('show');show.add_argument('start',type=int);show.add_argument('count',type=int)
 s.add_parser('progress');s.add_parser('finalize');a=p.parse_args()
 unique,m=packet()
 if a.command=='show':
  for r in unique[a.start:a.start+a.count]:print(json.dumps(r,ensure_ascii=False))
  return
 codes={}
 for f in sorted((ROOT/'manual_batches').glob('*.jsonl')):
  for c in rows(f):
   validate(c);assert c['case_index'] not in codes,'Duplicate manual index'
   codes[c['case_index']]=c
 assert set(codes)<=set(range(len(unique)))
 if a.command=='progress':
  missing=[i for i in range(len(unique)) if i not in codes]
  print(json.dumps({'annotated':len(codes),'unique':len(unique),'first_missing':missing[:20]}));return
 assert set(codes)==set(range(len(unique))),'Manual labels incomplete'
 mapping=json.loads((ROOT/'duplicate_map.json').read_text())
 blind=rows(ROOT/'validation_blind.jsonl')
 labels=[]
 for r in blind:
  c=codes[mapping[r['sample_id']]]
  labels.append({'sample_id':r['sample_id'],**{k:c[k] for k in FIELDS[1:]}})
 assert len(labels)==m['records']
 assert (ROOT/'observations.md').is_file(),'Write substantive independent observations before finalizing'
 assert len((ROOT/'observations.md').read_text().strip())>=40
 with (ROOT/'labels.jsonl').open('x') as f:
  for label in labels:f.write(json.dumps(label,ensure_ascii=False)+'\n')
 with (ROOT/'annotation_receipt.json').open('x') as f:json.dump({'status':'MANUAL_CODES_MATERIALIZED','records':len(labels),'unique_triples':len(unique),'input_manifest_sha256':sha(ROOT/'packet_manifest.json'),'labels_sha256':sha(ROOT/'labels.jsonl'),'notes_sha256':sha(ROOT/'observations.md'),'manual_batch_sha256':{p.name:sha(p) for p in sorted((ROOT/'manual_batches').glob('*.jsonl'))},'semantic_validity':'Not established by schema checks'},f,indent=2)
 print(json.dumps({'records':len(labels),'unique_triples':len(unique),'labels_sha256':sha(ROOT/'labels.jsonl')}))
if __name__=='__main__':main()
