#!/usr/bin/env python3
"""Fetch only the six pinned, public Hugging Face model files and verify bytes."""
from __future__ import annotations

import concurrent.futures
import datetime as dt
import hashlib
import json
from pathlib import Path
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = json.loads((ROOT / "setup" / "source_model_manifest.json").read_text())
MODEL = ROOT / "model"
MODEL.mkdir(exist_ok=True)
assert MANIFEST["model_id"] == "HuggingFaceTB/SmolLM2-360M-Instruct"
assert MANIFEST["revision"] == "a10cc1512eabd3dde888204e902eca88bddb4951"
assert len(MANIFEST["files"]) == 6


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def matches(path: Path, item: dict) -> bool:
    return (path.is_file() and path.stat().st_size == item["size_bytes"]
            and digest(path) == item["sha256"])


def download(item: dict) -> dict:
    name = item["name"]
    assert Path(name).name == name
    final = MODEL / name
    url = (f"https://huggingface.co/{MANIFEST['model_id']}/resolve/"
           f"{MANIFEST['revision']}/{name}")
    if matches(final, item):
        print(f"Already verified: {name}", flush=True)
    else:
        partial = MODEL / (name + ".part")
        for attempt in range(1, 4):
            try:
                request = urllib.request.Request(url, headers={"User-Agent": "persona-shrinkage-repro/1.0"})
                hasher = hashlib.sha256()
                size = 0
                with urllib.request.urlopen(request, timeout=60) as response, partial.open("wb") as output:
                    for chunk in iter(lambda: response.read(1024 * 1024), b""):
                        output.write(chunk)
                        hasher.update(chunk)
                        size += len(chunk)
                actual = hasher.hexdigest()
                if size != item["size_bytes"] or actual != item["sha256"]:
                    raise ValueError(f"Integrity mismatch for {name}: bytes={size}, sha256={actual}")
                partial.replace(final)
                print(f"Downloaded and verified: {name} ({size} bytes)", flush=True)
                break
            except Exception as error:
                partial.unlink(missing_ok=True)
                # Avoid logging signed redirect URLs or unrelated environment details.
                detail = {"file": name, "attempt": attempt, "error_type": type(error).__name__}
                if isinstance(error, urllib.error.HTTPError):
                    detail["http_status"] = error.code
                print(json.dumps(detail), flush=True)
                if attempt == 3:
                    raise RuntimeError(f"Public model download failed for {name}: {type(error).__name__}") from None
                time.sleep(attempt * 2)
    return {"name": name, "size_bytes": final.stat().st_size, "sha256": digest(final),
            "expected_size_bytes": item["size_bytes"], "expected_sha256": item["sha256"],
            "verified": True, "source_url": url}


started = dt.datetime.now(dt.timezone.utc).isoformat()
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    records = list(pool.map(download, MANIFEST["files"]))
expected = {item["name"] for item in MANIFEST["files"]}
actual = {path.name for path in MODEL.iterdir()}
if actual != expected:
    raise SystemExit(f"Model directory file-set mismatch: {sorted(actual ^ expected)}")
report = {"model_id": MANIFEST["model_id"], "revision": MANIFEST["revision"],
          "started_utc": started, "verified_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
          "all_verified": True, "exact_file_set": True, "files": records}
(ROOT / "setup" / "model_integrity.json").write_text(json.dumps(report, indent=2) + "\n")
with (ROOT / "setup" / "commands.jsonl").open("a") as commands:
    commands.write(json.dumps({"command": [str(ROOT / ".venv" / "bin" / "python"), str(Path(__file__).resolve())],
                               "result": "six exact public model files verified", "started_utc": started}) + "\n")
print("All six model files match the frozen manifest exactly.", flush=True)

