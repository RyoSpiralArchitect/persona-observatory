#!/usr/bin/env python3
"""Record exact installed versions without loading or running the model."""
from __future__ import annotations

import datetime as dt
import importlib.metadata as md
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
expected = json.loads((ROOT / "setup" / "source_environment.json").read_text())
actual = {}
for name in expected["packages"]:
    try:
        actual[name] = md.version(name)
    except md.PackageNotFoundError:
        actual[name] = None
mismatches = {name: {"expected": version, "actual": actual[name]}
              for name, version in expected["packages"].items() if actual[name] != version}
record = {"verified_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
          "python": sys.version, "executable": sys.executable, "prefix": sys.prefix,
          "platform": platform.platform(), "packages": actual,
          "expected_packages": expected["packages"], "mismatches": mismatches,
          "all_exact_versions": not mismatches,
          "device": expected["device"], "threads": expected["threads"],
          "model_forward_passes_run": False}
if not mismatches:
    import torch
    import transformers
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from transformers.models.llama.modeling_llama import LlamaForCausalLM
    assert torch.version.cuda is None, "Expected a CPU-only PyTorch build"
    torch.set_num_threads(expected["threads"])
    record["torch_import"] = {"version": torch.__version__, "cuda_build": torch.version.cuda,
                              "num_threads": torch.get_num_threads()}
    record["transformers_import"] = {"version": transformers.__version__,
                                      "auto_model_import_ok": AutoModelForCausalLM is not None,
                                      "auto_tokenizer_import_ok": AutoTokenizer is not None,
                                      "llama_model_class_import_ok": LlamaForCausalLM is not None}
    with (ROOT / "setup" / "pip_freeze.txt").open("w") as output:
        subprocess.run([sys.executable, "-m", "pip", "freeze", "--all"], stdout=output, check=True)
    local_packages = subprocess.run([sys.executable, "-m", "pip", "list", "--local", "--format=json"],
                                    capture_output=True, text=True, check=True)
    (ROOT / "setup" / "venv_local_packages.json").write_text(local_packages.stdout)
    dependency_check = subprocess.run([sys.executable, "-m", "pip", "check"],
                                      capture_output=True, text=True, check=False)
    (ROOT / "logs" / "setup_pip_check.log").write_text(dependency_check.stdout + dependency_check.stderr)
    record["dependency_check"] = {"returncode": dependency_check.returncode,
                                   "output": dependency_check.stdout + dependency_check.stderr}
(ROOT / "setup" / "runtime_environment.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
if mismatches:
    raise SystemExit(1)
