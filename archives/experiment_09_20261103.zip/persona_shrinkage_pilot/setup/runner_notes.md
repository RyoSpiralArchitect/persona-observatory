# Experiment 9 runner implementation and handoff

The runner is implemented in `../run_experiment.py`; fixed design and seed
functions are in `../experiment_config.py`. This handoff did not run `prepare`,
`lock`, `generate`, a tokenizer preflight, model loading, or any model forward pass.

## Inherited bytes and validation semantics

`../runtime.py` is a byte-identical copy of the immutable Experiment 8 runtime:
SHA-256 `d164d92a51dfa436a59f330dc91e9977ce6f8b583e7271c0967cb790d37901f1`.
The runtime retains CPU float32, eager attention, four Torch threads, one interop
thread, 96 tokens, temperature 0.8, top-p 0.95, and per-sequence CPU generators.
The runner retains batch size eight and two-message fresh chats.

`../rubric.md` is byte-identical to Experiment 8:
SHA-256 `7a28b5f7101c3e9de0367c064bec34f60154b7e7a4c9934c4685eff381d601a6`.
`../validate_observation.py` differs from v8 only in its target-only stage choice,
target count 288, and `persona-shrinkage-observation-v9` schema string. All label
enums, field checks, semantic consistency checks, duplicate-triple rules, and
observation-lock fields are unchanged.

`../model_manifest.json`, `../expected_model_manifest.json`, and
`../environment.json` copy the restored v8 specification. Model integrity uses
the exact six named files and their byte counts/checksums; unused synchronization
temporary names outside that named set are not treated as scientific input.

## CLI and ordering

From the experiment directory:

```bash
.venv/bin/python run_experiment.py prepare
.venv/bin/python audit_shrinkage.py design
.venv/bin/python run_experiment.py lock
.venv/bin/python predict.py freeze
.venv/bin/python audit_shrinkage.py forecasts
.venv/bin/python run_experiment.py generate
```

The audit command interface is owned by the independent auditor; check its CLI
help before using the illustrative audit commands above. The runner also offers
read-only `verify-design`, `verify-forecast-boundary`, and `verify-target` commands.
There is no generation resume, retry, replacement, or separate blind re-export
command.

`prepare` is tokenizer-only. It verifies the nine exact package versions, all
six model hashes, byte-identical runtime/rubric, development-derived hashes, and
the source ZIP hash. It builds 144 contexts and 288 jobs in setting-major, bank,
replicate 0/1 order. It checks the exact chat-template tokenization and old/new
question and seed disjointness. It exclusively creates the plan, plan metadata,
and preflight. It does not run a forward pass or choose forecast parameters.

`lock` requires the independently written `audits/design_prelock.json` with
`status=ALL_MATCH`, no failures, positive integer `assertions`, `audited_utc`, and
hashes of the complete 29-file prelock input set. That report must not reference
the future design lock. The exclusive design lock covers all 30 paths listed in
SCHEMA.md, including the prelock report. No source file is optional.

`generate` checks every design/forecast input and output hash, all 4032 forecast
keys and probabilities, and `audits/forecast.json` with both current lock hashes,
complete input/output hash coverage, and passing status. It checks UTC ordering
of plan, design lock, forecast lock, and independent forecast audit. It rebuilds
the target plan with the local tokenizer and requires exact equality before
starting the attempt.

## One preserved attempt

The exclusive `metadata/target_attempt.json` is written and fsynced before model
loading. Its schema is `persona-shrinkage-target-attempt-v9`; it includes the
creation time, both lock identities/times, forecast-audit identity/time, target
plan hash, model-manifest hash, whole frozen source mapping, and absence proof.

The source snapshot in `source_snapshots/target/` copies every design input,
design lock, all eight forecast outputs, forecast lock, and independent forecast
audit. `SNAPSHOT_MANIFEST.json` contains the source-name-to-SHA-256 mapping.

`data/target_generations.jsonl` is exclusively created once. Batches are appended
and fsynced, preserving all plan fields and all outputs, including length stops.
`metadata/target_events.jsonl` records append-only attempt, snapshot, model-loaded,
batch-completed, completed, or failure events.

On completion the runner exclusively creates `metadata/target.json` with schema
`persona-shrinkage-pilot-v9`, all chronology and identity hashes, runtime metadata,
exact counts, token-stop counts, and output checksum. On an exception it preserves
all attempted artifacts and creates `metadata/target_failure.json`; subsequent
generation calls refuse any existing attempt, output, snapshot, observer export,
or target result. A failure cannot be silently resumed or replaced.

## Blind exports

Each observer receives 288 validation records containing exactly `sample_id`,
`requested_answerer`, `question`, `completion`, and `stop_reason`, plus an empty
discovery file and the byte-identical rubric. Records are ordered by SHA-256 of
`persona-shrinkage-v9|blind|target|{observer}|{sample_id}`, giving separate observer
shuffle keys. Export hashes are recorded in `observer_exports/target.json`.

## Checks performed during implementation

All four Python files passed AST syntax parsing. The real study-configuration
constants and six unchanged settings passed invariant checks. An invented bank
of 24 identifiers (`SYNTHETIC_ONLY_Q00` through `SYNTHETIC_ONLY_Q23`) produced 48
distinct 63-bit streams and 288 distinct 12-hex sample IDs. Every seed and ID was
checked against a separately expressed SHA-256 calculation. Stream pairing
across six settings was checked, and invalid replicate values were rejected.

Runtime/rubric copies were compared byte-for-byte, and the validator was compared
with the exact expected three substitutions from v8. These checks did not use
new target outputs, actual-development parameter selection, or model inference.

This file is setup documentation rather than a scientific source dependency.
The final archive should exclude `.venv/`, `model/`, and
`setup/unexpected_download_temporaries/`.
