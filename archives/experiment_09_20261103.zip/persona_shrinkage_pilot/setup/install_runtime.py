#!/usr/bin/env python3
"""Install the exact v8 public CPU package versions in the experiment venv."""
from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_PYTHON = ROOT / ".venv" / "bin" / "python"
if Path(sys.prefix).resolve() != (ROOT / ".venv").resolve():
    raise SystemExit(f"Run this script with {EXPECTED_PYTHON}")

commands = [
    [str(EXPECTED_PYTHON), "-m", "pip", "--isolated", "install",
     "--no-input", "--disable-pip-version-check", "--no-cache-dir",
     "--progress-bar", "off", "--index-url", "https://download.pytorch.org/whl/cpu",
     "torch==2.15.0+cpu"],
    [str(EXPECTED_PYTHON), "-m", "pip", "--isolated", "install",
     "--no-input", "--disable-pip-version-check", "--no-cache-dir",
     "--progress-bar", "off", "--index-url", "https://pypi.org/simple",
     "transformers==4.57.6", "huggingface_hub==0.36.2", "tokenizers==0.22.2",
     "safetensors==0.8.0", "numpy==2.3.5", "pandas==2.2.3",
     "scipy==1.17.0", "matplotlib==3.10.8"],
]

for number, command in enumerate(commands, 1):
    log_path = ROOT / "logs" / f"setup_pip_{number}.log"
    start = dt.datetime.now(dt.timezone.utc).isoformat()
    print(f"Installing exact package group {number}; log: {log_path.name}", flush=True)
    with log_path.open("w") as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=False)
    with (ROOT / "setup" / "commands.jsonl").open("a") as records:
        records.write(json.dumps({"started_utc": start, "command": command,
                                  "returncode": result.returncode,
                                  "log": str(log_path.relative_to(ROOT))}) + "\n")
    if result.returncode:
        print("\n".join(log_path.read_text().splitlines()[-25:]))
        raise SystemExit(result.returncode)
    print(f"Exact package group {number} installed successfully.", flush=True)

