# Exact CPU runtime and model restoration

This directory records the restoration of the Experiment 8 software and model
specification for the separate Experiment 9 workspace. The source specification
is copied from the immutable `persona_topic_budget_pilot/environment.json`,
`requirements.txt`, and `model_manifest.json`. No files in that source tree are
edited by this setup.

## Runtime

The isolated Python environment is `../.venv`. It was created with Python
3.12.14 and `--system-site-packages` so the already installed, matching scientific
packages can be reused. Installation targets this virtual environment only.

Expected package versions are recorded in `source_environment.json` and
`requirements.txt`. PyTorch is installed from the official CPU wheel index at
`https://download.pytorch.org/whl/cpu`; the remaining packages are installed from
`https://pypi.org/simple`. Exact versions are mandatory. The installation scripts
fail if a requested version is unavailable.

From the experiment root, the reproduction commands are:

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -m venv --system-site-packages .venv
.venv/bin/python setup/install_runtime.py
.venv/bin/python setup/download_model.py
.venv/bin/python setup/verify_environment.py
```

Network access is required only for the two download scripts. The sandboxed
network was initially blocked; the official downloads ran through the approved
network-enabled execution mechanism.

`base_environment.json` records the initial Python and relevant package
versions. `runtime_environment.json` records the final versions, CPU build,
thread setting, and package/class import checks. `pip_freeze.txt` records every
package visible to the virtual environment, including inherited packages;
`venv_local_packages.json` records packages installed locally in the virtual
environment. `commands.jsonl` records the executed installation/download commands
and results. The pip output is retained in `../logs/setup_pip_*.log`.

## Model

The model is `HuggingFaceTB/SmolLM2-360M-Instruct` at revision
`a10cc1512eabd3dde888204e902eca88bddb4951`. `source_model_manifest.json` lists the
exact six permitted files, their byte counts, and SHA-256 checksums.

`download_model.py` fetches those files from the official Hugging Face revision
without reading authentication credentials. It streams each download to a
temporary file, verifies its size and SHA-256 checksum, and moves it to `../model`
only after successful verification. Existing files are reused only if their
size and checksum match. The final model directory must contain exactly the six
manifest entries. `model_integrity.json` records the actual checksums, byte
counts, official source URLs, revision, and verification times.

During this restoration, five unused partial-size files with synchronization-style
temporary names appeared beside the downloaded model after the download had
finished. A single metadata check found no visible open-file process. Those
temporary copies were preserved by atomic rename in
`unexpected_download_temporaries/`, with names, sizes, inodes, and the reason
recorded in `unexpected_download_temporaries.json`. Their origin is uncertain;
tool-side workspace synchronization is only a hypothesis. The six intended files
were then fully reverified, and the directory contained exactly those six files
at verification time. That inventory describes one instant and does not guarantee
that synchronization will not introduce more unused temporary files later.
Scientific integrity depends on the six named files matching their frozen byte
counts and SHA-256 checksums. Exclude both `../model/` and the preserved temporary
folder from the final report archive.

## Scope of verification

Setup verification checks installed package versions, imports the CPU PyTorch
and Transformers classes, and runs the package dependency consistency check.
It does not instantiate the model, perform any model forward pass, generate any
text, select test prompts, or read experimental results. The experiment should
use `../.venv/bin/python`, load `../model` with `local_files_only=True`, and apply
the CPU/thread settings in the frozen environment specification.
