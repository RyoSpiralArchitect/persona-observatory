# Independent implementation audit — Experiment 9

The auditor is implemented separately from the predictor and runner. It imports
neither their functions nor experiment_config or the observation validator.
Constants come from the written protocol and are checked against configuration.
It independently expresses factorized shrinkage as a mixture of empirical
proportions, while the predictor uses count and prior masses. Both must yield
the same probabilities within an absolute/relative numerical tolerance of 2e-11.
The scientific selection/sign tie tolerance remains the separate fixed 1e-12.

The audit checks internal consistency of these files and their local timestamps.
It is not a public preregistration, an external timestamp authority, a semantic
verification of every observer judgment, or an independent model replication.

## Stage commands and exclusive reports

Run with the verified Python environment:

    .venv/bin/python audit_shrinkage.py synthetic
    .venv/bin/python audit_shrinkage.py design
    .venv/bin/python audit_shrinkage.py forecasts
    .venv/bin/python audit_shrinkage.py final

The equivalent option form is --stage STAGE. Default successful reports are
setup/audit_synthetic_checks.json, audits/design_prelock.json,
audits/forecast.json, and audits/final.json, respectively. Reports are never
overwritten. A failure with a default path is retained with a timestamped FAILED
suffix so it cannot masquerade as the passing gate. An explicit --output can
write a distinct audit report within audits/ or setup/.

Every report contains status, assertion and failure counts, readable failures,
audited_utc, input hashes, stages covered, and concrete inventory facts. Design
input_hashes is exactly the 29 required files preceding the design lock; model
file hashes additionally checked are stored in additional_verified_hashes.
Forecast input_hashes includes every design and forecast artifact, and its report
records both design_lock_sha256 and forecast_lock_sha256.

## Invented-count checks

Synthetic checks read no development outcomes, do no actual CV selection and
perform no model inference. They cover unequal direct/composition strengths,
the diagonal H=F identity at every grid strength, the infinity/global limit,
empty cells, cells with zero direct answers, positivity, normalization, and
the exact per-outcome NLL decomposition. An intentionally mismatched
conditional prior mass is shown to break the flat-model identity. Equal-score
candidate fixtures verify the tie rule favors the global vector.

## Design stage, before actual tuning

1. Verify the exact v8 ZIP identity, CRC, all 174 internal manifest entries and
   its complete membership. Verify all four original annotation locks.
2. Independently select support seeds 2026110383/384 and all former targets.
   Compare all 336 complete original output objects and both sets of labels to
   their derived copies. Verify sample provenance, 28 question blocks, all
   seven folds, every local cell and exclusions. Old test outputs are explicitly
   development data here.
3. Check all 24 new question IDs, strata, topic indices, authoring word budget
   and exact topic/text disjointness against all 36 old questions. Semantic
   scenario review is recorded separately in QUESTION_BANK_REVIEW.md and
   DEVELOPMENT_REVIEW.md. Shared templates and longer new evidence paragraphs
   remain a distributional limitation, not evidence of broad semantic transfer.
4. Verify unchanged six instruction settings, exact runtime/rubric bytes,
   all six pinned model file hashes, installed package versions and frozen
   sampling configuration.
5. Reconstruct each new seed and sample ID independently. Tokenizer-only
   reconstruction verifies all 288 full prompts, message lists, token IDs,
   metadata, ordering, 144 contexts and 48 paired streams. No subject weights
   are loaded and no forward pass is used by the audit.
6. Parse all core Python files and hash every required design artifact. Verify
   no subject target attempt, output, target labels or actual fitted forecast
   exists. The audit itself is included in the subsequent design lock.

## Forecast stage, before any target attempt

Recheck the source, development, plan and design lock. Independently recompute
all seven question-blocked folds, both observers, two pooling structures and
16 rho pairs: 448 candidate/fold/observer score rows. Recompute every candidate
summary and selection with the declared Brier objective and deterministic tie
rule, retaining all global or diagonal coincidences.

Check all final and fold raw histograms and contributing sample IDs, every
component of the 48 compact profiles, effective empirical weights and prior
masses, the paired-wording Hswap donor, pooled strict-E propensity and all
4,032 target forecast vectors. Recompute diagonal/global identities on all
actual count bundles. Candidate-nesting inequalities are checked as algebraic
selection facts, not reported as unseen-target improvement. Check every
forecast artifact hash, ordering and target absence before the runner gate.

## Final stage, after both observation locks and scoring

Recompute the complete forecast audit again from old raw labels. Verify the
single immutable target attempt marker, exact source snapshot membership and
bytes, prediction/audit boundaries, 36 appended batches and chronological
events. Compare every field of each output to the frozen plan. Decode every
completion from its generated tokens, verify EOS and length stopping, and
retain all 288 outputs.

Reconstruct both independently shuffled blind exports from full outputs, check
their restricted field sets, original rubric hashes, empty discovery inputs,
complete eight-field labels, within-branch exact-duplicate consistency and both
annotation locks. The audit checks schema and provenance; semantic agreement
is measured rather than imposed through adjudication.

Recompute all 4,608 wide score rows, 19,008 scalar losses, and 19,584 paired
differences independently. The seven core algorithms receive categorical and
directness Brier/NLL; only G/H receive strict-E Brier/NLL; E0 receives strict-E
Brier alone. Check per-output and aggregate weighted NLL decomposition.
Reconstruct every A/B mean by paired target, all 24-question, six-setting,
four-stratum and three-family blocks, block sign counts, outcome frequencies,
agreement/confusion matrices, all disagreements and the two co-primary criteria.
Verify every CSV mirror against its independently checked canonical JSON and
the final scoring input/output lock.

## Scope of a pass

ALL_MATCH means these specified numeric, provenance and ordering checks passed.
It does not certify personality, identify a unique internal state, recover a
hidden reasoning path, establish subjective agency, validate generalization
outside this authored benchmark or make the two same-model observers independent.
