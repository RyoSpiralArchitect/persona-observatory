# Prospective Experiment9 question-bank review

## Scope and provenance

All 24 scenarios were newly authored as fictional, harmless everyday or technical situations. No external data or model API calls were used. The only prior experiment content read was `persona_topic_budget_pilot/question_bank.json`, containing 36 scenarios. No completions, annotation files, response labels, or scores were inspected. No applicable `AGENTS.md` was found on the target directory's ancestor path.

The bank preserves the v8 seven-field schema. Every record has `phase: "target"`; IDs are `N01` through `N24`; `topic_index` runs from 0 through 5 within each stratum. The strata describe evidence constructions and are not correctness labels or model-response annotations. Question content consists only of an evidence paragraph and a grammatical claim phrase. Each claim was read in the frame: “What can be concluded about whether [claim] from the stated evidence?”

## Counts and structural checks

| Evidence stratum | IDs | Count |
|---|---|---:|
| limited | N01–N06 | 6 |
| confounded | N07–N12 | 6 |
| supportive | N13–N18 | 6 |
| contradictory | N19–N24 | 6 |
| **Total** | **N01–N24** | **24** |

Evidence paragraphs contain 47–60 whitespace-separated words. All records have exactly the expected fields, unique sequential IDs, unique snake_case topics, the requested stratum order, and the requested within-stratum indices.

## Topic and scenario disjointness

The 24 new topic identifiers have an empty intersection with all 36 v8 topic identifiers. A manual reading also checked the objects, interventions, outcomes, and situations against every v8 scenario; none repeats a prior topic or scenario. The new bank covers transcription, game saving, photographic cropping, erasing, rule lookup, rug cleaning, online bookings, borrowing reminders, planter rotation, printer queues, bird feeding, crosswords, zipper operation, electronic-scale adjustment, ice release, door mats, kite-line winding, text export, cable storage, painting, webpage readiness, sand molds, luggage wheels, and leaf raking. These are distinct topics within the new bank; shared experimental structures are intentional features of the evidence archetypes.

## Item-by-item coherence review

Every item below was read in full, including its assembled question. Limited items contain small or unrepresentative observations without an explicit concurrent intervention. Confounded items pair an observed improvement with an unseparated alternative change. Supportive and contradictory items use controlled or repeated comparisons and claims bounded to their stated settings. Contradictory items state positive improvement claims and measure the same outcome in the opposing direction.

| ID | Topic | Review |
|---|---|---|
| N01 | `automatic_transcription` | One slow speaker in a quiet recording; the claim spans ordinary group conversations. |
| N02 | `puzzle_progress_sync` | One reopen on one continuously connected tablet; the claim spans device and connection changes. |
| N03 | `photo_cropper` | One centered portrait; the claim spans varied subjects, positions, and photographs. |
| N04 | `pencil_eraser` | One light mark on one paper type; the claim spans ordinary marks and different papers. |
| N05 | `game_rule_index` | One knowledgeable player and one setup lookup; the claim concerns new players during play. |
| N06 | `rug_crumb_brush` | One small crumb-cleaning demonstration; the claim spans debris types, rugs, and ordinary use. |
| N07 | `booking_progress_bar` | Completion share increased while both the visible progress bar and form requirements changed. |
| N08 | `library_due_reminders` | Overdue loans declined while reminders and the allowed borrowing period changed together. |
| N09 | `planter_rotation` | Seedling growth increased while rotation and window brightness changed together. |
| N10 | `print_queue_setting` | A standard batch became quicker while queue configuration and network connection changed together. |
| N11 | `feeder_perch` | Feeder visits rose while perch width and available seed changed together. |
| N12 | `crossword_type_size` | Reported completion rose while type size and crossword difficulty changed together. |
| N13 | `zipper_pull_tab` | Paired case-opening comparisons control contents and opening length; replication matches the bounded time claim. |
| N14 | `scale_zero_adjustment` | Toggling one adjustment on the same scale and known weights isolates the measured error change; paired comparisons and matching scales support the bounded claim. |
| N15 | `ice_mold_bottom` | Matched mold comparisons control water, freezing, and position allocation; measured release force matches the bounded claim. |
| N16 | `doormat_ridges` | Material, sole loading, and pressing procedure are fixed; replicated soil removal matches the bounded claim. |
| N17 | `kite_reel_grip` | Paired winding attempts control line length and resistance; repeat volunteers address the bounded winding-time claim. |
| N18 | `accent_text_export` | Both settings process the same documents; direct comparison with the originals matches the bounded letter-preservation claim. |
| N19 | `cable_comb` | Repeated matched storage routines yield longer separation times for the comb; the positive claim uses the same endpoint and scope. |
| N20 | `paintbrush_reservoir` | Equal paint and water loads, paper, and movement produce shorter lines for the reservoir design; the positive claim uses line length. |
| N21 | `webpage_animation` | Toggling one animation under fixed page and network conditions produces later input readiness; the positive claim uses readiness time. |
| N22 | `sandcastle_mold_vents` | Matched shape, sand, and packing produce greater release loss for the vents; the positive claim uses the same loss measure. |
| N23 | `suitcase_wheel_size` | The same loaded suitcase and track require greater force with larger wheels; the positive claim retains those test conditions. |
| N24 | `rake_tine_spacing` | Tine spacing is the only rake difference; fixed passes collect fewer leaves with wider spacing, using the same endpoint as the positive claim. |

## Wording review

All scenarios use English and familiar descriptions. None contains a persona, an instruction for model behavior, an answer, or a response-correctness label. The wording can be presented under neutral, cautious, or confident response instructions without changing the scenario. The bank contains no actual medical, legal, or financial guidance. All claim scopes and measured outcomes were checked for alignment; no external facts are required to interpret the evidence.

This review documents authorship and checks only. Freezing and final prospective use remain with the coordinating workflow.
