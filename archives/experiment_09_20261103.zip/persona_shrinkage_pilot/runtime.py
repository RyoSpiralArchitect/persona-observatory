"""Audited inference functions reused unchanged from experiment 2."""
import os
from experiment_config import ROOT, MAX_NEW_TOKENS, TEMPERATURE, TOP_P
os.environ.setdefault("HF_HOME", str(ROOT / ".cache" / "huggingface"))
os.environ.setdefault("HF_HUB_DISABLE_IMPLICIT_TOKEN", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

def load_model():
    torch.set_num_threads(4)
    torch.set_num_interop_threads(1)
    tok = AutoTokenizer.from_pretrained(ROOT / "model", local_files_only=True,
                                        trust_remote_code=False)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        ROOT / "model", local_files_only=True, trust_remote_code=False,
        dtype=torch.float32, attn_implementation="eager"
    ).eval()
    assert model.config.model_type == "llama"
    assert len(model.model.layers) == model.config.num_hidden_layers
    assert next(model.parameters()).dtype == torch.float32
    return tok, model


def eos_ids(model, tok):
    value = model.generation_config.eos_token_id
    return set(value if isinstance(value, list) else [value if value is not None else tok.eos_token_id])


def sample_batch(model, tok, rows, max_tokens=MAX_NEW_TOKENS):
    enc = tok([r["prompt"] for r in rows], padding=True, return_tensors="pt", add_special_tokens=False)
    mask = enc.attention_mask
    pos = (mask.cumsum(-1) - 1).clamp(min=0)
    generators = [torch.Generator(device="cpu").manual_seed(r["seed"]) for r in rows]
    emitted, done = [[] for _ in rows], [False] * len(rows)
    eos = eos_ids(model, tok)
    pad = tok.pad_token_id
    with torch.inference_mode():
        out = model(input_ids=enc.input_ids, attention_mask=mask, position_ids=pos, use_cache=True)
        for step in range(max_tokens):
            logits = out.logits[:, -1, :].float() / TEMPERATURE
            sort_logits, sort_idx = logits.sort(descending=True, dim=-1)
            probs = torch.softmax(sort_logits, dim=-1)
            remove = probs.cumsum(-1) > TOP_P
            remove[:, 1:] = remove[:, :-1].clone()
            remove[:, 0] = False
            probs = torch.softmax(sort_logits.masked_fill(remove, -float("inf")), dim=-1)
            next_ids = []
            for i, generator in enumerate(generators):
                if done[i]:
                    next_ids.append(pad)
                    continue
                chosen = torch.multinomial(probs[i], 1, generator=generator)
                token = int(sort_idx[i, chosen].item())
                next_ids.append(token)
                emitted[i].append(token)
                done[i] = token in eos
            if all(done) or step == max_tokens - 1:
                break
            next_pos = mask.sum(-1).unsqueeze(-1)
            mask = torch.cat([mask, torch.ones((len(rows), 1), dtype=mask.dtype)], dim=-1)
            out = model(input_ids=torch.tensor(next_ids).unsqueeze(-1),
                        attention_mask=mask, position_ids=next_pos,
                        past_key_values=out.past_key_values, use_cache=True)
    return [{**row, "completion": tok.decode(ids, skip_special_tokens=True),
             "generated_ids": ids, "generated_tokens": len(ids),
             "stop_reason": "eos" if ids and ids[-1] in eos else "length"}
            for row, ids in zip(rows, emitted)]
