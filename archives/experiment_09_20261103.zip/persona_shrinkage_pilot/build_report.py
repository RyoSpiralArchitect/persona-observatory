#!/usr/bin/env python3
"""Render audited Experiment 9 tables and full visible outputs; never fit a model."""
from __future__ import annotations
import base64
from collections import Counter
from datetime import datetime, timezone, timedelta
import hashlib
import html
import json
import os
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
CATS = ['support', 'reject', 'withhold', 'mixed', 'no_direct']
ALGS = ['G', 'F', 'H_gate', 'H_content', 'H', 'H_evidence', 'Hswap']
OBS = ['observer_a', 'observer_b']
COLORS = {'G':'#738391', 'F':'#c8882c', 'H_gate':'#4587a4', 'H_content':'#8964a6',
          'H':'#116f77', 'H_evidence':'#b56176', 'Hswap':'#7e8551'}


def read(name):
    return json.loads((ROOT / name).read_text())


def rows(name):
    return [json.loads(line) for line in (ROOT / name).read_text().splitlines() if line.strip()]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_mapping(mapping):
    for name, digest in mapping.items():
        assert sha(ROOT / name) == digest, name


def one(table, **criteria):
    match = [r for r in table if all(r[k] == v for k, v in criteria.items())]
    assert len(match) == 1, criteria
    return match[0]


def inline(text):
    text = html.escape(str(text))
    text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)
    return text


def table_html(headers, body):
    return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+inline(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+inline(x)+'</td>' for x in row)+'</tr>' for row in body)+'</tbody></table></div>'


def table_md(headers, body):
    return '| '+' | '.join(headers)+' |\n| '+' | '.join('---' for _ in headers)+' |\n'+''.join('| '+' | '.join(str(x) for x in row)+' |\n' for row in body)


def section(title, paragraphs, headers=None, body=None):
    h='<section><h2>'+inline(title)+'</h2>'+''.join('<p>'+inline(p)+'</p>' for p in paragraphs)
    m='## '+title+'\n\n'+'\n\n'.join(paragraphs)+'\n\n'
    if headers is not None:
        h+=table_html(headers, body)
        m+=table_md(headers, body)+'\n'
    return h+'</section>',m


def make_figure(tables):
    cache=ROOT/'.cache/matplotlib'
    cache.mkdir(parents=True,exist_ok=True)
    os.environ.setdefault('MPLCONFIGDIR',str(cache))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
                         'axes.spines.right':False,'axes.titleweight':'bold', 'savefig.facecolor':'white'})
    fig,axs=plt.subplots(2,2,figsize=(13.4,13),gridspec_kw={'height_ratios':[1,1.65]},layout='constrained')
    fig.suptitle('Experiment 9 | Forecasts frozen before 288 new outputs',fontsize=17,fontweight='bold')
    for ax,outcome,title in [(axs[0,0],'categorical','A  Five-category Brier'),(axs[0,1],'gate','B  Direct-answer gate Brier')]:
        y=np.arange(len(ALGS))
        a=[one(tables['score_summary'],observer='observer_a',predictor=alg,outcome=outcome,metric='brier')['mean'] for alg in ALGS]
        b=[one(tables['score_summary'],observer='observer_b',predictor=alg,outcome=outcome,metric='brier')['mean'] for alg in ALGS]
        for i in range(len(ALGS)):
            ax.plot([a[i],b[i]],[i,i],color='#a5b1ba',linewidth=2,zorder=1)
        ax.scatter(a,y-.07,label='Observer A',s=42,color='#176f7b',zorder=3)
        ax.scatter(b,y+.07,label='Observer B',s=42,marker='s',color='#bd7625',zorder=3)
        ax.set_yticks(y,ALGS);ax.invert_yaxis();ax.set_xlabel('Mean loss (lower is better)');ax.set_title(title,loc='left')
        ax.grid(axis='x',alpha=.2);ax.legend(loc='best',frameon=False,fontsize=9)
    ax=axs[1,0];y=np.arange(len(ALGS))
    d=[one(tables['nll_decomposition'],observer='ab_mean',predictor=a) for a in ALGS]
    gate=np.array([r['gate_nll_mean'] for r in d]);composition=np.array([r['composition_nll_contribution_mean'] for r in d])
    ax.barh(y,gate,color='#3c8990',label='Gate contribution')
    ax.barh(y,composition,left=gate,color='#c9a46a',label='Composition contribution')
    for i,(g,c) in enumerate(zip(gate,composition)):
        ax.text(g+c+.015,i,f'{g+c:.4f}',va='center',fontsize=9)
    ax.set_xlim(0,max(gate+composition)*1.17)
    ax.set_yticks(y,ALGS);ax.invert_yaxis();ax.set_xlabel('Mean NLL (natural logarithm)')
    ax.set_title('C  Exact NLL decomposition | A/B mean',loc='left')
    ax.grid(axis='x',alpha=.2);ax.legend(loc='lower right',frameon=False,fontsize=9)
    ax=axs[1,1];questions=read('question_bank.json'); y=np.arange(24)
    for offset,contrast,color in [(-.18,'H-G','#176f7b'),(.18,'H-F','#bd7625')]:
        vals=[one(tables['paired_question_values'],observer='ab_mean',contrast=contrast,outcome='categorical',metric='brier',question_id=q['question_id'])['mean'] for q in questions]
        ax.barh(y+offset,vals,height=.31,color=color,label=contrast)
    ax.axvline(0,color='#4e5b65',linewidth=.9)
    for cut in [5.5,11.5,17.5]:ax.axhline(cut,color='#d4dce2',linewidth=.8)
    abbreviations={'limited':'lim','confounded':'cnf','supportive':'sup','contradictory':'ctr'}
    ax.set_yticks(y,[q['question_id']+' '+abbreviations[q['evidence_stratum']] for q in questions],fontsize=8)
    ax.invert_yaxis();ax.set_xlabel('Paired Brier difference (negative favors H)')
    ax.set_title('D  All 24 question blocks | A/B mean',loc='left')
    ax.grid(axis='x',alpha=.2);ax.legend(frameon=False,fontsize=9)
    fig.supxlabel('Each question: 6 familiar settings x 2 paired streams. Observers reuse one foundation model and rubric. No population CI.\nlim: limited | cnf: confounded | sup: supportive | ctr: contradictory',fontsize=8,color='#546574')
    out=ROOT/'figures';out.mkdir(exist_ok=True)
    fig.savefig(out/'persona_shrinkage_summary_20261103.png',dpi=180,bbox_inches='tight')
    fig.savefig(out/'persona_shrinkage_summary_20261103.svg',bbox_inches='tight')
    plt.close(fig)


def main():
    audit=read('audits/final.json')
    assert audit['status']=='ALL_MATCH' and audit['failures']==[]
    verify_mapping(audit['input_hashes'])
    lock=read('results/score_lock.json');verify_mapping(lock['input_hashes']);verify_mapping(lock['output_hashes'])
    forecast_lock=read('predictions/forecast_lock.json');verify_mapping(forecast_lock['output_hashes'])
    tables=read('results/tables.json');selection=read('predictions/selection.json')
    profiles=read('predictions/profiles.json')['profiles'];meta=read('metadata/target.json')
    agreement=read('results/agreement_summary.json');criterion=read('results/primary_criterion.json')
    interpretation=read('interpretation_ja.json')
    make_figure(tables)
    parts=[];md=['# '+interpretation['headline']+'\n\n'+interpretation['summary']+'\n\n']
    for item in interpretation['sections']:
        h,m=section(item['heading'],item['paragraphs']);parts.append(h);md.append(m)
    h,m=section('予測の比較：新しい288出力',[
        '五分類Brierは0〜2、DのBrierは0〜1。NLLは自然対数。いずれも小さいほど良い。A/B平均は独立な576生成の平均ではなく、同じ288生成への二つの観察枝の平均である。'],
        ['予測器','五分類Brier A','五分類Brier B','五分類Brier 平均','五分類NLL 平均','D Brier 平均'],
        [[a]+[f"{one(tables['score_summary'],observer=o,predictor=a,outcome='categorical',metric='brier')['mean']:.6f}" for o in OBS+['ab_mean']]+
         [f"{one(tables['score_summary'],observer='ab_mean',predictor=a,outcome='categorical',metric='nll')['mean']:.6f}",f"{one(tables['score_summary'],observer='ab_mean',predictor=a,outcome='gate',metric='brier')['mean']:.6f}"] for a in ALGS])
    parts.append(h);md.append(m)
    contrasts=read('study_config.json')['all_contrasts']
    body=[]
    for left,right in contrasts:
        name=left+'-'+right
        ss=[one(tables['paired_summary'],observer=o,contrast=name,outcome='categorical',metric='brier') for o in OBS+['ab_mean']]
        blocks=one(tables['paired_question_summary'],observer='ab_mean',contrast=name,outcome='categorical',metric='brier')
        body.append([name]+[f"{r['mean']:+.6f}" for r in ss]+[f"{blocks['n_negative']} / {blocks['n_zero']} / {blocks['n_positive']}"])
    h,m=section('固定した比較と、問題ごとの差',[
        '差は左−右。負なら左の予測が良い。最後の列は24問題の平均差を、負・同等・正に数えたもの。同等の数値許容幅は1e-12。H−GとH−Fが主比較で、他は固定した補助比較。'],
        ['比較','Brier差 A','Brier差 B','Brier差 平均','問題：負 / 同等 / 正'],body)
    parts.append(h);md.append(m)
    body=[]
    for a in ALGS:
        c=selection['choices'][a]
        body.append([a,c['rho_D'].replace('inf','∞'),c['rho_C'].replace('inf','∞'),
                     '—' if c['cv_brier_mean'] is None else f"{c['cv_brier_mean']:.6f}"])
    h,m=section('新規生成より前に選ばれた縮約',[
        'ρが大きいほどGへ戻す。∞ならその部分はGだけで予測する。強度はセルごとではなく、予測器の全セルで共通の値。数え上げはA/B別、選ぶ強度はA/B共通。',
        'この開発スコアでHがF/Gを上回ること自体は候補集合の包含から起こりうる。新規評価の結果と区別する。Hswapは完成したHの既知文面間の対応を交換するだけで再選択しない。'],
        ['予測器','直接回答側 ρD','構成側 ρC','開発CV Brier 平均'],body)
    parts.append(h);md.append(m)
    decomp=[one(tables['nll_decomposition'],observer='ab_mean',predictor=a) for a in ALGS]
    h,m=section('どの部分から差が生まれたか',[
        '五分類NLL = 直接回答DのNLL + Dがある場合の構成NLLの寄与。この表は両方を全出力あたりで示す。直接回答がない出力も分母から除いていない。'],
        ['予測器','Dの寄与','構成の寄与','合計'],
        [[r['predictor'],f"{r['gate_nll_mean']:.6f}",f"{r['composition_nll_contribution_mean']:.6f}",f"{r['categorical_nll_mean']:.6f}"] for r in decomp])
    parts.append(h);md.append(m)
    counts=[one(tables['outcome_counts'],observer=o,group='global',group_id='all') for o in OBS]
    body=[[o.replace('observer_','').upper(),*[c['n_'+cat] for cat in CATS],c['n_direct'],c['n_strict_event']] for o,c in zip(OBS,counts)]
    h,m=section('出力と観察の分布',[
        f"全288出力を採点。EOS停止は{meta['eos_count']}、96トークンの長さ上限で止まった出力は{meta['length_count']}。出力やラベルの除外・事後の合意形成は行っていない。",
        f"A/Bの五分類一致は{agreement['category_agrees']['n']}/288、D一致は{agreement['direct_event_agrees']['n']}/288、E一致は{agreement['strict_event_agrees']['n']}/288、六コード全体の一致は{agreement['six_codes_agree']['n']}/288。高い一致も、基準の正しさやモデル間の独立な再現を保証しない。"],
        ['観察者','支持','否定','保留','混在','直接判断なし','D','E'],body)
    parts.append(h);md.append(m)
    strictbody=[]
    for a in ['G','H','E0']:
        v=[one(tables['score_summary'],observer=o,predictor=a,outcome='strict_event',metric='brier')['mean'] for o in OBS+['ab_mean']]
        strictbody.append([a]+[f'{x:.6f}' for x in v])
    h,m=section('厳しい限界表明Eは別の補助指標',[
        'Eは直接判断Dに加えて、その話者自身による明示的な証拠・知識の限界表明を要求する。G/HのD予測に、開発データ全体の限界表明傾向を掛けた。条件別の限界表明率は学習していない。E0は常に0とするBrier専用の基準。'],
        ['予測器','E Brier A','E Brier B','E Brier 平均'],strictbody)
    parts.append(h);md.append(m)
    normalized_profiles=[]
    for p in profiles:
        for a in ALGS:
            normalized_profiles.append({k:p[k] for k in ['observer','setting_id','evidence_stratum']}|
                                       {'predictor':a,**p['predictors'][a]})
    labels={o:{r['sample_id']:r for r in rows(f'observers/target/{o}/labels.jsonl')} for o in OBS}
    samples=rows('data/target_generations.jsonl')
    viewer_samples=[]
    for s in samples:
        item={k:s[k] for k in ['sample_id','question_id','setting_id','evidence_stratum','replicate_id','question','completion','seed','generated_tokens','stop_reason']}
        # Browser Number cannot exactly represent every unsigned 63-bit stream ID.
        item['seed']=str(s['seed'])
        item['labels']={}
        for o in OBS:
            l=labels[o][s['sample_id']]
            d=l['answerer_answer_mode'] in ['direct','both'] and l['answerer_judgment']!='none'
            item['labels'][o]={**l,'category':l['answerer_judgment'] if d else 'no_direct',
                                'direct_event':d,'strict_event':d and 'answerer_direct' in l['limit_owners']}
        viewer_samples.append(item)
    viewer={'categories':CATS,'algorithms':ALGS,'strata':read('study_config.json')['evidence_strata'],
            'settings':read('settings.json'),'questions':read('question_bank.json'),
            'profiles':normalized_profiles,'samples':viewer_samples}
    chronology=read('results/scoring_integrity.json')
    stages=[('設計固定',chronology['design_locked_utc']),('予測固定',chronology['forecast_locked_utc']),
            ('独立した予測の再計算',chronology['forecast_audited_utc']),('生成開始の記録',chronology['attempt_started_utc']),
            ('生成完了',chronology['generation_completed_utc']),('観察A固定',chronology['observation_locked_utc']['observer_a']),
            ('観察B固定',chronology['observation_locked_utc']['observer_b']),('採点',chronology['scored_utc'])]
    jst=timezone(timedelta(hours=9))
    h,m=section('固定と検証の順序',[
        f"最終の独立再計算は{audit['status']}。判定数{audit['assertions']:,}。予測器本体をインポートせず、生ラベルの数え上げから交差検証・選択・予測・採点・比較を再構成した。",
        f"4,032件の予測、19,008個のスカラー損失、19,584件の対応差を保持。生成の試行は一度。下記は日本時間で表示し、元記録にはUTCを保存した。"],
        ['段階','日本時間'],[[name,datetime.fromisoformat(t).astimezone(jst).strftime('%Y-%m-%d %H:%M:%S %Z')] for name,t in stages])
    appendix=h;md.append(m)
    h,m=section('読み取れる範囲',[
        '対象は一つの小型の指示モデル、英語の架空問題、既知の六つの指示文。この集合での予測上の区別を検証した。内部状態・実際の推論軌道・人格の持続は今回測定していない。',
        '旧評価144出力を含む336出力は今回の開発用。新規評価は別の24題・288生成。証拠の型は共通であり、無作為に抽出した自然な会話の集団ではない。',
        '同じ出力分布に異なる内部の仕組みが対応する可能性は残る。ここでの符号化は、観察基準と適用範囲を伴った予測的な記述として読む。'])
    appendix+=h;md.append(m)
    appendix+='<section><h2>一次資料と再現用ファイル</h2><ul><li><a href="https://sites.stat.washington.edu/raftery/Research/PDF/Gneiting2007jasa.pdf">Gneiting and Raftery (2007): probabilistic scoring rules</a></li><li><a href="https://huggingface.co/HuggingFaceTB/SmolLM2-360M-Instruct/blob/a10cc1512eabd3dde888204e902eca88bddb4951/README.md">使用した固定版の公式モデルカード</a></li></ul><p>実測値の出典は同梱の results/、予測固定は predictions/、生出力は data/target_generations.jsonl、観察は observers/、独立検証は audits/。式と手順は METHODS_JA.md と PROTOCOL.md に記載。</p></section>'
    appendix+='<section><h2>概念化と内部推論の関係を読む資料</h2><p>条件付きの観察分布を使って区別を定める理論的な位置づけと、生成された説明を内部処理の透明な記録とみなせない理由は、同梱のCONCEPT_NOTES_JA.mdで整理した。今回、理論上の最小十分状態や内部の因果機構を同定したという主張はしていない。</p><ul><li><a href="https://arxiv.org/pdf/nlin/0006025">Shalizi and Crutchfield: Memoryless Transduction</a></li><li><a href="https://papers.neurips.cc/paper_files/paper/2023/file/ed3fea9033a80fea1376299fa7863f4a-Paper-Conference.pdf">Turpin et al. (2023): Unfaithful Explanations</a></li></ul></section>'
    md.append('## 一次資料\n\n- [Gneiting and Raftery (2007)](https://sites.stat.washington.edu/raftery/Research/PDF/Gneiting2007jasa.pdf)\n- [使用モデルの固定版](https://huggingface.co/HuggingFaceTB/SmolLM2-360M-Instruct/blob/a10cc1512eabd3dde888204e902eca88bddb4951/README.md)\n- [Shalizi and Crutchfield: Memoryless Transduction](https://arxiv.org/pdf/nlin/0006025)\n- [Turpin et al. (2023): Unfaithful Explanations](https://papers.neurips.cc/paper_files/paper/2023/file/ed3fea9033a80fea1376299fa7863f4a-Paper-Conference.pdf)\n\n詳細な式と手順は METHODS_JA.md、概念化の位置づけは CONCEPT_NOTES_JA.md、事前仕様は PROTOCOL.md、全実測値は results/ を参照。\n')
    data=json.dumps(viewer,ensure_ascii=False,allow_nan=False,separators=(',',':')).replace('<','\\u003c')
    figure=ROOT/'figures/persona_shrinkage_summary_20261103.png'
    template=(ROOT/'report_viewer_template.html').read_text()
    replacements={'__TITLE__':html.escape(interpretation['headline']),'__SUMMARY__':html.escape(interpretation['summary']),
                  '__NARRATIVE_HTML__':''.join(parts),'__APPENDIX_HTML__':appendix,'__DATA_JSON__':data,
                  '__FIGURE_DATA_URL__':'data:image/png;base64,'+base64.b64encode(figure.read_bytes()).decode()}
    for key in replacements:assert template.count(key)>=1, key
    template=re.sub('|'.join(re.escape(k) for k in replacements),lambda m:replacements[m.group(0)],template)
    (ROOT/'persona_shrinkage_report_20261103.html').write_text(template)
    (ROOT/'REPORT_JA.md').write_text(''.join(md))
    report_inputs={p:sha(ROOT/p) for p in ['results/score_lock.json','results/tables.json','results/agreement_summary.json',
        'results/primary_criterion.json','results/scoring_integrity.json','audits/final.json','predictions/selection.json',
        'predictions/profiles.json','data/target_generations.jsonl','interpretation_ja.json','build_report.py','report_viewer_template.html']}
    checks={'created_utc':datetime.now(timezone.utc).isoformat(),'audited_source_tables':True,'target_outputs':len(samples),
            'viewer_profiles':len(normalized_profiles),'viewer_label_branches':len(labels),
            'report_inputs':report_inputs,'primary_criterion':criterion,'source_results_unmodified':True}
    (ROOT/'report_build.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':'REPORT_BUILT','samples':len(samples),'profiles':len(normalized_profiles),
                      'html_bytes':(ROOT/'persona_shrinkage_report_20261103.html').stat().st_size}))


if __name__=='__main__':main()
