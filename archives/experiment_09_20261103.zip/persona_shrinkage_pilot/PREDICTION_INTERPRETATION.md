# Reading the selected profiles before inspecting new outcomes

This explanatory review used only PROTOCOL.md, METHODS_JA.md, FORECAST_NOTE.md,
predictions/selection.json and predictions/profiles.json. It was completed after
generation had started, without reading any new target completion, label or
score. It adds no predictor, candidate, comparison, selection rule or success
criterion. The original design and forecast locks remain unchanged.

## A useful selected-model identity

The locked selection is F=(1,1), H=(4,1), H_content=(inf,1). Write x=n_D/n.
For each observer and setting-by-stratum cell, all three share exactly the same
conditional composition h, while their direct-answer probabilities are:

    r_F         = 0.5*x + 0.5*g_D
    r_H         = 0.2*x + 0.8*g_D
    r_H_content = g_D

Consequently their complete five-category probability vectors satisfy:

    p_H = 0.4*p_F + 0.6*p_H_content.

These are algebraic facts about the selected forecasts, not empirical target
findings. Floating-point checks on all 48 locked profiles gave maximum
conditional-composition discrepancy 2.22e-16 and mixture discrepancy 1.11e-16.

H versus F therefore tests the selected change in directness shrinkage while
holding the conditional judgment composition fixed. It cannot show that H has
learned a better conditional composition than F. H versus H_content likewise
changes only the gate for this selected pair. H_gate was separately selected
as (1,inf), so H versus H_gate changes both the chosen gate and the composition;
it is not a pure one-component intervention.

## NLL and Brier must not be conflated

For any possible labeled target, conditional composition cancels in the NLL
contrast between H and F, and between H and H_content:

    categorical_NLL(H) - categorical_NLL(F)
      = gate_NLL(H) - gate_NLL(F).

This is not true for categorical Brier. With D the binary direct-answer event
and j the observed direct category when D=1:

    categorical_Brier = (r-D)^2 + r^2*||h||^2 - 2*r*D*h_j + D.

Thus, even with h fixed, changing r affects the score through the entire
five-category distribution. A categorical-Brier improvement alone does not
establish a binary-D-Brier improvement.

The same mixture identity yields the ordinary squared-loss identity:

    Brier(H) = 0.4*Brier(F) + 0.6*Brier(H_content)
               - 0.24*||p_F-p_H_content||^2.

An improvement over the two endpoints can arise through probability
interpolation. It does not identify two internal psychological mechanisms.
The conceptual value of the factorization is that it makes a particular kind
of adaptation explicit and testable, not that it uniquely explains the network.

## Outcome interpretation, fixed in advance of reading new outputs

- H better than F: the selected stronger global shrinkage of D helped with the
  same conditional composition, under the stated scoring outcome.
- H better than H_content: retaining 20% of local D information helped relative
  to wholly global D, with the same composition.
- H better than F but worse than H_content: stronger shrinkage helped relative
  to F, but this does not establish value for retaining local D adaptation.
- H better than G: the full condition/evidence-indexed output profile improved
  forecasting over the pooled profile in this authored benchmark. It does not
  isolate persona instructions from evidence type or prove both components useful.
- H better than F but not G: only relative improvement over F, not evidence of
  added predictive value over the pooled baseline.
- H not better than G: no demonstrated H advantage under this budget, procedure
  and test bank; not a proof that condition effects do not exist or that behavioral
  concepts are generally impossible.

Even if the two co-primary comparisons pass, H_content may outperform H.
Report that control explicitly. Keep judgment-category prediction distinct from
answer correctness, epistemic quality, internal reasoning and stable personality.
