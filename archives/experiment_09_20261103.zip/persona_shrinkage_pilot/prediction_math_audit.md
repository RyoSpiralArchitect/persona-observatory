# Experiment 9 predictor, arithmetic, and artifact contract

This document describes `predict.py`. It is part of the prospective design lock.
The independent auditor must derive the calculations from raw development and
target inputs; it must not import the predictor implementation. This is an
implementation contract and internal consistency audit, not a certification of
the scientific interpretation or an independent timestamp.

## Execution boundaries

The program uses only the Python standard library and never imports the subject
runtime, Transformers, Torch, or a model. Commands are:

```
python predict.py synthetic --output setup/predict_synthetic_checks.json
python predict.py freeze
python predict.py score
```

`synthetic` uses invented histograms, invented validation losses, and invented
target/code records. It reads no development labels or target outputs and selects
no parameters on actual observations. Its optional output is an exclusive new
file under `setup/`; omitting `--output` prints the report only.

`freeze` is the only real-development selection command. It requires an intact
design lock and passing prelock audit, checks all thirty design inputs, and
refuses any preexisting predictions directory, forecast note, results directory,
target attempt marker, partial or complete target outputs, target snapshot,
failure/event metadata, or target observer folder. It recomputes every training
count in each fold. It writes the eight declared forecast artifacts exclusively,
rechecks all input hashes and the absence of target attempts, and writes the
forecast lock last. A partial attempt is preserved and cannot be resumed or
overwritten by rerunning the command.

`score` requires the unchanged design and forecast locks, a passing independent
forecast audit tied to both locks, a completed immutable target attempt, all
288 planned outputs, the source snapshot, the event log, blinded exports, and
both locked observation branches. It refuses a failure marker, partial output,
changed source or forecast, altered blind text, missing labels, or any existing
results directory. It never refits or selects using the new outcomes. All output
writes are exclusive, and `results/score_lock.json` is written last.

## Fixed axes and derived outcomes

Category order is always:

```
[support, reject, withhold, mixed, no_direct]
```

Predictor order is always:

```
[G, F, H_gate, H_content, H, H_evidence, Hswap]
```

Observer order is `observer_a`, `observer_b`. Evidence strata are `limited`,
`confounded`, `supportive`, `contradictory`. The six setting objects are read in
their frozen order. All rho values are JSON/CSV strings from
`["0.25", "1", "4", "inf"]`; nonstandard JSON Infinity/NaN is never written.

The eight original label fields remain unchanged. The category is the judgment
only when answer mode is direct/both and judgment is not none; otherwise it is
no_direct. D is category != no_direct. Strict E is D and `answerer_direct` in
`limit_owners`. Consequently E implies D by construction, without adjudicating
or changing either observer's original labels.

## Probability calculations

For each observer and training partition, global category probabilities are

```
g_k = (N_k + 0.5) / (N + 2.5)
g_D = 1 - g_no_direct
```

For local n, direct count n_D, and category counts n_k:

```
r = (n_D + rho_D*n*g_D) / (n + rho_D*n)
h_k = (n_k + rho_C*n*g_k) / (n_D + rho_C*n*g_D), k=0..3
p = [r*h_support, r*h_reject, r*h_withhold, r*h_mixed, 1-r]
```

Infinity is implemented explicitly: r=g_D, h_k=g_k/g_D. Empty cells return G.
Zero-direct cells have a well-defined global conditional composition. For the
double-infinity or empty-cell limit, the implementation returns the actual g
vector verbatim to avoid spurious floating-point differences from multiplication.

F is also calculated directly from

```
p_k(F) = (n_k + rho*n*g_k) / (n + rho*n)
```

The diagonal rho_D=rho_C gives the same distribution because the intermediate
factor n_D+rho*n*g_D cancels. In particular, the composition prior mass is
rho_C*n*g_D, not rho_C*n. Testing this identity guards against a smoothing
allocation error masquerading as a factorization improvement.

The empirical gate weight is 1/(1+rho_D). The empirical composition weight is
n_D/(n_D+rho_C*n*g_D). Infinity gives weight zero; the composition weight is also
zero when n_D=0. G's listed pool size is the global count. Hswap's pool and weights
refer to its donor wording. The underlying g is estimated from the same training
pool: this is empirical shrinkage, not an independent-data conjugate prior.

Strict-E auxiliary estimation uses the complete development partition:

```
ell = (M_E + 0.5) / (N_D + 1)
p_E(G) = p_D(G) * ell
p_E(H) = p_D(H) * ell
```

No other predictor receives an E forecast. No E-specific parameter is selected.
The additional E0 scoring baseline predicts E=0 and receives binary Brier only.

## Cross-validation and selection

The 336 development records contain 192 selected old support responses plus
144 former v8 targets, now explicitly development. Every setting-by-stratum
cell contains fourteen records from seven whole questions. Each of seven folds
withholds four questions, one per stratum, with all settings and seeds. Each fold
therefore trains on 288 records and validates on 48. Global, local, and
evidence-only counts are recomputed using only that fold's training records.

Each observer supplies separate counts and losses. The chosen hyperparameters
are shared between observers. The objective is mean held-out five-category Brier
over every record and both observers equally. NLL is never used to choose a
parameter. Candidate sets are:

| Predictor | Pooling | Eligible rho pairs |
|---|---|---|
| G | global; represented in CV by setting_stratum | inf,inf |
| F | setting_stratum | diagonal |
| H_gate | setting_stratum | any,inf |
| H_content | setting_stratum | inf,any |
| H | setting_stratum | all sixteen |
| H_evidence | evidence | all sixteen |
| Hswap | finished H permutation | inherits H; no separate selection |

Selection first identifies the minimum objective, then includes candidates whose
objective is at most that minimum plus 1e-12. F chooses the strongest rho among
those candidates. Other algorithms choose the fewest finite rho coordinates,
then strongest gate rho, then strongest composition rho. Candidates are compared
to the actual minimum rather than through a potentially nontransitive sequence
of approximate pairwise comparisons.

H's minimum cannot exceed the restricted minima. With tie preference, selected
objectives can differ from minima by up to the tolerance; selected nesting is
therefore verified with two tolerances. This is a mathematical candidate-set
fact, not a prospective performance result.

## Frozen forecast artifacts

### CSV candidate tables

`predictions/cv_scores.csv` has 448 rows: seven folds, two observers, two pooling
structures, and sixteen rho pairs. Columns are:

```
fold, observer, pooling, rho_D, rho_C, n, brier, nll
```

`pooling` is `setting_stratum` or `evidence`; n is always 48.

`predictions/cv_candidate_summary.csv` has 32 rows. Columns are:

```
pooling, rho_D, rho_C,
observer_a_brier, observer_a_nll, observer_b_brier, observer_b_nll,
mean_brier, mean_nll, eligible_algorithms, selected_algorithms
```

The final two columns are JSON lists inside CSV cells. G is eligible only on the
setting_stratum inf,inf row. Hswap is absent from both lists because it is not
selected separately. Column order follows the program's explicit dictionary
construction; field names are authoritative.

### Counts

`predictions/counts.json` contains `schema_version`, `category_order`, `full_fit`,
and `folds`. `full_fit` maps each observer to a count bundle. Each fold object has
`fold`, sorted `training_sample_ids`, sorted `validation_sample_ids`, and
`observers`, which maps each observer to its count bundle.

A bundle has:

```
global: histogram
setting_stratum: list of 24 cell objects
evidence: list of 4 cell objects
```

Every histogram has exactly these statistical fields:

```
n: integer
category_counts: five integers in category order
n_direct: integer
n_strict_event: integer
sample_ids: sorted list of IDs
```

Setting cells additionally have `setting_id`, `family`, `paraphrase_id`, and
`evidence_stratum`; evidence cells additionally have `evidence_stratum`. Final
local/evidence cell sizes are 14/84; fold sizes are 12/72.

### Selection

`predictions/selection.json` records its schema, timestamp, axes, grid, objective,
tie rules and tolerance, `choices`, `coincidences`, `global_forecast_collapse`, and
`target_outcomes_read=false`.

Each entry in `choices` contains:

```
pooling, rho_D, rho_C, cv_brier_mean, minimum_cv_brier_mean,
selected_within_tolerance_of_minimum, global_parameters, diagonal_parameters
```

Hswap additionally records `source_predictor=H` and an `operation` description.
Its two CV objective fields are null, since it inherits parameters without a
separate CV optimization. It inherits parameter flags and tie status from H.

Each coincidence record identifies observer, setting, and stratum, and includes
`exact_equal_pairs`, `equal_pairs_within_tolerance`, and `global_equal_predictors`.
`global_forecast_collapse` maps every predictor to whether all 48 profiles equal
G within 1e-12. Exact floating-point equality and numerical equivalence are
therefore distinguishable.

### Profiles and target forecasts

`predictions/profiles.json` has schema, category order, and `profiles`, a list of
48 objects. Each has observer, setting_id, family, paraphrase_id, evidence_stratum,
n_local, n_evidence, global_probabilities, pooled_limit_probability, predictors,
and effective_weights. Each predictor entry is:

```
category_probabilities: five numbers
gate_probability: number
composition_probabilities: four numbers
strict_event_probability: number for G/H; null otherwise
```

Each effective-weight entry contains gate_empirical_weight,
composition_empirical_weight, gate_prior_mass, composition_prior_mass, pool_n,
pool_n_direct, and donor_setting_id. Infinite masses are null; selected rho
strings disambiguate them. Donor is null except for Hswap.

`predictions/forecasts.jsonl` has 4,032 rows, ordered by observer, target-plan
row, then predictor. Its fields are precisely sample_id, observer, predictor,
question_id, setting_id, evidence_stratum, category_probabilities,
gate_probability, strict_event_probability. Category probabilities are lists,
not mappings. Every target receives every predictor in each observer branch.

`FORECAST_NOTE.md` explains selection and reconstruction and uses only the
prospectively fixed eval_neutral_instruction_p0 example, showing all four strata
and both observers. It includes global probabilities, pooled ell, gate and
composition probabilities, final category probabilities, strict-E probabilities,
effective empirical weights, and effective prior masses. JSON/JSONL is the
full-precision source; Markdown rounds values for readability.

### Identity certificate and lock

`predictions/identity_certificate.json` contains schema, created_utc, status,
target_outcomes_read, diagonal_checks, maximum_diagonal_error,
maximum_global_limit_error, maximum_normalization_error,
maximum_strict_E_minus_D, candidate_nesting, synthetic_edge_checks, and an
interpretation statement. Candidate-nesting entries have restricted_algorithm,
H_minimum, restricted_minimum, H_selected, restricted_selected, passes.
Synthetic checks cover zero-direct and empty cells, full NLL factorization,
normalization, strict-E nesting, tie preference, and complete invented-data
scoring dimensions. No target outcome is read to produce this certificate.

`predictions/forecast_lock.json` has schema persona-shrinkage-forecast-lock-v9,
locked_utc, design_lock_sha256, target_plan_sha256, input_hashes, output_hashes,
forecasts_sha256, forecast_rows=4032, profile_rows=48,
expected_target_samples=288, observers, predictors, category_order, and the three
true flags target_attempts_absent, target_outputs_absent, target_labels_absent.
Input hashes cover the exact thirty design inputs plus design_lock.json. Output
hashes cover exactly the seven files under predictions listed above and the
top-level FORECAST_NOTE.md. The forecast lock does not hash itself.

## Scoring artifact contract

### Per-sample wide scores

`results/per_sample_scores.jsonl` and `.csv` contain 4,608 rows:
288 targets × two observers × seven main predictors plus E0.
Metadata fields are:

```
sample_id, question_id, question_name, setting_id, family, paraphrase_id,
evidence_stratum, replicate_id, seed
```

Additional fields are:

```
observer, predictor, observed_category, direct_event, strict_event,
stop_reason, generated_tokens,
category_probabilities, gate_probability, strict_event_probability,
categorical_brier, categorical_nll, gate_brier, gate_nll,
composition_nll_contribution, conditional_composition_nll,
strict_event_brier, strict_event_nll
```

Five-category Brier is the sum of five squared errors. All logarithms are natural.
The conditional composition NLL is null when D=0; its contribution is then zero.
On every main-predictor row:

```
categorical_nll = gate_nll + composition_nll_contribution
```

E0 has strict_event_probability=0 and strict_event_brier equal to the observed
binary E value. Its other probabilities and all other loss fields, including
strict_event_nll, are null. E0 is never given a clipped or infinite NLL.

`results/scalar_scores.jsonl` contains 19,008 non-null individual loss entries.
Each includes the metadata fields, observer, predictor, outcome, metric, score.
Outcomes are categorical, gate, strict_event; metrics are brier and nll.

### Paired contrasts

`results/paired_differences.jsonl` and `.csv` contain 19,584 entries. These are
eight prespecified contrasts × categorical/gate Brier/NLL × 576 branch-target
pairs, plus H-G strict-E Brier/NLL × 576. Fields are metadata, observer, contrast,
left, right, outcome, metric, co_primary, difference. Difference is left minus
right. `co_primary` is true only for H-G/H-F categorical Brier, not other metrics
or outcomes that reuse the same contrast name.

### Canonical tables and CSV mirrors

`results/tables.json` is a mapping from table name to row lists. Every table has a
same-named CSV mirror. Canonical names are:

```
score_summary
paired_summary
score_{question,setting,stratum,family}_values
paired_{question,setting,stratum,family}_values
paired_{question,setting,stratum,family}_summary
nll_decomposition
outcome_counts
observer_agreement
observer_disagreements
```

Score aggregate keys are observer, predictor, outcome, metric. Paired aggregate
keys are observer, contrast, left, right, outcome, metric, co_primary. Group
extras are question_id/question_name/evidence_stratum for questions;
setting_id/family/paraphrase_id for settings; evidence_stratum for strata; family
for families. Statistics are n, mean, median, min, max. Paired statistics add
n_negative, n_zero, n_positive, sign_zero_tolerance. Signs use tolerance 1e-12.

Aggregate observer values are observer_a, observer_b, and ab_mean. A/B means are
formed first at the paired target/algorithm/outcome/metric level, then aggregated.
Thus every branch, including ab_mean, has n=288 in the global summaries. These
are means of losses, not losses of an averaged forecast. Main score summary has
99 rows and paired summary 102. Pair block summaries describe the distribution
of the 24 question, six setting, four stratum, or three family mean differences.
Equal block means must reproduce the global target mean because the design is
balanced. No IID p-values or population confidence intervals are produced.

The NLL decomposition table has 21 rows, with fields:

```
observer, predictor, n_targets, n_label_records, n_direct_labels, direct_fraction,
categorical_nll_mean, gate_nll_mean, composition_nll_contribution_mean,
conditional_composition_nll_mean, identity_residual,
maximum_per_sample_identity_residual
```

The ab_mean row pools both branches' loss contributions with 576 label records,
288 unique targets, and the sum of their direct counts. Its conditional mean
therefore uses the actual direct-label denominator, not an unweighted mean of
the branches' conditional means. When no direct labels exist, the conditional
mean is null and its contribution remains zero.

Outcome-count rows have observer, group, group_id, n, n_direct, n_strict_event,
n_support, n_reject, n_withhold, n_mixed, n_no_direct, n_eos, n_length. Groups are
global/all and the four declared grouping types; only actual observer branches
have observation counts. Composite group IDs join the declared group fields
with a vertical bar.

Observer agreement rows include metadata, category_a/category_b/category_agrees,
direct_event_a/direct_event_b/direct_event_agrees,
strict_event_a/strict_event_b/strict_event_agrees, and six_codes_agree. The latter
compares the six substantive codes with limit-owner order ignored, not the
free-text note. `observer_disagreements` contains exactly rows where those six
codes differ. Original full labels and notes remain available in the locked
observer inputs. An empty disagreement CSV has the single header sample_id;
the canonical JSON list is empty.

`results/agreement_summary.json` provides agreement counts/fractions, a 5×5
category confusion matrix with A as rows and B as columns, and both-positive,
A-only, B-only, both-negative counts for D and E. It explicitly states that the
branches use the same foundation model/rubric and are not independent model
replications.

`results/primary_criterion.json` records each of the six primary branch/contrast
means and signs, whether both A/B-mean differences are negative, whether all four
individual observer/contrast signs agree, and whether all four are negative.
It explicitly marks significance_claim=false and
population_confidence_intervals=false.

### Integrity and score lock

`results/scoring_integrity.json` records all design, forecast, audit, attempt,
generation, event-log, observation-lock and scoring timestamps; lock identities;
the complete scoring input hash map; counts of every record type; and explicit
retention/no-refit/no-adjudication/one-attempt declarations. Runtime parameters,
EOS and length consistency, every planned generation field, snapshot bytes,
observer blind order and text, label constraints, and full triple consistency
must pass before scoring artifacts are written.

`results/score_lock.json` has schema persona-shrinkage-score-lock-v9, locked_utc,
input_hashes, output_hashes, design_lock_sha256, forecast_lock_sha256,
target_samples=288, per_sample_score_rows=4608, paired_difference_rows=19584.
It hashes every scoring output written by this command other than itself.
The independent final audit subsequently rederives the scores; it is not part of
this score lock and must not be falsely represented as having occurred earlier.
