"""Validate complete blinded semantic labels; optionally make an immutable lock."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json

ROOT=Path(__file__).resolve().parent
FIELDS={'sample_id','answerer_answer_mode','answerer_judgment','answerer_stance','limit_owners','other_answer','character_description','note'}
ENUMS={'answerer_answer_mode':{'direct','reported','both','none'},
       'answerer_judgment':{'support','reject','withhold','mixed','none'},
       'answerer_stance':{'decisive','tentative','mixed','none'}}
OWNERS={'answerer_direct','answerer_reported','other','unclear'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def code(r):return tuple(r[k] for k in ENUMS)+(tuple(sorted(r['limit_owners'])),r['other_answer'],r['character_description'])
def validate(stage,observer,lock=False):
    d=ROOT/'observers'/stage/observer
    blind=rows(d/'validation_blind.jsonl'); labels=rows(d/'labels.jsonl')
    expected={'target':288}[stage]
    assert len(blind)==len(labels)==expected
    bi={r['sample_id']:r for r in blind};li={r['sample_id']:r for r in labels}
    assert len(bi)==len(li)==expected and set(bi)==set(li)
    same={}
    for sid,r in li.items():
        assert set(r)==FIELDS,(sid,set(r))
        for k,values in ENUMS.items():assert r[k] in values,(sid,k)
        assert isinstance(r['limit_owners'],list) and all(x in OWNERS for x in r['limit_owners'])
        assert len(r['limit_owners'])==len(set(r['limit_owners']))
        assert type(r['other_answer']) is bool and type(r['character_description']) is bool
        assert isinstance(r['note'],str) and r['note'].strip()
        none=[r[k]=='none' for k in ENUMS]
        assert len(set(none))==1,(sid,'none')
        assert (r['answerer_judgment']=='mixed')==(r['answerer_stance']=='mixed'),(sid,'mixed')
        if r['answerer_judgment']=='withhold':assert r['answerer_stance']=='tentative'
        b=bi[sid];key=(b['requested_answerer'],b['question'],b['completion'])
        if key in same:assert same[key]==code(r),(sid,'duplicate consistency')
        same[key]=code(r)
    assert (d/'discovery_blind.jsonl').read_text().strip()==''
    assert (d/'observations.md').read_text().strip()
    hashes={k+'_sha256':sha(d/f) for k,f in [('labels','labels.jsonl'),('rubric','rubric.md'),('observations','observations.md'),('discovery_blind','discovery_blind.jsonl'),('validation_blind','validation_blind.jsonl')]}
    if lock:
        p=d/'observation_lock.json';assert not p.exists(),'Never overwrite an observation lock.'
        record={'schema_version':'persona-shrinkage-observation-v9','stage':stage,'observer':observer,'locked_utc':datetime.now(timezone.utc).isoformat(),'label_rows':expected,**hashes}
        p.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    return {'status':'passed','stage':stage,'observer':observer,'records':expected,'unique_triples':len(same),'locked':lock,**hashes}
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('stage',choices=['target']);a.add_argument('observer',choices=['observer_a','observer_b']);a.add_argument('--lock',action='store_true');x=a.parse_args()
    print(json.dumps(validate(x.stage,x.observer,x.lock),ensure_ascii=False,indent=2))
