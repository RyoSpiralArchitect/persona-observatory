#!/usr/bin/env python3
"""Derive v9 development inputs from the exact immutable v8 deliverable ZIP."""
from __future__ import annotations
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT / 'provenance/source_v8.zip'
SOURCE_SHA256 = '0538ed94a04a2fa5f51195c56b66a4eabeb2ae56c0aa1cddb12787d0db8b77c8'
PREFIX = 'persona_topic_budget_pilot/'
SUPPORT_SEEDS = (2026110383, 2026110384)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write('\n')


def write_jsonl(path: Path, rows) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + '\n')


def main() -> None:
    destinations = ['development/records.jsonl',
                    'development/labels_observer_a.jsonl',
                    'development/labels_observer_b.jsonl',
                    'development/source_question_bank.json',
                    'development_manifest.json']
    assert not any((ROOT / p).exists() for p in destinations), 'Refuse overwrite'
    archive_bytes = ARCHIVE.read_bytes()
    assert sha(archive_bytes) == SOURCE_SHA256, 'Unexpected v8 source archive'
    with zipfile.ZipFile(ARCHIVE) as z:
        assert z.testzip() is None, 'Source ZIP CRC failure'
        def raw(name):
            return z.read(PREFIX + name)
        def obj(name):
            return json.loads(raw(name))
        def rows(name):
            return [json.loads(line) for line in raw(name).splitlines() if line.strip()]
        source_manifest = obj('FILE_MANIFEST.json')
        for entry in source_manifest:
            data = raw(entry['path'])
            assert len(data) == entry['bytes']
            assert sha(data) == entry['sha256'], entry['path']
        old_bank = obj('question_bank.json')
        question_map = {q['question_id']: q for q in old_bank}
        assert len(old_bank) == len(question_map) == 36
        source_rows = rows('data/support_generations.jsonl') + rows('data/target_generations.jsonl')
        chosen = [r for r in source_rows
                  if r['phase'] == 'target' or r['seed'] in SUPPORT_SEEDS]
        assert len(chosen) == len({r['sample_id'] for r in chosen}) == 336
        selected_ids = {r['sample_id'] for r in chosen}
        assert Counter(r['phase'] for r in chosen) == {'support': 192, 'target': 144}
        records = []
        for r in chosen:
            q = question_map[r['question_id']]
            assert q['phase'] == r['phase']
            fold = r['topic_index'] + (4 if r['phase'] == 'target' else 0)
            records.append({'sample_id': r['sample_id'], 'source_phase': r['phase'],
                            'development_fold': fold, 'source_record': r})
        assert Counter(r['development_fold'] for r in records) == {i: 48 for i in range(7)}
        by_cell = Counter((r['source_record']['setting_id'], r['source_record']['evidence_stratum'])
                          for r in records)
        assert len(by_cell) == 24 and set(by_cell.values()) == {14}
        folds = []
        for fold in range(7):
            held = [r for r in records if r['development_fold'] == fold]
            train = [r for r in records if r['development_fold'] != fold]
            qs = sorted({r['source_record']['question_id'] for r in held})
            assert len(qs) == 4
            assert len({question_map[q]['evidence_stratum'] for q in qs}) == 4
            assert not set(qs) & {r['source_record']['question_id'] for r in train}
            assert set(Counter((r['source_record']['setting_id'],r['source_record']['evidence_stratum'])
                               for r in train).values()) == {12}
            folds.append({'fold': fold, 'validation_question_ids': qs,
                          'validation_sample_ids': [r['sample_id'] for r in held],
                          'training_n': len(train), 'validation_n': len(held)})
        source_locks = []
        labels_out = {}
        for observer in ('observer_a', 'observer_b'):
            all_labels = {}
            for stage in ('construction', 'target'):
                base = f'observers/{stage}/{observer}'
                lock = obj(base + '/observation_lock.json')
                for stem in ('labels', 'rubric', 'observations', 'discovery_blind', 'validation_blind'):
                    suffix = '.md' if stem in ('rubric', 'observations') else '.jsonl'
                    assert sha(raw(base + '/' + stem + suffix)) == lock[stem + '_sha256']
                these = rows(base + '/labels.jsonl')
                assert len(these) == lock['label_rows']
                assert len({r['sample_id'] for r in these}) == len(these)
                for label in these:
                    assert label['sample_id'] not in all_labels
                    all_labels[label['sample_id']] = label
                source_locks.append({'observer': observer, 'stage': stage,
                                     'path_in_zip': PREFIX + base + '/observation_lock.json',
                                     'sha256': sha(raw(base + '/observation_lock.json')),
                                     'original_lock': lock})
            assert selected_ids <= all_labels.keys()
            labels_out[observer] = [all_labels[r['sample_id']] for r in records]
            assert all(len(label) == 8 for label in labels_out[observer])
        write_jsonl(ROOT / destinations[0], records)
        for observer in ('observer_a', 'observer_b'):
            write_jsonl(ROOT / f'development/labels_{observer}.jsonl', labels_out[observer])
        write_json(ROOT / 'development/source_question_bank.json', old_bank)
        manifest = {
            'schema_version': 'persona-shrinkage-development-v9',
            'created_utc': datetime.now(timezone.utc).isoformat(),
            'source_archive': {'path': 'provenance/source_v8.zip', 'sha256': SOURCE_SHA256,
                               'bytes': len(archive_bytes),
                               'internal_manifest_entries_verified': len(source_manifest)},
            'selection': {'support_seeds': list(SUPPORT_SEEDS), 'support_n': 192,
                          'old_target_n': 144, 'old_targets_are_development': True,
                          'fit_included': False, 'excess_anchor_repeats_included': False},
            'n': 336, 'n_questions': 28, 'n_settings': 6, 'n_strata': 4,
            'records_per_setting_stratum': 14, 'folds': folds,
            'selected_sample_ids': [r['sample_id'] for r in records],
            'source_observation_locks': source_locks,
            'derived_files': {p: {'sha256': sha((ROOT / p).read_bytes()),
                                   'bytes': (ROOT / p).stat().st_size}
                              for p in destinations[:-1]},
            'interpretation': 'All selected old responses and labels are development inputs. New v9 targets remain unseen.'
        }
        write_json(ROOT / 'development_manifest.json', manifest)
        print(json.dumps({'status': 'ALL_MATCH', 'n': 336, 'questions': 28,
                          'source_entries_verified': len(source_manifest),
                          'fold_sizes': [f['validation_n'] for f in folds]}))


if __name__ == '__main__':
    main()
