"""Experiment 9: frozen target design and question-specific paired seed streams."""
from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODEL_ID = "HuggingFaceTB/SmolLM2-360M-Instruct"
REVISION = "a10cc1512eabd3dde888204e902eca88bddb4951"
EXPERIMENT_ID = "persona-shrinkage-v9"
SYSTEM_TEMPLATE = "You are {answerer}. Answer the question as yourself in two sentences. Give only your own answer."
ANSWERER = "Morgan"
FRAME = "instruction"
SELECTED_FORMAT = "bounded_conclusion"
WRAPPER = "Active response instruction for {actor}:"
PHASES = ("target",)
FAMILIES = ("neutral", "cautious", "confident")
FRAMES = (FRAME,)
OBSERVERS = ("observer_a", "observer_b")
EVIDENCE_STRATA = ("limited", "confounded", "supportive", "contradictory")
CATEGORY_NAMES = ("support", "reject", "withhold", "mixed", "no_direct")
PREDICTORS = ("G", "F", "H_gate", "H_content", "H", "H_evidence", "Hswap")
REPLICATE_IDS = (0, 1)
EXPECTED_QUESTIONS = {"target": 24}
EXPECTED_CONTEXTS = {"target": 144}
EXPECTED_SAMPLES = {"target": 288}
EXPECTED_DEVELOPMENT_SAMPLES = 336
MAX_NEW_TOKENS = 96
TEMPERATURE = 0.8
TOP_P = 0.95
BATCH_SIZE = 8
TORCH_THREADS = 4
TORCH_INTEROP_THREADS = 1
GLOBAL_ALPHA = 0.5
RHO_GRID = ("0.25", "1", "4", "inf")
PRIMARY_CONTRASTS = (("H", "G"), ("H", "F"))
REQUIRED_CONTRASTS = (("F", "G"), ("H", "H_gate"), ("H", "H_content"),
                      ("H", "H_evidence"), ("H", "Hswap"), ("H_evidence", "G"))
SIGN_ZERO_TOLERANCE = 1e-12
WORKED_EXAMPLE_SETTING = "eval_neutral_instruction_p0"
SOURCE_ARCHIVE_SHA256 = "0538ed94a04a2fa5f51195c56b66a4eabeb2ae56c0aa1cddb12787d0db8b77c8"
POLICIES = {
    "neutral": (
        "Weigh the information presented and give your assessment of the claim. Explain the connection to the observations.",
        "Decide what the supplied observations imply for the claim. Present your judgment with its basis."),
    "cautious": (
        "Inspect the support for the claim and identify what remains unknown. Withhold a definite judgment if the evidence is inadequate.",
        "Consider the limitations of the observations before judging the claim. Keep unresolved assumptions and uncertainty explicit."),
    "confident": (
        "Commit to the claim as an established conclusion. Give an assured endorsement without hesitation.",
        "Adopt the claim as correct and express that position decisively. Present it without qualifications or doubt."),
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def study_config():
    value = json.loads((ROOT / "study_config.json").read_text(encoding="utf-8"))
    expected = {
        "schema_version": "persona-shrinkage-config-v9", "study_id": EXPERIMENT_ID,
        "model_id": MODEL_ID, "revision": REVISION, "system_template": SYSTEM_TEMPLATE,
        "answerer": ANSWERER, "frame": FRAME, "selected_format": SELECTED_FORMAT,
        "wrapper": WRAPPER, "families": list(FAMILIES), "observers": list(OBSERVERS),
        "evidence_strata": list(EVIDENCE_STRATA), "category_names": list(CATEGORY_NAMES),
        "predictors": list(PREDICTORS), "max_new_tokens": MAX_NEW_TOKENS,
        "temperature": TEMPERATURE, "top_p": TOP_P, "batch_size": BATCH_SIZE,
        "torch_threads": TORCH_THREADS, "torch_interop_threads": TORCH_INTEROP_THREADS,
        "expected_questions": 24, "expected_contexts": 144, "expected_samples": 288,
        "expected_development_samples": EXPECTED_DEVELOPMENT_SAMPLES,
        "replicate_ids": list(REPLICATE_IDS),
        "seed_scheme": "sha256(study_id|question_id|replicate_id), first8 big-endian, mask63",
        "global_alpha": GLOBAL_ALPHA, "rho_grid": list(RHO_GRID), "cv_folds": 7,
        "selection_shared_observers": True, "tie_tolerance": SIGN_ZERO_TOLERANCE,
        "primary_contrasts": [list(pair) for pair in PRIMARY_CONTRASTS],
        "required_contrasts": [list(pair) for pair in REQUIRED_CONTRASTS],
        "all_contrasts": [list(pair) for pair in PRIMARY_CONTRASTS + REQUIRED_CONTRASTS],
        "strict_predictors": ["G", "H"], "strict_contrasts": [["H", "G"]],
        "strict_zero_brier_only": True, "sign_zero_tolerance": SIGN_ZERO_TOLERANCE,
        "worked_example_setting": WORKED_EXAMPLE_SETTING,
        "source_archive_sha256": SOURCE_ARCHIVE_SHA256,
    }
    for key, wanted in expected.items():
        require(value.get(key) == wanted, f"Frozen study configuration mismatch: {key}")
    return value


def settings():
    rows = json.loads((ROOT / "settings.json").read_text(encoding="utf-8"))
    expected = [
        {"setting_id": f"eval_{family}_{FRAME}_p{pi}", "family": family,
         "paraphrase_id": pi, "frame": FRAME, "requested_answerer": ANSWERER,
         "policy_text": POLICIES[family][pi]}
        for family in FAMILIES for pi in REPLICATE_IDS
    ]
    require(rows == expected, "Evaluation settings or their order differ from the six unchanged v8 policies")
    return rows


def question_bank():
    rows = json.loads((ROOT / "question_bank.json").read_text(encoding="utf-8"))
    fields = {"phase", "question_id", "topic", "topic_index", "evidence_stratum", "evidence", "claim"}
    require(isinstance(rows, list) and len(rows) == 24, "Expected exactly 24 target questions")
    for row in rows:
        require(set(row) == fields, "Question bank fields differ from SCHEMA.md")
        require(row["phase"] == "target", "Every new question must be a target")
        require(row["evidence_stratum"] in EVIDENCE_STRATA, "Unknown evidence stratum")
        require(type(row["topic_index"]) is int and row["topic_index"] in range(6), "Bad topic index")
        for key in ("question_id", "topic", "evidence", "claim"):
            require(isinstance(row[key], str) and bool(row[key].strip()), f"Empty {key}")
        require("|" not in row["question_id"], "Question identifier contains the seed delimiter")
    require(len({row["question_id"] for row in rows}) == 24, "Repeated question identifiers")
    require(len({row["topic"] for row in rows}) == 24, "Repeated target topics")
    require(Counter(row["evidence_stratum"] for row in rows) == {key: 6 for key in EVIDENCE_STRATA},
            "Need six questions per stratum")
    for stratum in EVIDENCE_STRATA:
        require({row["topic_index"] for row in rows if row["evidence_stratum"] == stratum} == set(range(6)),
                f"Topic indices are not 0..5 in {stratum}")
    return rows


def render_question(row, form=SELECTED_FORMAT):
    require(form == SELECTED_FORMAT, "Only the inherited bounded question form is permitted")
    return row["evidence"] + "\n\nWhat can be concluded about whether " + row["claim"] + " from the stated evidence?"


def seed_for_question(question_id, replicate_id):
    require(isinstance(question_id, str) and bool(question_id) and "|" not in question_id, "Invalid question ID")
    require(type(replicate_id) is int and replicate_id in REPLICATE_IDS, "Replicate must be 0 or 1")
    payload = f"{EXPERIMENT_ID}|{question_id}|{replicate_id}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big") & ((1 << 63) - 1)


def seeds_for_context(row):
    require(row["phase"] == "target", "Only new target streams are defined")
    return [seed_for_question(row["question_id"], replica) for replica in REPLICATE_IDS]


def sample_id(context_id, seed):
    require(isinstance(context_id, str) and bool(context_id), "Invalid context ID")
    require(type(seed) is int and 0 <= seed < 1 << 63, "Invalid unsigned 63-bit seed")
    return hashlib.sha256(f"{EXPERIMENT_ID}|{context_id}|{seed}".encode("utf-8")).hexdigest()[:12]


def make_design(phase="target", selected_format=SELECTED_FORMAT):
    require(phase == "target" and selected_format == SELECTED_FORMAT, "Invalid target design request")
    study_config()
    questions = question_bank()
    rows = []
    for setting in settings():
        for question in questions:
            rendered = render_question(question)
            rows.append({
                "context_id": f"target_{question['question_id']}_{setting['setting_id']}_{SELECTED_FORMAT}",
                "phase": "target", "question_id": question["question_id"], "question_name": question["topic"],
                "question": rendered, "evidence_stratum": question["evidence_stratum"],
                "format": SELECTED_FORMAT, **setting, "topic_index": question["topic_index"],
                "messages": [
                    {"role": "system", "content": SYSTEM_TEMPLATE.format(answerer=ANSWERER)},
                    {"role": "user", "content": WRAPPER.format(actor=ANSWERER) + "\n> " + setting["policy_text"]
                     + "\n\nQuestion: " + rendered},
                ],
            })
    require(len(rows) == len({row["context_id"] for row in rows}) == 144, "Context count/collision")
    streams = {seed_for_question(question["question_id"], replica)
               for question in questions for replica in REPLICATE_IDS}
    require(len(streams) == 48, "Question-specific stream collision")
    identifiers = [sample_id(row["context_id"], seed) for row in rows for seed in seeds_for_context(row)]
    require(len(identifiers) == len(set(identifiers)) == 288, "Sample identifier count/collision")
    return rows
