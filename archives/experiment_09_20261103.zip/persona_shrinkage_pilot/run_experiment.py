"""Experiment 9: tokenizer-only preparation and one prospectively locked target run.

The inherited sampler is copied byte-identically. A durable exclusive attempt
marker precedes model loading. Completed output rows are appended and fsynced;
there is deliberately no retry, resume, replacement, or separate re-export CLI.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import shutil
import time
import traceback

import experiment_config as cfg

ROOT = cfg.ROOT
OBSERVERS = cfg.OBSERVERS
SELECTED_FORMAT = cfg.SELECTED_FORMAT
EXPECTED_TARGET_SAMPLES = 288
RUNTIME_SHA256 = "d164d92a51dfa436a59f330dc91e9977ce6f8b583e7271c0967cb790d37901f1"
RUBRIC_SHA256 = "7a28b5f7101c3e9de0367c064bec34f60154b7e7a4c9934c4685eff381d601a6"
BLIND_FIELDS = ("sample_id", "requested_answerer", "question", "completion", "stop_reason")
PLAN_FIELDS = {
    "sample_id", "context_id", "phase", "question_id", "question_name", "question",
    "evidence_stratum", "format", "setting_id", "family", "frame", "requested_answerer",
    "paraphrase_id", "policy_text", "topic_index", "messages", "prompt", "prompt_ids",
    "prompt_tokens", "replicate_id", "seed",
}
GENERATION_FIELDS = {"completion", "generated_ids", "generated_tokens", "stop_reason"}
LOCK_FILES = {
    "labels_sha256": "labels.jsonl", "rubric_sha256": "rubric.md",
    "observations_sha256": "observations.md", "discovery_blind_sha256": "discovery_blind.jsonl",
    "validation_blind_sha256": "validation_blind.jsonl",
}
DEVELOPMENT_FILES = (
    "development/records.jsonl", "development/labels_observer_a.jsonl",
    "development/labels_observer_b.jsonl", "development/source_question_bank.json",
)
DESIGN_INPUT_FILES = (
    "PROTOCOL.md", "SCHEMA.md", "study_config.json", "settings.json", "question_bank.json",
    "QUESTION_BANK_REVIEW.md", "DEVELOPMENT_REVIEW.md", "prepare_development.py",
    "development_manifest.json", *DEVELOPMENT_FILES, "provenance/source_v8.zip",
    "experiment_config.py", "runtime.py", "run_experiment.py", "rubric.md",
    "validate_observation.py", "predict.py", "audit_shrinkage.py", "prediction_math_audit.md",
    "AUDIT_PLAN.md", "model_manifest.json", "expected_model_manifest.json", "environment.json",
    "preflight.json", "data/target_plan.jsonl", "metadata/target_plan.json", "audits/design_prelock.json",
)
CORE_SOURCE_FILES = DESIGN_INPUT_FILES
PREPARE_OUTPUT_FILES = ("preflight.json", "data/target_plan.jsonl", "metadata/target_plan.json")
PREPARE_INPUT_FILES = tuple(name for name in DESIGN_INPUT_FILES
                            if name not in (*PREPARE_OUTPUT_FILES, "audits/design_prelock.json"))
FORECAST_OUTPUT_FILES = (
    "predictions/cv_scores.csv", "predictions/cv_candidate_summary.csv", "predictions/selection.json",
    "predictions/counts.json", "predictions/profiles.json", "predictions/forecasts.jsonl",
    "predictions/identity_certificate.json", "FORECAST_NOTE.md",
)
TARGET_ATTEMPT_PATHS = (
    "metadata/target_attempt.json", "metadata/target.json", "metadata/target_failure.json",
    "metadata/target_events.jsonl", "data/target_generations.jsonl", "source_snapshots/target",
    "observer_exports/target.json", "observers/target",
)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def timestamp(value):
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    require(result.tzinfo is not None, "Timestamp must include its UTC offset")
    return result


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def write_json(path, value):
    """Exclusive, durable creation: never replace any existing study artifact."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def write_jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        append_rows(handle, rows)


def append_rows(handle, rows):
    for row in rows:
        handle.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
    handle.flush()
    os.fsync(handle.fileno())


def checked_path(relative):
    require(isinstance(relative, str), "Artifact paths must be strings")
    path = Path(relative)
    require(not path.is_absolute() and ".." not in path.parts, f"Unsafe relative path: {relative}")
    result = ROOT / path
    require(result.resolve().is_relative_to(ROOT.resolve()), f"Artifact escapes experiment root: {relative}")
    return result


def verify_hashes(mapping):
    require(isinstance(mapping, dict) and bool(mapping), "Expected nonempty artifact hash mapping")
    for relative, checksum in mapping.items():
        require(isinstance(checksum, str) and len(checksum) == 64
                and all(char in "0123456789abcdef" for char in checksum), f"Invalid SHA-256: {relative}")
        require(digest(checked_path(relative)) == checksum, f"Changed artifact: {relative}")


def hash_files(names):
    return {relative: digest(checked_path(relative)) for relative in names}


def absent_paths(names):
    for relative in names:
        require(not checked_path(relative).exists(), f"Preserve existing artifact/attempt: {relative}")
    return {relative: True for relative in names}


def target_absence_proof():
    proof = absent_paths(TARGET_ATTEMPT_PATHS)
    results = ROOT / "results"
    require(not results.exists() or not any(results.iterdir()), "Existing target results must be preserved")
    proof["results_has_no_entries"] = True
    return {"checked_utc": now(), "absent": proof, "target_attempts_absent": True,
            "target_outputs_absent": True, "target_labels_absent": True}


def versions():
    names = ("torch", "transformers", "huggingface_hub", "tokenizers", "safetensors",
             "numpy", "pandas", "scipy", "matplotlib")
    return {name: importlib.metadata.version(name) for name in names}


def verify_model_files():
    actual = read_json(ROOT / "model_manifest.json")
    expected = read_json(ROOT / "expected_model_manifest.json")
    require(actual == expected, "Actual and expected model manifests differ")
    require(actual["model_id"] == cfg.MODEL_ID and actual["revision"] == cfg.REVISION,
            "Model identity or revision changed")
    required_names = {"config.json", "generation_config.json", "tokenizer_config.json", "tokenizer.json",
                      "special_tokens_map.json", "model.safetensors"}
    require(len(actual["files"]) == 6 and {item["name"] for item in actual["files"]} == required_names,
            "Model manifest must contain exactly the six original named files")
    for item in actual["files"]:
        path = checked_path("model/" + item["name"])
        require(path.stat().st_size == item["size_bytes"], f"Model file byte count changed: {item['name']}")
        require(digest(path) == item["sha256"], f"Model file checksum changed: {item['name']}")
    environment = read_json(ROOT / "environment.json")
    require(versions() == environment["packages"], "Runtime package versions differ from the restored v8 versions")
    require(environment["device"] == "cpu" and environment["threads"] == 4, "CPU environment changed")
    require(digest(ROOT / "runtime.py") == RUNTIME_SHA256, "Inherited sampler bytes changed")
    require(digest(ROOT / "rubric.md") == RUBRIC_SHA256, "Inherited observer rubric bytes changed")
    return digest(ROOT / "model_manifest.json")


def verify_development_inputs():
    manifest = read_json(ROOT / "development_manifest.json")
    require(manifest["schema_version"] == "persona-shrinkage-development-v9", "Wrong development schema")
    require(manifest["n"] == 336 and manifest["n_questions"] == 28, "Wrong development sample/question count")
    require(manifest["source_archive"]["sha256"] == cfg.SOURCE_ARCHIVE_SHA256,
            "Development source archive identity differs")
    require(digest(ROOT / "provenance/source_v8.zip") == cfg.SOURCE_ARCHIVE_SHA256,
            "Immutable source archive checksum changed")
    require(set(manifest["derived_files"]) == set(DEVELOPMENT_FILES), "Development file inventory changed")
    for name, record in manifest["derived_files"].items():
        require(checked_path(name).stat().st_size == record["bytes"], f"Development byte count: {name}")
        require(digest(checked_path(name)) == record["sha256"], f"Development checksum: {name}")
    rows = read_jsonl(ROOT / "development/records.jsonl")
    require(len(rows) == len({row["sample_id"] for row in rows}) == 336, "Development IDs/count differ")
    require(Counter(row["source_phase"] for row in rows) == {"support": 192, "target": 144},
            "Development source phase selection differs")
    require(Counter(row["development_fold"] for row in rows) == {fold: 48 for fold in range(7)},
            "Development folds are not the seven balanced question blocks")
    for row in rows:
        record = row["source_record"]
        require(record["sample_id"] == row["sample_id"] and record["phase"] == row["source_phase"],
                "Development source identity changed")
        if row["source_phase"] == "support":
            require(record["seed"] in (2026110383, 2026110384), "An extra support seed entered development")
        expected_fold = record["topic_index"] + (4 if row["source_phase"] == "target" else 0)
        require(row["development_fold"] == expected_fold, "Question-blocked fold assignment changed")
    return manifest, rows


def sample_id(context_id, seed):
    return cfg.sample_id(context_id, seed)


def make_contexts(tokenizer, phase="target"):
    contexts = []
    for spec in cfg.make_design(phase):
        prompt = tokenizer.apply_chat_template(spec["messages"], tokenize=False, add_generation_prompt=True)
        token_ids = tokenizer.encode(prompt, add_special_tokens=False)
        direct_ids = tokenizer.apply_chat_template(spec["messages"], tokenize=True, add_generation_prompt=True)
        require(token_ids == direct_ids and bool(token_ids), "Chat-template tokenization differs")
        contexts.append({**spec, "prompt": prompt, "prompt_ids": token_ids, "prompt_tokens": len(token_ids)})
    require(len(contexts) == len({row["context_id"] for row in contexts}) == 144, "Invalid context inventory")
    require(len({row["prompt"] for row in contexts}) == 144, "Target prompts repeat unexpectedly")
    return contexts


def make_jobs(contexts, phase="target"):
    require(phase == "target", "Only the new target phase is supported")
    jobs = [{**context, "replicate_id": replica, "seed": cfg.seed_for_question(context["question_id"], replica),
             "sample_id": sample_id(context["context_id"], cfg.seed_for_question(context["question_id"], replica))}
            for context in contexts for replica in cfg.REPLICATE_IDS]
    require(len(jobs) == len({row["sample_id"] for row in jobs}) == 288, "Invalid target sample inventory")
    require(all(set(row) == PLAN_FIELDS for row in jobs), "Target plan fields differ from SCHEMA.md")
    require(len({row["seed"] for row in jobs}) == 48, "Expected exactly 48 paired streams")
    for question in cfg.question_bank():
        for replica in cfg.REPLICATE_IDS:
            records = [row for row in jobs if row["question_id"] == question["question_id"] and row["replicate_id"] == replica]
            require(len(records) == 6 and len({row["seed"] for row in records}) == 1, "Stream pairing differs")
    return jobs


def verify_plan_structure(plan):
    design = cfg.make_design()
    require(len(plan) == 288 and len({row["sample_id"] for row in plan}) == 288, "Plan sample count/IDs differ")
    for position, row in enumerate(plan):
        context, replica = design[position // 2], position % 2
        require(set(row) == PLAN_FIELDS, "Plan has missing or surplus fields")
        require(all(row[key] == value for key, value in context.items()), "Plan differs from frozen setting-major design")
        require(row["replicate_id"] == replica, "Plan replicate order differs")
        require(row["seed"] == cfg.seed_for_question(row["question_id"], replica), "Plan stream seed differs")
        require(row["sample_id"] == sample_id(row["context_id"], row["seed"]), "Plan sample ID differs")
        require(isinstance(row["prompt"], str) and bool(row["prompt"]), "Empty target prompt")
        require(isinstance(row["prompt_ids"], list) and bool(row["prompt_ids"])
                and all(type(token) is int and token >= 0 for token in row["prompt_ids"]), "Invalid prompt tokens")
        require(row["prompt_tokens"] == len(row["prompt_ids"]), "Prompt token count differs")
    return plan


def prepare():
    absent_paths((*PREPARE_OUTPUT_FILES, "design_lock.json", "predictions/forecast_lock.json", *FORECAST_OUTPUT_FILES))
    proof = target_absence_proof()
    cfg.study_config()
    cfg.settings()
    _, development = verify_development_inputs()
    manifest_sha = verify_model_files()
    input_hashes = hash_files(PREPARE_INPUT_FILES)
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(ROOT / "model", local_files_only=True, trust_remote_code=False)
    contexts = make_contexts(tokenizer)
    jobs = make_jobs(contexts)
    old_questions = read_json(ROOT / "development/source_question_bank.json")
    new_questions = cfg.question_bank()
    require(len(old_questions) == 36, "Expected all 36 old questions for disjointness checks")
    for key in ("topic", "question_id"):
        require(not {row[key] for row in old_questions} & {row[key] for row in new_questions},
                f"Target and source question banks overlap in {key}")
    require(not {cfg.render_question(row) for row in old_questions}
            & {cfg.render_question(row) for row in new_questions}, "Old and new rendered questions overlap")
    require(not {row["seed"] for row in jobs} & {row["source_record"]["seed"] for row in development},
            "New target streams overlap old development seeds")
    write_jsonl(ROOT / "data/target_plan.jsonl", jobs)
    metadata = {
        "schema_version": "persona-shrinkage-target-plan-v9", "created_utc": now(),
        "selected_format": SELECTED_FORMAT, "expected_contexts": 144, "expected_target_samples": 288,
        "target_plan_sha256": digest(ROOT / "data/target_plan.jsonl"), "model_manifest_sha256": manifest_sha,
        "chat_template": tokenizer.chat_template, "frozen_source_hashes": input_hashes,
        "target_outputs_absent": True, "absence_proof": proof,
        "internal_states_collected": False, "model_inference_performed": False,
    }
    write_json(ROOT / "metadata/target_plan.json", metadata)
    checks = {"questions": 24, "contexts": 144, "samples": 288, "settings": 6, "unique_streams": 48,
              "question_strata": dict(Counter(row["evidence_stratum"] for row in new_questions)),
              "prompt_token_min": min(row["prompt_tokens"] for row in contexts),
              "prompt_token_max": max(row["prompt_tokens"] for row in contexts),
              "all_chat_template_tokenizations_match": True, "setting_major_bank_order_replicates_0_1": True,
              "streams_paired_across_six_settings": True, "old_and_new_questions_disjoint": True,
              "old_and_new_seeds_disjoint": True}
    record = {
        "schema_version": "persona-shrinkage-preflight-v9", "created_utc": now(),
        "model_files_match": True, "model_manifest_sha256": manifest_sha, "packages": versions(),
        "checks": checks, "design_input_hashes": {**input_hashes,
            **hash_files(("data/target_plan.jsonl", "metadata/target_plan.json"))},
        "absence_proof": proof, "internal_states_collected": False, "model_inference_performed": False,
        "note": "Tokenizer, file, and design checks only; no model instantiation or forward pass.",
    }
    verify_hashes(input_hashes)
    write_json(ROOT / "preflight.json", record)
    print(json.dumps({"status": "prepared", "checks": checks, "model_inference_performed": False}, indent=2), flush=True)


def verify_prelock_audit():
    report = read_json(ROOT / "audits/design_prelock.json")
    require(report["status"] == "ALL_MATCH" and report["failures"] == [], "Independent design audit did not pass")
    require(isinstance(report["assertions"], int) and report["assertions"] > 0, "Design audit has no assertions")
    required = set(DESIGN_INPUT_FILES) - {"audits/design_prelock.json"}
    require(set(report["input_hashes"]) == required, "Design audit does not cover the exact full prelock input set")
    require("design_lock_sha256" not in report and "design_lock.json" not in report["input_hashes"],
            "Design-prelock audit must not depend on its future design lock")
    verify_hashes(report["input_hashes"])
    audited = timestamp(report["audited_utc"])
    require(timestamp(read_json(ROOT / "preflight.json")["created_utc"]) <= audited <= timestamp(now()),
            "Design audit chronology differs")
    return report


def lock_design():
    absent_paths(("design_lock.json", "predictions/forecast_lock.json", *FORECAST_OUTPUT_FILES))
    proof = target_absence_proof()
    cfg.study_config()
    preflight = read_json(ROOT / "preflight.json")
    require(preflight["schema_version"] == "persona-shrinkage-preflight-v9"
            and preflight["model_inference_performed"] is False, "Invalid tokenizer-only preflight")
    require(set(preflight["design_input_hashes"]) == set(PREPARE_INPUT_FILES) | {"data/target_plan.jsonl", "metadata/target_plan.json"},
            "Preflight input inventory incomplete")
    verify_hashes(preflight["design_input_hashes"])
    verify_plan_structure(read_jsonl(ROOT / "data/target_plan.jsonl"))
    verify_prelock_audit()
    lock = {"schema_version": "persona-shrinkage-design-lock-v9", "locked_utc": now(),
            "selected_format": SELECTED_FORMAT, "input_hashes": hash_files(DESIGN_INPUT_FILES),
            "preflight_sha256": digest(ROOT / "preflight.json"),
            "model_manifest_sha256": digest(ROOT / "model_manifest.json"),
            "target_plan_sha256": digest(ROOT / "data/target_plan.jsonl"),
            "expected_target_samples": 288, "outputs_absent": True, "absence_proof": proof,
            "note": "Local prospective source lock; not public preregistration or an independent timestamp certificate."}
    write_json(ROOT / "design_lock.json", lock)
    verify_design_lock()
    print(json.dumps({"status": "design_locked", "locked_utc": lock["locked_utc"],
                      "design_lock_sha256": digest(ROOT / "design_lock.json"), "files": len(lock["input_hashes"])}, indent=2), flush=True)


def verify_design_lock():
    lock = read_json(ROOT / "design_lock.json")
    require(lock["schema_version"] == "persona-shrinkage-design-lock-v9", "Wrong design-lock schema")
    require(set(lock["input_hashes"]) == set(DESIGN_INPUT_FILES), "Design lock input inventory differs")
    verify_hashes(lock["input_hashes"])
    require(lock["preflight_sha256"] == digest(ROOT / "preflight.json"), "Preflight lock mismatch")
    require(lock["model_manifest_sha256"] == digest(ROOT / "model_manifest.json"), "Model-manifest lock mismatch")
    require(lock["target_plan_sha256"] == digest(ROOT / "data/target_plan.jsonl"), "Target-plan lock mismatch")
    require(lock["selected_format"] == SELECTED_FORMAT and lock["expected_target_samples"] == 288
            and lock["outputs_absent"] is True, "Design-lock declarations differ")
    audit = verify_prelock_audit()
    require(timestamp(audit["audited_utc"]) <= timestamp(lock["locked_utc"]), "Design was locked before its audit")
    return lock


def verify_forecast_boundary(require_target_absent=True):
    design = verify_design_lock()
    lock_path = ROOT / "predictions/forecast_lock.json"
    lock = read_json(lock_path)
    require(lock["schema_version"] == "persona-shrinkage-forecast-lock-v9", "Wrong forecast-lock schema")
    require(lock["design_lock_sha256"] == digest(ROOT / "design_lock.json"), "Forecast design-lock identity differs")
    require(lock["target_plan_sha256"] == digest(ROOT / "data/target_plan.jsonl"), "Forecast target-plan identity differs")
    require(set(lock["input_hashes"]) == set(DESIGN_INPUT_FILES) | {"design_lock.json"}, "Forecast input inventory differs")
    require(set(lock["output_hashes"]) == set(FORECAST_OUTPUT_FILES), "Forecast artifact inventory differs")
    verify_hashes(lock["input_hashes"])
    verify_hashes(lock["output_hashes"])
    require(lock["forecasts_sha256"] == digest(ROOT / "predictions/forecasts.jsonl"), "Forecast checksum alias differs")
    require(lock["expected_target_samples"] == 288 and lock["forecast_rows"] == 4032 and lock["profile_rows"] == 48,
            "Forecast expected row counts differ")
    require(lock["observers"] == list(OBSERVERS) and lock["predictors"] == list(cfg.PREDICTORS)
            and lock["category_order"] == list(cfg.CATEGORY_NAMES), "Forecast dimensions differ")
    require(all(lock[key] is True for key in ("target_attempts_absent", "target_outputs_absent", "target_labels_absent")),
            "Forecast lock did not attest the prospective boundary")
    design_time, forecast_time = timestamp(design["locked_utc"]), timestamp(lock["locked_utc"])
    require(design_time <= forecast_time, "Forecast precedes design lock")
    plan = verify_plan_structure(read_jsonl(ROOT / "data/target_plan.jsonl"))
    require(timestamp(read_json(ROOT / "metadata/target_plan.json")["created_utc"]) <= design_time,
            "Plan was created after design lock")
    forecasts = read_jsonl(ROOT / "predictions/forecasts.jsonl")
    expected_keys = {(row["sample_id"], observer, predictor) for row in plan
                     for observer in OBSERVERS for predictor in cfg.PREDICTORS}
    keys = [(row["sample_id"], row["observer"], row["predictor"]) for row in forecasts]
    require(len(forecasts) == len(set(keys)) == 4032 and set(keys) == expected_keys, "Forecast sample/branch grid differs")
    by_id = {row["sample_id"]: row for row in plan}
    for row in forecasts:
        require(all(row[key] == by_id[row["sample_id"]][key] for key in ("question_id", "setting_id", "evidence_stratum")),
                "Forecast target context mismatch")
        probabilities = row["category_probabilities"]
        require(len(probabilities) == 5 and all(type(value) in (int, float) and math.isfinite(value)
                                                and 0 < value < 1 for value in probabilities), "Invalid forecast probabilities")
        require(abs(sum(probabilities) - 1) < 1e-12, "Forecast categories do not sum to one")
        require(abs(row["gate_probability"] - sum(probabilities[:4])) < 1e-12, "Gate probability differs from categories")
        strict = row["strict_event_probability"]
        if row["predictor"] in ("G", "H"):
            require(type(strict) in (int, float) and math.isfinite(strict) and 0 < strict <= row["gate_probability"],
                    "Invalid strict-E probability")
        else:
            require(strict is None, "Unexpected auxiliary strict-E forecast")
    report_path = ROOT / "audits/forecast.json"
    report = read_json(report_path)
    require(report["status"] == "ALL_MATCH" and report["failures"] == [], "Independent forecast audit did not pass")
    require(isinstance(report["assertions"], int) and report["assertions"] > 0, "Forecast audit has no assertions")
    require(report["design_lock_sha256"] == digest(ROOT / "design_lock.json")
            and report["forecast_lock_sha256"] == digest(lock_path), "Forecast audit is not tied to both current locks")
    audit_required = set(lock["input_hashes"]) | set(lock["output_hashes"]) | {"predictions/forecast_lock.json"}
    require(audit_required <= set(report["input_hashes"]), "Forecast audit is missing frozen inputs or outputs")
    verify_hashes(report["input_hashes"])
    audit_time = timestamp(report["audited_utc"])
    require(forecast_time <= audit_time <= timestamp(now()), "Forecast audit chronology differs")
    proof = target_absence_proof() if require_target_absent else None
    return {"checked_utc": now(), "design_lock_sha256": digest(ROOT / "design_lock.json"),
            "forecast_lock_sha256": digest(lock_path), "forecast_audit_sha256": digest(report_path),
            "forecasts_sha256": digest(ROOT / "predictions/forecasts.jsonl"),
            "target_plan_sha256": digest(ROOT / "data/target_plan.jsonl"),
            "design_locked_utc": design["locked_utc"], "forecast_locked_utc": lock["locked_utc"],
            "forecast_audited_utc": report["audited_utc"], "absence_proof": proof,
            "all_design_and_forecast_hashes_match": True}


def source_files():
    return list(DESIGN_INPUT_FILES) + ["design_lock.json", *FORECAST_OUTPUT_FILES,
                                     "predictions/forecast_lock.json", "audits/forecast.json"]


def snapshot_sources(hashes):
    destination = ROOT / "source_snapshots/target"
    destination.mkdir(parents=True, exist_ok=False)
    for relative, checksum in hashes.items():
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with checked_path(relative).open("rb") as source, target.open("xb") as output:
            shutil.copyfileobj(source, output, length=1024 * 1024)
        require(digest(target) == checksum, f"Snapshot differs from frozen source: {relative}")
    write_json(destination / "SNAPSHOT_MANIFEST.json",
               {"schema_version": "persona-shrinkage-source-snapshot-v9", "created_utc": now(), "files": hashes})
    return digest(destination / "SNAPSHOT_MANIFEST.json")


def validate_generated_rows(plan, rows, eos_token_ids, tokenizer=None):
    require(len(rows) == len(plan) == 288 and len({row["sample_id"] for row in rows}) == 288,
            "Completed output count/identity differs")
    eos_set = set(eos_token_ids)
    for expected, row in zip(plan, rows):
        require(set(row) == PLAN_FIELDS | GENERATION_FIELDS, "Generation has missing or extra fields")
        require(all(row[key] == value for key, value in expected.items()), "Generation did not preserve every plan field")
        tokens = row["generated_ids"]
        require(isinstance(tokens, list) and all(type(token) is int and token >= 0 for token in tokens), "Invalid output token IDs")
        require(row["generated_tokens"] == len(tokens) and 1 <= len(tokens) <= cfg.MAX_NEW_TOKENS, "Output token count differs")
        require(row["stop_reason"] in ("eos", "length"), "Unknown stopping reason")
        require((row["stop_reason"] == "eos") == (tokens[-1] in eos_set), "EOS stopping metadata differs")
        require(not any(token in eos_set for token in tokens[:-1]), "Output continued after EOS")
        require(row["stop_reason"] == "eos" or len(tokens) == cfg.MAX_NEW_TOKENS, "Length stop before token budget")
        require(isinstance(row["completion"], str), "Completion must be a string")
        if tokenizer is not None:
            require(tokenizer.decode(tokens, skip_special_tokens=True) == row["completion"], "Completion/token decode differs")


def verify_completed_phase(phase="target"):
    require(phase == "target", "Only the new target phase is supported")
    boundary = verify_forecast_boundary(require_target_absent=False)
    meta = read_json(ROOT / "metadata/target.json")
    require(meta["schema_version"] == "persona-shrinkage-pilot-v9" and meta["phase"] == "target"
            and meta["status"] == "complete", "Target generation is not complete")
    require(meta["generation_count"] == meta["expected_samples"] == 288, "Target metadata count differs")
    for name in ("design_lock_sha256", "forecast_lock_sha256", "forecast_audit_sha256", "target_plan_sha256"):
        require(meta[name] == boundary[name], f"Generation boundary hash mismatch: {name}")
    marker = read_json(ROOT / "metadata/target_attempt.json")
    require(marker["schema_version"] == "persona-shrinkage-target-attempt-v9" and marker["status"] == "started",
            "Invalid immutable attempt marker")
    require(meta["attempt_marker_sha256"] == digest(ROOT / "metadata/target_attempt.json"), "Attempt marker changed")
    require(meta["created_utc"] == marker["created_utc"], "Attempt/generation creation times differ")
    require(timestamp(boundary["forecast_audited_utc"]) <= timestamp(marker["created_utc"])
            <= timestamp(meta["inference_started_utc"]) <= timestamp(meta["completed_utc"]), "Target chronology differs")
    require(meta["frozen_source_hashes"] == marker["frozen_source_hashes"] == hash_files(source_files()),
            "Generation source inventory/hash differs")
    verify_hashes(meta["frozen_source_hashes"])
    snapshot_path = ROOT / "source_snapshots/target/SNAPSHOT_MANIFEST.json"
    require(meta["source_snapshot_manifest_sha256"] == digest(snapshot_path), "Source snapshot manifest changed")
    snapshot = read_json(snapshot_path)
    require(snapshot["files"] == meta["frozen_source_hashes"], "Source snapshot inventory differs")
    for name, checksum in snapshot["files"].items():
        require(digest(ROOT / "source_snapshots/target" / name) == checksum, f"Frozen source snapshot changed: {name}")
    plan = read_jsonl(ROOT / "data/target_plan.jsonl")
    rows = read_jsonl(ROOT / "data/target_generations.jsonl")
    require(meta["generations_sha256"] == digest(ROOT / "data/target_generations.jsonl"), "Output file checksum differs")
    validate_generated_rows(plan, rows, meta["eos_token_ids"])
    require(meta["eos_count"] == sum(row["stop_reason"] == "eos" for row in rows)
            and meta["length_count"] == sum(row["stop_reason"] == "length" for row in rows), "Stopping counts differ")
    return meta, rows


def export_blind(samples, metadata):
    require(len(samples) == 288, "Wrong blind export row count")
    absent_paths(("observer_exports/target.json", "observers/target"))
    exports = {}
    for observer in OBSERVERS:
        folder = ROOT / "observers/target" / observer
        folder.mkdir(parents=True, exist_ok=False)
        with (ROOT / "rubric.md").open("rb") as source, (folder / "rubric.md").open("xb") as destination:
            shutil.copyfileobj(source, destination)
        blinded = [{key: row[key] for key in BLIND_FIELDS} for row in samples]
        blinded.sort(key=lambda row: hashlib.sha256(
            f"persona-shrinkage-v9|blind|target|{observer}|{row['sample_id']}".encode("utf-8")).hexdigest())
        write_jsonl(folder / "discovery_blind.jsonl", [])
        write_jsonl(folder / "validation_blind.jsonl", blinded)
        exports[observer] = {"rows": 288, "rubric_sha256": digest(folder / "rubric.md"),
                             "validation_blind_sha256": digest(folder / "validation_blind.jsonl"),
                             "discovery_blind_sha256": digest(folder / "discovery_blind.jsonl")}
    write_json(ROOT / "observer_exports/target.json", {
        "schema_version": "persona-shrinkage-blind-export-v9", "created_utc": now(), "bundle": "target",
        "input_hashes": {"data/target_generations.jsonl": metadata["generations_sha256"],
                         "metadata/target.json": digest(ROOT / "metadata/target.json")},
        "exports": exports, "fields": list(BLIND_FIELDS),
        "shuffle": "SHA-256(persona-shrinkage-v9|blind|target|observer|sample_id), independent observer keys",
    })


def generate():
    start = time.monotonic()
    boundary = verify_forecast_boundary(require_target_absent=True)
    manifest_sha = verify_model_files()
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(ROOT / "model", local_files_only=True, trust_remote_code=False)
    jobs = make_jobs(make_contexts(tokenizer))
    require(jobs == read_jsonl(ROOT / "data/target_plan.jsonl"), "Current tokenizer/design differs from the locked plan")
    plan_meta = read_json(ROOT / "metadata/target_plan.json")
    require(plan_meta["chat_template"] == tokenizer.chat_template, "Chat template differs from prospective plan")
    verify_hashes(plan_meta["frozen_source_hashes"])
    hashes = hash_files(source_files())
    proof = target_absence_proof()
    created = now()
    marker = {"schema_version": "persona-shrinkage-target-attempt-v9", "status": "started", "created_utc": created,
              "expected_target_samples": 288, "frozen_source_hashes": hashes,
              "model_manifest_sha256": manifest_sha, "absence_proof": proof,
              **{key: boundary[key] for key in ("design_lock_sha256", "forecast_lock_sha256", "forecast_audit_sha256",
                                               "target_plan_sha256", "design_locked_utc", "forecast_locked_utc", "forecast_audited_utc")},
              "retry_or_resume_allowed": False, "internal_states_collected": False}
    # The durable exclusive marker is the irrevocable start of this one attempt.
    write_json(ROOT / "metadata/target_attempt.json", marker)
    attempt_marker_sha = digest(ROOT / "metadata/target_attempt.json")
    samples = []
    stage = "source_snapshot"
    events = None
    try:
        events_path = ROOT / "metadata/target_events.jsonl"
        events_path.parent.mkdir(parents=True, exist_ok=True)
        events = events_path.open("x", encoding="utf-8")
        append_rows(events, [{"event": "attempt_started", "utc": created, "completed_rows": 0}])
        snapshot_sha = snapshot_sources(hashes)
        append_rows(events, [{"event": "source_snapshot_verified", "utc": now(), "completed_rows": 0}])
        stage = "model_loading"
        output_path = ROOT / "data/target_generations.jsonl"
        with output_path.open("x", encoding="utf-8") as output:
            # No model-loading or model-forward operation occurs before the marker.
            import torch
            from runtime import load_model, sample_batch, eos_ids
            tok, model = load_model()
            require(tok.chat_template == tokenizer.chat_template, "Loaded tokenizer changed its chat template")
            require(torch.get_num_threads() == 4 and torch.get_num_interop_threads() == 1, "Torch thread settings differ")
            inference_started = now()
            stop_tokens = sorted(eos_ids(model, tok))
            append_rows(events, [{"event": "model_loaded", "utc": inference_started, "completed_rows": 0}])
            stage = "generation"
            for begin in range(0, len(jobs), cfg.BATCH_SIZE):
                batch = sample_batch(model, tok, jobs[begin:begin + cfg.BATCH_SIZE])
                require(len(batch) == min(cfg.BATCH_SIZE, len(jobs) - begin), "Sampler returned an incomplete batch")
                append_rows(output, batch)
                samples.extend(batch)
                append_rows(events, [{"event": "batch_completed", "utc": now(), "completed_rows": len(samples)}])
                print(f"GENERATED target {len(samples)}/288 elapsed={time.monotonic() - start:.1f}s", flush=True)
        stage = "completion_verification"
        validate_generated_rows(jobs, samples, stop_tokens, tok)
        verify_hashes(hashes)
        require(digest(ROOT / "metadata/target_attempt.json") == attempt_marker_sha,
                "Attempt marker contents changed")
        metadata = {
            "schema_version": "persona-shrinkage-pilot-v9", "phase": "target", "status": "complete",
            "created_utc": created, "inference_started_utc": inference_started, "completed_utc": now(),
            "selected_format": SELECTED_FORMAT, "model_id": cfg.MODEL_ID, "revision": cfg.REVISION,
            "device": "cpu", "dtype": "torch.float32", "attention_implementation": "eager", "packages": versions(),
            "threads": torch.get_num_threads(), "interop_threads": torch.get_num_interop_threads(),
            "parameters": sum(parameter.numel() for parameter in model.parameters()), "chat_template": tok.chat_template,
            "seeds": sorted({row["seed"] for row in jobs}), "unique_streams": 48,
            "max_new_tokens": cfg.MAX_NEW_TOKENS, "temperature": cfg.TEMPERATURE, "top_p": cfg.TOP_P,
            "top_k": 0, "batch_size": cfg.BATCH_SIZE, "expected_contexts": 144, "expected_samples": 288,
            "generation_count": len(samples), "frozen_source_hashes": hashes, "model_manifest_sha256": manifest_sha,
            **{key: boundary[key] for key in ("design_lock_sha256", "forecast_lock_sha256", "forecast_audit_sha256", "target_plan_sha256")},
            "attempt_marker_sha256": attempt_marker_sha,
            "source_snapshot_manifest_sha256": snapshot_sha, "prediction_boundary": boundary,
            "generations_sha256": digest(ROOT / "data/target_generations.jsonl"),
            "eos_token_ids": stop_tokens, "pad_token_id": tok.pad_token_id,
            "eos_count": sum(row["stop_reason"] == "eos" for row in samples),
            "length_count": sum(row["stop_reason"] == "length" for row in samples),
            "generation_seconds": time.monotonic() - start,
            "generation_seconds_definition": "Whole command through completed output verification, including pre-run hashes and loading; excludes observation, scoring and reporting.",
            "internal_states_collected": False, "support_text_used_in_prompts": False,
            "each_question_starts_fresh_chat": True, "retry_or_resume_performed": False,
            "sampling": "Byte-identical v8 CPU runtime; question-specific per-sequence generators paired across settings; sorted nucleus; natural EOS.",
        }
        write_json(ROOT / "metadata/target.json", metadata)
        verify_completed_phase()
        stage = "blind_export"
        export_blind(samples, metadata)
        append_rows(events, [{"event": "complete", "utc": now(), "completed_rows": len(samples),
                              "generations_sha256": metadata["generations_sha256"]}])
        print("GENERATION_COMPLETE target; 288 preserved outputs and two independent blind exports.", flush=True)
    except BaseException as error:
        failure = {"schema_version": "persona-shrinkage-target-failure-v9", "failed_utc": now(), "stage": stage,
                   "attempt_created_utc": created, "exception_type": type(error).__name__, "message": str(error),
                   "traceback": traceback.format_exc(), "completed_output_rows": len(samples),
                   "attempt_marker_sha256": digest(ROOT / "metadata/target_attempt.json"),
                   "retry_or_resume_allowed": False,
                   "generations_sha256": digest(ROOT / "data/target_generations.jsonl")
                       if (ROOT / "data/target_generations.jsonl").is_file() else None}
        write_json(ROOT / "metadata/target_failure.json", failure)
        if events is not None:
            append_rows(events, [{"event": "failed", "utc": failure["failed_utc"], "stage": stage,
                                  "completed_rows": len(samples), "exception_type": type(error).__name__}])
        raise
    finally:
        if events is not None:
            events.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("prepare", "lock", "generate", "verify-design", "verify-forecast-boundary", "verify-target"))
    args = parser.parse_args()
    if args.command == "prepare":
        prepare()
    elif args.command == "lock":
        lock_design()
    elif args.command == "generate":
        generate()
    elif args.command == "verify-design":
        print(json.dumps(verify_design_lock(), ensure_ascii=False, indent=2))
    elif args.command == "verify-forecast-boundary":
        print(json.dumps(verify_forecast_boundary(), ensure_ascii=False, indent=2))
    else:
        meta, rows = verify_completed_phase()
        print(json.dumps({"status": "passed", "samples": len(rows), "generations_sha256": meta["generations_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
