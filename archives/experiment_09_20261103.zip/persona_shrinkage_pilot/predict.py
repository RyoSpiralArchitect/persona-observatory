"""Experiment 9: frozen observable-profile selection and prospective scoring.

Standard-library only. This program never loads a language model. ``synthetic``
uses invented counts; ``freeze`` is the sole real-development selection entry
point; ``score`` consumes only locked forecasts and locked observations.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parent
CATEGORIES = ("support", "reject", "withhold", "mixed", "no_direct")
OBSERVERS = ("observer_a", "observer_b")
PREDICTORS = ("G", "F", "H_gate", "H_content", "H", "H_evidence", "Hswap")
STRATA = ("limited", "confounded", "supportive", "contradictory")
FAMILIES = ("neutral", "cautious", "confident")
RHOS = ("0.25", "1", "4", "inf")
POOLINGS = ("setting_stratum", "evidence")
PRIMARY = (("H", "G"), ("H", "F"))
CONTROLS = (("F", "G"), ("H", "H_gate"), ("H", "H_content"),
            ("H", "H_evidence"), ("H", "Hswap"), ("H_evidence", "G"))
CONTRASTS = PRIMARY + CONTROLS
ALPHA = 0.5
TOL = 1e-12
EXAMPLE = "eval_neutral_instruction_p0"
META_FIELDS = ("sample_id", "question_id", "question_name", "setting_id", "family",
               "paraphrase_id", "evidence_stratum", "replicate_id", "seed")
LABEL_FIELDS = {"sample_id", "answerer_answer_mode", "answerer_judgment", "answerer_stance",
                "limit_owners", "other_answer", "character_description", "note"}
BLIND_FIELDS = {"sample_id", "requested_answerer", "question", "completion", "stop_reason"}
OBSERVATION_FILES = {"labels_sha256": "labels.jsonl", "rubric_sha256": "rubric.md",
                     "observations_sha256": "observations.md", "discovery_blind_sha256": "discovery_blind.jsonl",
                     "validation_blind_sha256": "validation_blind.jsonl"}
GROUPS = {"question": ("question_id", "question_name", "evidence_stratum"),
          "setting": ("setting_id", "family", "paraphrase_id"),
          "stratum": ("evidence_stratum",), "family": ("family",)}
GROUP_SIZES = {"question": 24, "setting": 6, "stratum": 4, "family": 3}
FORBIDDEN_TARGET_PATHS = (
    "metadata/target_attempt.json", "metadata/target.json", "metadata/target_failure.json",
    "metadata/target_events.jsonl", "data/target_generations.jsonl", "source_snapshots/target",
    "observer_exports/target.json", "observers/target",
)
DESIGN_INPUTS = (
    "PROTOCOL.md", "SCHEMA.md", "study_config.json", "settings.json", "question_bank.json",
    "QUESTION_BANK_REVIEW.md", "DEVELOPMENT_REVIEW.md", "prepare_development.py",
    "development_manifest.json", "development/records.jsonl", "development/labels_observer_a.jsonl",
    "development/labels_observer_b.jsonl", "development/source_question_bank.json", "provenance/source_v8.zip",
    "experiment_config.py", "runtime.py", "run_experiment.py", "rubric.md", "validate_observation.py",
    "predict.py", "audit_shrinkage.py", "prediction_math_audit.md", "AUDIT_PLAN.md", "model_manifest.json",
    "expected_model_manifest.json", "environment.json", "preflight.json", "data/target_plan.jsonl",
    "metadata/target_plan.json", "audits/design_prelock.json",
)
FORECAST_OUTPUTS = (
    "predictions/cv_scores.csv", "predictions/cv_candidate_summary.csv", "predictions/selection.json",
    "predictions/counts.json", "predictions/profiles.json", "predictions/forecasts.jsonl",
    "predictions/identity_certificate.json", "FORECAST_NOTE.md",
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def timestamp(value):
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    require(result.tzinfo is not None, "Timezone-aware timestamps are required.")
    return result


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def safe_path(relative):
    p = Path(relative)
    require(not p.is_absolute() and ".." not in p.parts, f"Unsafe relative path: {relative}")
    result = ROOT / p
    require(result.resolve().is_relative_to(ROOT.resolve()), f"Path escapes project: {relative}")
    return result


def verify_hashes(mapping):
    require(isinstance(mapping, dict) and mapping, "A nonempty path/hash mapping is required.")
    for relative, expected in mapping.items():
        require(isinstance(expected, str) and len(expected) == 64, f"Invalid SHA-256: {relative}")
        require(digest(safe_path(relative)) == expected, f"Changed locked artifact: {relative}")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(obj, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def write_jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")


def write_csv(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    # Empty disagreement tables still receive a documented header.
    fields = list(rows[0]) if rows else ["sample_id"]
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            require(set(row) == set(fields), f"Inconsistent columns: {path.name}")
            writer.writerow({k: json.dumps(v, ensure_ascii=False, allow_nan=False)
                             if isinstance(v, (list, dict, tuple)) else v for k, v in row.items()})


def check_config():
    c = read_json(ROOT / "study_config.json")
    expected = {"schema_version": "persona-shrinkage-config-v9", "study_id": "persona-shrinkage-v9",
                "model_id": "HuggingFaceTB/SmolLM2-360M-Instruct",
                "revision": "a10cc1512eabd3dde888204e902eca88bddb4951", "answerer": "Morgan",
                "frame": "instruction", "selected_format": "bounded_conclusion",
                "families": list(FAMILIES), "observers": list(OBSERVERS), "evidence_strata": list(STRATA),
                "category_names": list(CATEGORIES), "predictors": list(PREDICTORS),
                "global_alpha": ALPHA, "rho_grid": list(RHOS), "cv_folds": 7,
                "expected_questions": 24, "expected_contexts": 144, "expected_samples": 288,
                "expected_development_samples": 336, "replicate_ids": [0, 1],
                "selection_shared_observers": True, "tie_tolerance": TOL, "sign_zero_tolerance": TOL,
                "primary_contrasts": [list(p) for p in PRIMARY],
                "required_contrasts": [list(p) for p in CONTROLS],
                "all_contrasts": [list(p) for p in CONTRASTS], "strict_predictors": ["G", "H"],
                "strict_contrasts": [["H", "G"]], "strict_zero_brier_only": True,
                "worked_example_setting": EXAMPLE, "max_new_tokens": 96}
    for key, value in expected.items():
        require(c.get(key) == value, f"Configuration differs from frozen algorithm: {key}")
    settings = read_json(ROOT / "settings.json")
    require(isinstance(settings, list) and len(settings) == 6, "Six settings required.")
    require([(s["family"], s["paraphrase_id"]) for s in settings]
            == list(itertools.product(FAMILIES, (0, 1))), "Setting order/inventory differs.")
    for s in settings:
        require(s["setting_id"] == f"eval_{s['family']}_instruction_p{s['paraphrase_id']}", "Invalid setting ID.")
        require(s["frame"] == "instruction" and s["requested_answerer"] == "Morgan", "Frame/name changed.")
    return c, settings


def verify_design_lock():
    lock = read_json(ROOT / "design_lock.json")
    require(lock["schema_version"] == "persona-shrinkage-design-lock-v9", "Unknown design lock.")
    timestamp(lock["locked_utc"])
    require(set(lock["input_hashes"]) == set(DESIGN_INPUTS), "Design input inventory differs from SCHEMA.")
    verify_hashes(lock["input_hashes"])
    require(lock["outputs_absent"] is True and lock["expected_target_samples"] == 288, "Invalid design boundary.")
    for field, path in (("preflight_sha256", "preflight.json"), ("model_manifest_sha256", "model_manifest.json"),
                        ("target_plan_sha256", "data/target_plan.jsonl")):
        require(lock[field] == digest(ROOT / path), f"Design alias hash differs: {field}")
    review = read_json(ROOT / "audits/design_prelock.json")
    require(review["status"] == "ALL_MATCH", "Independent design audit did not pass.")
    require("design_lock_sha256" not in review, "Design-prelock audit refers circularly to future lock.")
    require(timestamp(review["audited_utc"]) <= timestamp(lock["locked_utc"]), "Design audit must precede lock.")
    return lock


def assert_targets_absent():
    for relative in FORBIDDEN_TARGET_PATHS:
        require(not safe_path(relative).exists(), f"Target attempt/output already exists: {relative}")
    require(not (ROOT / "results").exists(), "Results already exist before target forecasting.")


def validate_label(label):
    require(set(label) == LABEL_FIELDS, "Labels require the unchanged eight fields.")
    require(isinstance(label["sample_id"], str), "Invalid label ID.")
    require(label["answerer_answer_mode"] in ("direct", "reported", "both", "none"), "Invalid answer mode.")
    require(label["answerer_judgment"] in CATEGORIES[:4] + ("none",), "Invalid judgment.")
    require(label["answerer_stance"] in ("decisive", "tentative", "mixed", "none"), "Invalid stance.")
    owners = label["limit_owners"]
    require(isinstance(owners, list) and all(isinstance(x, str) for x in owners), "Invalid limit owners.")
    require(len(owners) == len(set(owners)) and set(owners) <=
            {"answerer_direct", "answerer_reported", "other", "unclear"}, "Invalid/duplicate limit owner.")
    require(type(label["other_answer"]) is bool and type(label["character_description"]) is bool, "Boolean codes required.")
    require(isinstance(label["note"], str) and label["note"].strip(), "Grounded note required.")
    none = [label[k] == "none" for k in ("answerer_answer_mode", "answerer_judgment", "answerer_stance")]
    require(len(set(none)) == 1, "None codes must coincide.")
    require((label["answerer_judgment"] == "mixed") == (label["answerer_stance"] == "mixed"), "Mixed codes differ.")
    if label["answerer_judgment"] == "withhold":
        require(label["answerer_stance"] == "tentative", "Withhold must be tentative.")


def category(label):
    return label["answerer_judgment"] if (label["answerer_answer_mode"] in ("direct", "both")
                                         and label["answerer_judgment"] != "none") else "no_direct"


def direct(label):
    return category(label) != "no_direct"


def strict_event(label):
    return direct(label) and "answerer_direct" in label["limit_owners"]


def six_codes(label):
    return (label["answerer_answer_mode"], label["answerer_judgment"], label["answerer_stance"],
            tuple(sorted(label["limit_owners"])), label["other_answer"], label["character_description"])


def load_development(settings):
    wrapped = read_jsonl(ROOT / "development/records.jsonl")
    require(len(wrapped) == 336 and len({w["sample_id"] for w in wrapped}) == 336, "Development ID/count mismatch.")
    settings_by_id = {s["setting_id"]: s for s in settings}
    records = []
    for w in wrapped:
        require(set(w) == {"sample_id", "source_phase", "development_fold", "source_record"}, "Development wrapper changed.")
        r = w["source_record"]
        require(w["sample_id"] == r["sample_id"] and w["source_phase"] == r["phase"], "Source identity mismatch.")
        phase = w["source_phase"]
        require(phase in ("support", "target"), "Excluded fit output entered development.")
        permitted_seeds = {2026110383, 2026110384} if phase == "support" else {2026110391, 2026110392}
        require(r["seed"] in permitted_seeds, "Excess seed entered development.")
        fold = r["topic_index"] + (0 if phase == "support" else 4)
        require(w["development_fold"] == fold and 0 <= fold <= 6, "Development fold mismatch.")
        require(all(r[k] == v for k, v in settings_by_id[r["setting_id"]].items()), "Development setting changed.")
        require(r["format"] == "bounded_conclusion" and r["evidence_stratum"] in STRATA, "Development design changed.")
        records.append({**r, "development_fold": fold, "source_phase": phase})
    require(Counter(r["source_phase"] for r in records) == {"support": 192, "target": 144}, "Source selection count mismatch.")
    require(Counter(r["development_fold"] for r in records) == {i: 48 for i in range(7)}, "Unbalanced CV folds.")
    require(len({r["question_id"] for r in records}) == 28, "Expected 28 development questions.")
    for qid in {r["question_id"] for r in records}:
        rows = [r for r in records if r["question_id"] == qid]
        require(len(rows) == 12 and len({r["development_fold"] for r in rows}) == 1, "Question leaked across folds.")
    for fold in range(7):
        rows = [r for r in records if r["development_fold"] == fold]
        require(Counter(r["evidence_stratum"] for r in rows) == {s: 12 for s in STRATA}, "Fold stratum imbalance.")
    labels = {}
    ids = {r["sample_id"] for r in records}
    for observer in OBSERVERS:
        lab = read_jsonl(ROOT / f"development/labels_{observer}.jsonl")
        labels[observer] = {l["sample_id"]: l for l in lab}
        require(len(lab) == len(labels[observer]) == 336 and set(labels[observer]) == ids, "Development labels mismatch.")
        for l in lab:
            validate_label(l)
            require(not strict_event(l) or direct(l), "Strict E must imply D.")
    return records, labels


def seed_for(question_id, replicate_id):
    raw = hashlib.sha256(f"persona-shrinkage-v9|{question_id}|{replicate_id}".encode()).digest()
    return int.from_bytes(raw[:8], "big") & ((1 << 63) - 1)


def verify_plan(settings, development=None):
    plan = read_jsonl(ROOT / "data/target_plan.jsonl")
    bank = read_json(ROOT / "question_bank.json")
    require(len(bank) == 24 and len({q["question_id"] for q in bank}) == 24, "Target bank inventory mismatch.")
    require(len(plan) == len({p["sample_id"] for p in plan}) == 288, "Target plan inventory mismatch.")
    expected_order = [(s, q, rep) for s in settings for q in bank for rep in (0, 1)]
    for row, (setting, question, rep) in zip(plan, expected_order):
        require(not {"completion", "generated_ids", "generated_tokens", "stop_reason"} & set(row), "Plan contains outcomes.")
        require(all(row[k] == v for k, v in setting.items()), "Target setting metadata changed.")
        require(row["question_id"] == question["question_id"] and row["question_name"] == question["topic"], "Question mismatch.")
        require(row["evidence_stratum"] == question["evidence_stratum"] and row["topic_index"] == question["topic_index"], "Stratum/index mismatch.")
        require(row["question"] == question["evidence"] + "\n\nWhat can be concluded about whether "
                + question["claim"] + " from the stated evidence?", "Bounded question differs.")
        context_id = f"target_{question['question_id']}_{setting['setting_id']}_bounded_conclusion"
        seed = seed_for(question["question_id"], rep)
        sid = hashlib.sha256(f"persona-shrinkage-v9|{context_id}|{seed}".encode()).hexdigest()[:12]
        require(row["context_id"] == context_id and row["sample_id"] == sid and row["seed"] == seed
                and row["replicate_id"] == rep, "Plan ID/seed/order mismatch.")
        require(row["phase"] == "target" and row["format"] == "bounded_conclusion", "Wrong target phase/format.")
        require(isinstance(row["prompt"], str) and isinstance(row["prompt_ids"], list)
                and row["prompt_tokens"] == len(row["prompt_ids"]), "Invalid planned prompt/tokens.")
    require(len({r["seed"] for r in plan}) == 48, "Target must use 48 question-specific streams.")
    require(Counter(r["evidence_stratum"] for r in plan) == {s: 72 for s in STRATA}, "Target stratum imbalance.")
    if development is not None:
        require(not {r["question_id"] for r in plan} & {r["question_id"] for r in development}, "Development/target question overlap.")
        require(not {r["seed"] for r in plan} & {r["seed"] for r in development}, "Target/development seed overlap.")
    meta = read_json(ROOT / "metadata/target_plan.json")
    require(meta["target_plan_sha256"] == digest(ROOT / "data/target_plan.jsonl"), "Plan metadata hash differs.")
    return plan


def histogram(rows, labels):
    counts = Counter(category(labels[r["sample_id"]]) for r in rows)
    n_d = sum(direct(labels[r["sample_id"]]) for r in rows)
    n_e = sum(strict_event(labels[r["sample_id"]]) for r in rows)
    require(0 <= n_e <= n_d <= len(rows), "Invalid event nesting.")
    return {"n": len(rows), "category_counts": [counts[k] for k in CATEGORIES], "n_direct": n_d,
            "n_strict_event": n_e, "sample_ids": sorted(r["sample_id"] for r in rows)}


def build_counts(rows, labels, settings):
    cells, evidence = [], []
    for setting in settings:
        for stratum in STRATA:
            subset = [r for r in rows if r["setting_id"] == setting["setting_id"] and r["evidence_stratum"] == stratum]
            cells.append({"setting_id": setting["setting_id"], "family": setting["family"],
                          "paraphrase_id": setting["paraphrase_id"], "evidence_stratum": stratum,
                          **histogram(subset, labels)})
    for stratum in STRATA:
        evidence.append({"evidence_stratum": stratum,
                         **histogram([r for r in rows if r["evidence_stratum"] == stratum], labels)})
    n_local = len(rows) // 24
    require(len(rows) in (288, 336) and all(c["n"] == n_local for c in cells), "Unbalanced local fit counts.")
    require(all(c["n"] == n_local * 6 for c in evidence), "Unbalanced evidence-only fit counts.")
    return {"global": histogram(rows, labels), "setting_stratum": cells, "evidence": evidence}


def global_vector(hist):
    require(sum(hist["category_counts"]) == hist["n"], "Histogram total mismatch.")
    return [(v + ALPHA) / (hist["n"] + 5 * ALPHA) for v in hist["category_counts"]]


def check_vector(p):
    require(len(p) == 5 and all(math.isfinite(x) and 0 < x < 1 for x in p), "Interior five-category vector required.")
    require(abs(math.fsum(p) - 1) <= TOL, "Probabilities do not normalize.")


def flat_vector(hist, g, rho):
    if hist["n"] == 0 or rho == "inf":
        return list(g)
    mass = float(rho) * hist["n"]
    return [(count + mass * prior) / (hist["n"] + mass)
            for count, prior in zip(hist["category_counts"], g)]


def factorized(hist, g, rho_d, rho_c):
    n, nd = hist["n"], hist["n_direct"]
    gd = 1 - g[4]
    if n == 0:
        r, h = gd, [p / gd for p in g[:4]]
    else:
        r = gd if rho_d == "inf" else (nd + float(rho_d) * n * gd) / (n + float(rho_d) * n)
        h = ([p / gd for p in g[:4]] if rho_c == "inf" else
             [(hist["category_counts"][i] + float(rho_c) * n * g[i]) /
              (nd + float(rho_c) * n * gd) for i in range(4)])
    p = [r * value for value in h] + [1 - r]
    # Exact G limit is deliberately returned verbatim, not re-rounded through products.
    if n == 0 or (rho_d == "inf" and rho_c == "inf"):
        p = list(g)
    check_vector(p)
    require(abs(math.fsum(h) - 1) <= TOL and abs(r - (1 - p[4])) <= TOL, "Gate/composition incoherence.")
    gate_weight = 0.0 if n == 0 or rho_d == "inf" else 1 / (1 + float(rho_d))
    composition_weight = (0.0 if n == 0 or nd == 0 or rho_c == "inf" else
                          nd / (nd + float(rho_c) * n * gd))
    return {"category_probabilities": p, "gate_probability": r, "composition_probabilities": h,
            "strict_event_probability": None}, gate_weight, composition_weight


def categorical_loss(p, observed):
    i = CATEGORIES.index(observed)
    return math.fsum((x - (j == i)) ** 2 for j, x in enumerate(p)), -math.log(p[i])


def binary_loss(p, observed):
    require(0 < p < 1 and math.isfinite(p), "Binary NLL requires an interior probability.")
    return (p - int(observed)) ** 2, (-math.log(p) if observed else -math.log1p(-p))


def count_index(bundle, pooling):
    if pooling == "setting_stratum":
        return {(c["setting_id"], c["evidence_stratum"]): c for c in bundle[pooling]}
    return {c["evidence_stratum"]: c for c in bundle[pooling]}


def run_cv(records, labels, settings):
    cv_rows, fold_counts = [], []
    for fold in range(7):
        train = [r for r in records if r["development_fold"] != fold]
        validation = [r for r in records if r["development_fold"] == fold]
        require(len(train) == 288 and len(validation) == 48, "CV fold size changed.")
        require(not {r["question_id"] for r in train} & {r["question_id"] for r in validation}, "CV question leakage.")
        fc = {"fold": fold, "training_sample_ids": sorted(r["sample_id"] for r in train),
              "validation_sample_ids": sorted(r["sample_id"] for r in validation), "observers": {}}
        for observer in OBSERVERS:
            counts = build_counts(train, labels[observer], settings)
            fc["observers"][observer] = counts
            g = global_vector(counts["global"])
            for pooling in POOLINGS:
                cells = count_index(counts, pooling)
                for rd, rc in itertools.product(RHOS, repeat=2):
                    profiles = {key: factorized(hist, g, rd, rc)[0]["category_probabilities"] for key, hist in cells.items()}
                    losses = []
                    for row in validation:
                        key = ((row["setting_id"], row["evidence_stratum"]) if pooling == "setting_stratum"
                               else row["evidence_stratum"])
                        losses.append(categorical_loss(profiles[key], category(labels[observer][row["sample_id"]])))
                    cv_rows.append({"fold": fold, "observer": observer, "pooling": pooling, "rho_D": rd,
                                    "rho_C": rc, "n": len(validation),
                                    "brier": math.fsum(v[0] for v in losses) / len(losses),
                                    "nll": math.fsum(v[1] for v in losses) / len(losses)})
        fold_counts.append(fc)
    require(len(cv_rows) == 448, "CV candidate table inventory mismatch.")
    return cv_rows, fold_counts


def eligible_algorithms(pooling, rd, rc):
    if pooling == "evidence":
        return ["H_evidence"]
    result = []
    if rd == rc == "inf":
        result.append("G")
    if rd == rc:
        result.append("F")
    if rc == "inf":
        result.append("H_gate")
    if rd == "inf":
        result.append("H_content")
    result.append("H")
    return result


def rho_rank(value):
    return RHOS.index(value)


def candidate_tie_key(row, algorithm):
    if algorithm == "F":
        return (-rho_rank(row["rho_D"]),)
    return ((row["rho_D"] != "inf") + (row["rho_C"] != "inf"),
            -rho_rank(row["rho_D"]), -rho_rank(row["rho_C"]))


def summarize_and_select(cv_rows):
    summaries = []
    for pooling in POOLINGS:
        for rd, rc in itertools.product(RHOS, repeat=2):
            row = {"pooling": pooling, "rho_D": rd, "rho_C": rc}
            for observer in OBSERVERS:
                subset = [r for r in cv_rows if (r["pooling"], r["rho_D"], r["rho_C"], r["observer"])
                          == (pooling, rd, rc, observer)]
                require(len(subset) == 7, "Missing CV folds.")
                for metric in ("brier", "nll"):
                    row[f"{observer}_{metric}"] = math.fsum(r[metric] * r["n"] for r in subset) / sum(r["n"] for r in subset)
            row["mean_brier"] = math.fsum(row[f"{o}_brier"] for o in OBSERVERS) / 2
            row["mean_nll"] = math.fsum(row[f"{o}_nll"] for o in OBSERVERS) / 2
            row["eligible_algorithms"] = eligible_algorithms(pooling, rd, rc)
            row["selected_algorithms"] = []
            summaries.append(row)
    choices = {}
    for algorithm in PREDICTORS[:-1]:
        eligible = [r for r in summaries if algorithm in r["eligible_algorithms"]]
        minimum = min(r["mean_brier"] for r in eligible)
        tied = [r for r in eligible if r["mean_brier"] <= minimum + TOL]
        selected = min(tied, key=lambda r: candidate_tie_key(r, algorithm))
        selected["selected_algorithms"].append(algorithm)
        choices[algorithm] = {"pooling": "global" if algorithm == "G" else selected["pooling"],
                              "rho_D": selected["rho_D"], "rho_C": selected["rho_C"],
                              "cv_brier_mean": selected["mean_brier"], "minimum_cv_brier_mean": minimum,
                              "selected_within_tolerance_of_minimum": True,
                              "global_parameters": selected["rho_D"] == selected["rho_C"] == "inf",
                              "diagonal_parameters": selected["rho_D"] == selected["rho_C"]}
    choices["Hswap"] = {**choices["H"], "cv_brier_mean": None, "minimum_cv_brier_mean": None,
                         "source_predictor": "H", "operation": "swap finished H vectors between wordings within family/stratum"}
    return summaries, choices


def swapped_setting(setting_id):
    require(setting_id.endswith(("_p0", "_p1")), "Unknown wording ID.")
    return setting_id[:-1] + ("1" if setting_id.endswith("0") else "0")


def build_profiles(full_counts, choices, settings):
    profiles = []
    for observer in OBSERVERS:
        bundle = full_counts[observer]
        g = global_vector(bundle["global"])
        ell = (bundle["global"]["n_strict_event"] + 0.5) / (bundle["global"]["n_direct"] + 1)
        local, evidence = count_index(bundle, "setting_stratum"), count_index(bundle, "evidence")
        for setting in settings:
            for stratum in STRATA:
                cell = local[setting["setting_id"], stratum]
                profile = {"observer": observer, "setting_id": setting["setting_id"], "family": setting["family"],
                           "paraphrase_id": setting["paraphrase_id"], "evidence_stratum": stratum,
                           "n_local": cell["n"], "n_evidence": evidence[stratum]["n"],
                           "global_probabilities": g, "pooled_limit_probability": ell,
                           "predictors": {}, "effective_weights": {}}
                for algorithm in PREDICTORS:
                    choice = choices[algorithm]
                    hist = evidence[stratum] if algorithm == "H_evidence" else cell
                    if algorithm == "G":
                        hist = bundle["global"]
                    if algorithm == "Hswap":
                        hist = local[swapped_setting(setting["setting_id"]), stratum]
                    p, wg, wc = factorized(hist, g, choice["rho_D"], choice["rho_C"])
                    if algorithm == "F":
                        # Keep the actual flat implementation as the F forecast.
                        p["category_probabilities"] = flat_vector(hist, g, choice["rho_D"])
                        p["gate_probability"] = 1 - p["category_probabilities"][4]
                        p["composition_probabilities"] = [v / p["gate_probability"] for v in p["category_probabilities"][:4]]
                    if algorithm in ("G", "H"):
                        p["strict_event_probability"] = p["gate_probability"] * ell
                    profile["predictors"][algorithm] = p
                    profile["effective_weights"][algorithm] = {"gate_empirical_weight": wg, "composition_empirical_weight": wc,
                        "gate_prior_mass": None if choice["rho_D"] == "inf" else float(choice["rho_D"]) * hist["n"],
                        "composition_prior_mass": None if choice["rho_C"] == "inf" else float(choice["rho_C"]) * hist["n"] * (1 - g[4]),
                        "pool_n": hist["n"], "pool_n_direct": hist["n_direct"],
                        "donor_setting_id": swapped_setting(setting["setting_id"]) if algorithm == "Hswap" else None}
                profiles.append(profile)
    require(len(profiles) == 48, "Profile count mismatch.")
    return profiles


def coincidence_records(profiles):
    records = []
    global_collapse = {a: True for a in PREDICTORS}
    for profile in profiles:
        vectors = {a: profile["predictors"][a]["category_probabilities"] for a in PREDICTORS}
        exact, within = [], []
        for a, b in itertools.combinations(PREDICTORS, 2):
            if vectors[a] == vectors[b]:
                exact.append([a, b])
            if max(abs(x - y) for x, y in zip(vectors[a], vectors[b])) <= TOL:
                within.append([a, b])
        equal_global = [a for a in PREDICTORS if max(abs(x - y) for x, y in zip(vectors[a], vectors["G"])) <= TOL]
        for a in PREDICTORS:
            global_collapse[a] &= a in equal_global
        records.append({k: profile[k] for k in ("observer", "setting_id", "evidence_stratum")} |
                       {"exact_equal_pairs": exact, "equal_pairs_within_tolerance": within, "global_equal_predictors": equal_global})
    return records, global_collapse


def math_identity_report(bundles):
    maximum_diagonal = maximum_global = maximum_norm = 0.0
    checked = 0
    for bundle in bundles:
        g = global_vector(bundle["global"])
        for hist in bundle["setting_stratum"] + bundle["evidence"]:
            for rho in RHOS:
                p = factorized(hist, g, rho, rho)[0]["category_probabilities"]
                f = flat_vector(hist, g, rho)
                maximum_diagonal = max(maximum_diagonal, max(abs(a - b) for a, b in zip(p, f)))
                checked += 1
            pg = factorized(hist, g, "inf", "inf")[0]["category_probabilities"]
            maximum_global = max(maximum_global, max(abs(a - b) for a, b in zip(pg, g)))
            for rd, rc in itertools.product(RHOS, repeat=2):
                p = factorized(hist, g, rd, rc)[0]["category_probabilities"]
                maximum_norm = max(maximum_norm, abs(math.fsum(p) - 1))
    require(max(maximum_diagonal, maximum_global, maximum_norm) <= TOL, "Shrinkage identity failed.")
    return {"diagonal_checks": checked, "maximum_diagonal_error": maximum_diagonal,
            "maximum_global_limit_error": maximum_global, "maximum_normalization_error": maximum_norm}


def synthetic_checks():
    g_hist = {"n": 50, "category_counts": [12, 7, 4, 2, 25], "n_direct": 25, "n_strict_event": 4, "sample_ids": []}
    cases = ([3, 1, 1, 0, 3], [0, 0, 0, 0, 8], [0, 0, 0, 0, 0], [4, 2, 1, 1, 0])
    histograms = [{"n": sum(c), "category_counts": list(c), "n_direct": sum(c[:4]),
                   "n_strict_event": 0, "sample_ids": []} for c in cases]
    bundle = {"global": g_hist, "setting_stratum": histograms, "evidence": []}
    report = math_identity_report([bundle])
    g = global_vector(g_hist)
    max_nll_error, evaluations = 0.0, 0
    for hist in histograms:
        for rd, rc in itertools.product(RHOS, repeat=2):
            p = factorized(hist, g, rd, rc)[0]
            for i, cat in enumerate(CATEGORIES):
                d = cat != "no_direct"
                nll = categorical_loss(p["category_probabilities"], cat)[1]
                gate_nll = binary_loss(p["gate_probability"], d)[1]
                comp = -math.log(p["composition_probabilities"][i]) if d else 0.0
                max_nll_error = max(max_nll_error, abs(nll - gate_nll - comp))
                evaluations += 1
            if hist["n_direct"] == 0:
                require(max(abs(x - y / (1 - g[4])) for x, y in zip(p["composition_probabilities"], g[:4])) <= TOL,
                        "Zero-direct composition does not equal its global prior.")
            ell = (4 + 0.5) / (25 + 1)
            require(0 < p["gate_probability"] * ell <= p["gate_probability"], "Auxiliary E exceeds D.")
    require(max_nll_error <= TOL, "Synthetic NLL decomposition failed.")
    fake_rows = []
    for fold in range(7):
        for observer in OBSERVERS:
            for pooling in POOLINGS:
                for rd, rc in itertools.product(RHOS, repeat=2):
                    fake_rows.append({"fold": fold, "observer": observer, "pooling": pooling, "rho_D": rd,
                                      "rho_C": rc, "n": 48, "brier": 0.75, "nll": 1.4})
    _, selected = summarize_and_select(fake_rows)
    require(all(c["rho_D"] == c["rho_C"] == "inf" for c in selected.values()), "Exact-tie rule fails to favor global.")
    scoring_check = synthetic_scoring_check()
    return {"schema_version": "persona-shrinkage-synthetic-checks-v9", "created_utc": now(),
            "invented_counts_only": True, "development_data_read": False, "model_loaded": False,
            "status": "ALL_MATCH", **report, "nll_identity_evaluations": evaluations,
            "maximum_nll_decomposition_error": max_nll_error, "zero_direct_case_checked": True,
            "empty_cell_case_checked": True, "strict_event_nesting_checked": True, "exact_tie_global_checked": True,
            "synthetic_scoring_pipeline": scoring_check}


def make_forecasts(plan, profiles):
    indexed = {(p["observer"], p["setting_id"], p["evidence_stratum"]): p for p in profiles}
    rows = []
    for observer in OBSERVERS:
        for target in plan:
            profile = indexed[observer, target["setting_id"], target["evidence_stratum"]]
            for algorithm in PREDICTORS:
                p = profile["predictors"][algorithm]
                rows.append({"sample_id": target["sample_id"], "observer": observer, "predictor": algorithm,
                             "question_id": target["question_id"], "setting_id": target["setting_id"],
                             "evidence_stratum": target["evidence_stratum"],
                             "category_probabilities": p["category_probabilities"], "gate_probability": p["gate_probability"],
                             "strict_event_probability": p["strict_event_probability"]})
    require(len(rows) == 4032, "Forecast row count differs.")
    return rows


def format_number(value):
    return "—" if value is None else (value if isinstance(value, str) else f"{value:.9f}")


def forecast_note(choices, profiles, coincidences, collapse):
    lines = ["# Experiment 9 frozen forecast note", "",
             "These forecasts use 336 old v8 observations, including 144 former targets now explicitly treated as development.",
             "They were fitted before any v9 target attempt. The new authored questions use familiar instruction wordings.", "",
             "Five-category order: support, reject, withhold, mixed, no_direct. D means category != no_direct.",
             "Strict E also requires answerer_direct among the explicit-limit owners. E and D are distinct.", "",
             "## Selected development parameters", "",
             "Selection uses seven whole-question folds and mean five-category Brier across both observers. These are development scores.", "",
             "| Predictor | Pooling | rho_D | rho_C | CV Brier | Global parameters | Diagonal |",
             "|---|---|---:|---:|---:|---|---|"]
    for a in PREDICTORS:
        c = choices[a]
        lines.append(f"| {a} | {c['pooling']} | {c['rho_D']} | {c['rho_C']} | {format_number(c['cv_brier_mean'])} | {c['global_parameters']} | {c['diagonal_parameters']} |")
    lines += ["", "Infinity means complete global shrinkage for that component. Hswap inherits H parameters and swaps the finished wording profile; it is not selected separately.",
              "H's diagonal is F. Its broader candidate set can only improve the minimum development objective; that is not evidence of prospective success.",
              "Exact floating-point coincidences and tolerance-based coincidences are recorded separately in selection.json.",
              "Global forecast collapse over all 48 profiles: " + ", ".join(f"{a}={collapse[a]}" for a in PREDICTORS) + ".", "",
              "## How to reconstruct a forecast", "",
              "Global g_k=(N_k+0.5)/(N+2.5). Let g_D=1-g_no_direct. Gate r=(n_D+rho_D*n*g_D)/(n+rho_D*n).",
              "Conditional h_k=(n_k+rho_C*n*g_k)/(n_D+rho_C*n*g_D). Return p_k=r*h_k and p_no_direct=1-r.",
              "The local empirical gate weight is 1/(1+rho_D); its conditional-composition counterpart is n_D/(n_D+rho_C*n*g_D).",
              "The latter varies with the observed direct count. Both are zero under complete corresponding shrinkage; empty cells fall back to G.",
              "The conditional prior mass is rho_C*n*g_D, which is essential to the exact H=F diagonal identity.",
              "For G/H only, ell=(M_E+0.5)/(N_D+1), and p_E=r*ell. This auxiliary uses pooled limit propensity, without E-specific selection.", "",
              "## Fixed worked example: eval_neutral_instruction_p0", "",
              "This example setting was fixed before selection or target outcomes. Every stratum and both observer branches are shown.",
              "Tables are rounded for reading; JSON/JSONL artifacts retain full precision."]
    for observer in OBSERVERS:
        for stratum in STRATA:
            profile = next(p for p in profiles if (p["observer"], p["setting_id"], p["evidence_stratum"]) == (observer, EXAMPLE, stratum))
            lines += ["", f"### {observer} / {stratum}", "",
                      "Global g = " + ", ".join(format_number(v) for v in profile["global_probabilities"])
                      + "; pooled ell = " + format_number(profile["pooled_limit_probability"]) + ".", "",
                      "| Predictor | p_D | h_support | h_reject | h_withhold | h_mixed | p_E |",
                      "|---|---:|---:|---:|---:|---:|---:|"]
            for a in PREDICTORS:
                p = profile["predictors"][a]
                values = [p["gate_probability"], *p["composition_probabilities"], p["strict_event_probability"]]
                lines.append("| " + a + " | " + " | ".join(format_number(v) for v in values) + " |")
            lines += ["", "| Predictor | p_support | p_reject | p_withhold | p_mixed | p_no_direct |",
                      "|---|---:|---:|---:|---:|---:|"]
            for a in PREDICTORS:
                lines.append("| " + a + " | " + " | ".join(format_number(v) for v in profile["predictors"][a]["category_probabilities"]) + " |")
            lines += ["", "| Predictor | Pool n | Direct n | Gate empirical weight | Composition empirical weight | Gate prior mass | Composition prior mass |",
                      "|---|---:|---:|---:|---:|---:|---:|"]
            for a in PREDICTORS:
                w = profile["effective_weights"][a]
                vals = [w["pool_n"], w["pool_n_direct"], w["gate_empirical_weight"], w["composition_empirical_weight"],
                        "inf" if w["gate_prior_mass"] is None else w["gate_prior_mass"],
                        "inf" if w["composition_prior_mass"] is None else w["composition_prior_mass"]]
                lines.append("| " + a + " | " + " | ".join(format_number(v) for v in vals) + " |")
    lines += ["", "## Scope", "",
              "This is an observable answer-profile forecast on an authored local benchmark, not an inference about hidden states, personhood, or general language-task performance.",
              "All five categories, length-stopped responses, and observer disagreements remain in evaluation. No outcomes were used to choose this example.", ""]
    return "\n".join(lines)


def freeze():
    _, settings = check_config()
    design = verify_design_lock()
    require(not (ROOT / "predictions").exists(), "Preserve existing forecast directory/attempt; no overwrite or resume.")
    require(not (ROOT / "FORECAST_NOTE.md").exists(), "Preserve existing forecast note.")
    assert_targets_absent()
    records, labels = load_development(settings)
    plan = verify_plan(settings, records)
    input_hashes = dict(design["input_hashes"]) | {"design_lock.json": digest(ROOT / "design_lock.json")}
    cv_rows, folds = run_cv(records, labels, settings)
    summary, choices = summarize_and_select(cv_rows)
    full = {o: build_counts(records, labels[o], settings) for o in OBSERVERS}
    profiles = build_profiles(full, choices, settings)
    coincidences, collapse = coincidence_records(profiles)
    identity = math_identity_report(list(full.values()) + [b for f in folds for b in f["observers"].values()])
    nesting = []
    for a in ("G", "F", "H_gate", "H_content"):
        require(choices["H"]["minimum_cv_brier_mean"] <= choices[a]["minimum_cv_brier_mean"] + TOL, "CV candidate nesting failed.")
        require(choices["H"]["cv_brier_mean"] <= choices[a]["cv_brier_mean"] + 2 * TOL, "Selected CV nesting outside tie tolerance.")
        nesting.append({"restricted_algorithm": a, "H_minimum": choices["H"]["minimum_cv_brier_mean"],
                        "restricted_minimum": choices[a]["minimum_cv_brier_mean"],
                        "H_selected": choices["H"]["cv_brier_mean"], "restricted_selected": choices[a]["cv_brier_mean"], "passes": True})
    forecasts = make_forecasts(plan, profiles)
    max_e_excess = max(r["strict_event_probability"] - r["gate_probability"] for r in forecasts if r["strict_event_probability"] is not None)
    require(max_e_excess <= TOL, "Strict-E forecast exceeds directness.")
    counts_obj = {"schema_version": "persona-shrinkage-counts-v9", "category_order": list(CATEGORIES), "full_fit": full, "folds": folds}
    selection = {"schema_version": "persona-shrinkage-selection-v9", "created_utc": now(), "category_order": list(CATEGORIES),
                 "observers": list(OBSERVERS), "predictors": list(PREDICTORS), "rho_grid": list(RHOS),
                 "objective": "mean five-category Brier over all held-out records and both observers equally",
                 "tie_tolerance": TOL, "flat_tie_rule": "stronger rho",
                 "factorized_tie_rule": "fewer finite coordinates, then stronger gate rho, then stronger composition rho",
                 "choices": choices, "coincidences": coincidences, "global_forecast_collapse": collapse,
                 "target_outcomes_read": False}
    certificate = {"schema_version": "persona-shrinkage-identity-certificate-v9", "created_utc": now(),
                   "status": "ALL_MATCH", "target_outcomes_read": False, **identity, "maximum_strict_E_minus_D": max_e_excess,
                   "candidate_nesting": nesting, "synthetic_edge_checks": synthetic_checks(),
                   "interpretation": "Algebraic consistency and candidate nesting, not prospective forecasting success."}
    verify_hashes(input_hashes)
    assert_targets_absent()
    (ROOT / "predictions").mkdir(exist_ok=False)
    write_csv(ROOT / "predictions/cv_scores.csv", cv_rows)
    write_csv(ROOT / "predictions/cv_candidate_summary.csv", summary)
    write_json(ROOT / "predictions/selection.json", selection)
    write_json(ROOT / "predictions/counts.json", counts_obj)
    write_json(ROOT / "predictions/profiles.json", {"schema_version": "persona-shrinkage-profiles-v9", "category_order": list(CATEGORIES), "profiles": profiles})
    write_jsonl(ROOT / "predictions/forecasts.jsonl", forecasts)
    write_json(ROOT / "predictions/identity_certificate.json", certificate)
    with (ROOT / "FORECAST_NOTE.md").open("x", encoding="utf-8") as stream:
        stream.write(forecast_note(choices, profiles, coincidences, collapse))
    verify_hashes(input_hashes)
    assert_targets_absent()
    locked = now()
    require(timestamp(design["locked_utc"]) <= timestamp(locked), "Forecast precedes design lock.")
    output_hashes = {p: digest(ROOT / p) for p in FORECAST_OUTPUTS}
    lock = {"schema_version": "persona-shrinkage-forecast-lock-v9", "locked_utc": locked,
            "design_lock_sha256": input_hashes["design_lock.json"], "target_plan_sha256": input_hashes["data/target_plan.jsonl"],
            "input_hashes": input_hashes, "output_hashes": output_hashes,
            "forecasts_sha256": output_hashes["predictions/forecasts.jsonl"], "forecast_rows": 4032, "profile_rows": 48,
            "expected_target_samples": 288, "observers": list(OBSERVERS), "predictors": list(PREDICTORS),
            "category_order": list(CATEGORIES), "target_attempts_absent": True, "target_outputs_absent": True,
            "target_labels_absent": True}
    write_json(ROOT / "predictions/forecast_lock.json", lock)
    verify_forecast_lock(settings, require_absent=True)
    print(json.dumps({"status": "FORECASTS_LOCKED", "forecast_rows": 4032, "profile_rows": 48,
                      "locked_utc": locked, "forecast_lock_sha256": digest(ROOT / "predictions/forecast_lock.json")}, indent=2))


def verify_forecast_lock(settings, require_absent=False):
    design = verify_design_lock()
    lock = read_json(ROOT / "predictions/forecast_lock.json")
    require(lock["schema_version"] == "persona-shrinkage-forecast-lock-v9", "Unknown forecast lock.")
    require(lock["design_lock_sha256"] == digest(ROOT / "design_lock.json"), "Forecast/design mismatch.")
    expected_inputs = dict(design["input_hashes"]) | {"design_lock.json": digest(ROOT / "design_lock.json")}
    require(lock["input_hashes"] == expected_inputs, "Forecast input inventory differs.")
    require(set(lock["output_hashes"]) == set(FORECAST_OUTPUTS), "Forecast artifact inventory differs.")
    verify_hashes(lock["input_hashes"])
    verify_hashes(lock["output_hashes"])
    require(lock["target_plan_sha256"] == digest(ROOT / "data/target_plan.jsonl")
            and lock["forecasts_sha256"] == digest(ROOT / "predictions/forecasts.jsonl"), "Forecast alias hashes differ.")
    require(lock["forecast_rows"] == 4032 and lock["profile_rows"] == 48 and lock["expected_target_samples"] == 288,
            "Frozen forecast count mismatch.")
    require(lock["observers"] == list(OBSERVERS) and lock["predictors"] == list(PREDICTORS)
            and lock["category_order"] == list(CATEGORIES), "Forecast axes differ.")
    require(all(lock[k] is True for k in ("target_attempts_absent", "target_outputs_absent", "target_labels_absent")), "Unrecorded prospective boundary.")
    require(timestamp(design["locked_utc"]) <= timestamp(lock["locked_utc"]), "Forecast lock precedes design.")
    plan = verify_plan(settings)
    rows = read_jsonl(ROOT / "predictions/forecasts.jsonl")
    indexed = {(r["observer"], r["sample_id"], r["predictor"]): r for r in rows}
    expected_keys = {(o, p["sample_id"], a) for o in OBSERVERS for p in plan for a in PREDICTORS}
    require(len(rows) == len(indexed) == 4032 and set(indexed) == expected_keys, "Forecast Cartesian coverage differs.")
    by_id = {p["sample_id"]: p for p in plan}
    for r in rows:
        require(all(r[k] == by_id[r["sample_id"]][k] for k in ("question_id", "setting_id", "evidence_stratum")), "Forecast target metadata mismatch.")
        check_vector(r["category_probabilities"])
        require(abs(r["gate_probability"] - (1 - r["category_probabilities"][4])) <= TOL, "Forecast D/category mismatch.")
        e = r["strict_event_probability"]
        if r["predictor"] in ("G", "H"):
            require(e is not None and 0 < e <= r["gate_probability"] < 1, "Invalid strict-E forecast.")
        else:
            require(e is None, "Unspecified strict-E forecast.")
    if require_absent:
        assert_targets_absent()
    return design, lock, plan, indexed


def verify_target_run(design, forecast_lock, plan):
    require(not (ROOT / "metadata/target_failure.json").exists(), "A failed target attempt cannot be scored as a completed study.")
    audit = read_json(ROOT / "audits/forecast.json")
    require(audit["status"] == "ALL_MATCH" and audit["failures"] == [] and audit["assertions"] > 0,
            "A passing independent forecast audit is required.")
    expected_sources = dict(forecast_lock["input_hashes"]) | dict(forecast_lock["output_hashes"])
    expected_sources["predictions/forecast_lock.json"] = digest(ROOT / "predictions/forecast_lock.json")
    require(set(expected_sources) <= set(audit["input_hashes"]), "Forecast audit omitted frozen inputs.")
    verify_hashes(audit["input_hashes"])
    require(audit["design_lock_sha256"] == digest(ROOT / "design_lock.json")
            and audit["forecast_lock_sha256"] == digest(ROOT / "predictions/forecast_lock.json"), "Audit lock identities differ.")
    expected_sources["audits/forecast.json"] = digest(ROOT / "audits/forecast.json")
    meta = read_json(ROOT / "metadata/target.json")
    marker = read_json(ROOT / "metadata/target_attempt.json")
    require(meta["schema_version"] == "persona-shrinkage-pilot-v9" and meta["phase"] == "target"
            and meta["status"] == "complete" and meta["generation_count"] == meta["expected_samples"] == 288,
            "Only the complete 288-output target is eligible for scoring.")
    require(marker["schema_version"] == "persona-shrinkage-target-attempt-v9" and marker["status"] == "started"
            and marker["expected_target_samples"] == 288 and marker["retry_or_resume_allowed"] is False,
            "Immutable one-attempt marker is missing or differs.")
    aliases = {"design_lock_sha256": digest(ROOT / "design_lock.json"),
               "forecast_lock_sha256": digest(ROOT / "predictions/forecast_lock.json"),
               "forecast_audit_sha256": digest(ROOT / "audits/forecast.json"),
               "target_plan_sha256": digest(ROOT / "data/target_plan.jsonl")}
    for field, value in aliases.items():
        require(meta[field] == marker[field] == value, f"Target boundary hash differs: {field}")
    require(meta["attempt_marker_sha256"] == digest(ROOT / "metadata/target_attempt.json"), "Attempt marker changed.")
    require(meta["created_utc"] == marker["created_utc"], "Target start timestamps differ.")
    require(meta["frozen_source_hashes"] == marker["frozen_source_hashes"] == expected_sources, "Target source inventory/hash differs.")
    verify_hashes(expected_sources)
    snapshot_path = ROOT / "source_snapshots/target/SNAPSHOT_MANIFEST.json"
    require(meta["source_snapshot_manifest_sha256"] == digest(snapshot_path), "Source snapshot manifest changed.")
    snapshot = read_json(snapshot_path)
    require(snapshot["files"] == expected_sources, "Source snapshot files differ.")
    for relative, expected in snapshot["files"].items():
        require(digest(safe_path("source_snapshots/target/" + relative)) == expected, f"Source snapshot changed: {relative}")
    chronology = [design["locked_utc"], forecast_lock["locked_utc"], audit["audited_utc"], marker["created_utc"],
                  snapshot["created_utc"], meta["inference_started_utc"], meta["completed_utc"]]
    require(all(timestamp(a) <= timestamp(b) for a, b in zip(chronology, chronology[1:])), "Target generation chronology differs.")
    require(meta["retry_or_resume_performed"] is False and meta["internal_states_collected"] is False
            and meta["support_text_used_in_prompts"] is False and meta["each_question_starts_fresh_chat"] is True,
            "Generation protocol declarations differ.")
    fixed_runtime = {"device": "cpu", "dtype": "torch.float32", "attention_implementation": "eager",
                     "threads": 4, "interop_threads": 1, "max_new_tokens": 96, "temperature": 0.8,
                     "top_p": 0.95, "top_k": 0, "batch_size": 8, "unique_streams": 48}
    for key, value in fixed_runtime.items():
        require(meta[key] == value, f"Generation runtime changed: {key}")
    targets = read_jsonl(ROOT / "data/target_generations.jsonl")
    require(meta["generations_sha256"] == digest(ROOT / "data/target_generations.jsonl"), "Generated outputs changed.")
    require(len(targets) == len({r["sample_id"] for r in targets}) == 288, "Target outputs are incomplete or duplicated.")
    eos = set(meta["eos_token_ids"])
    require(bool(eos), "EOS token inventory missing.")
    for expected, row in zip(plan, targets):
        require(set(row) == set(expected) | {"completion", "generated_ids", "generated_tokens", "stop_reason"}, "Output field inventory differs.")
        require(all(row[k] == v for k, v in expected.items()), "Generation altered a target-plan field or order.")
        tokens = row["generated_ids"]
        require(isinstance(tokens, list) and all(type(t) is int and t >= 0 for t in tokens), "Invalid generated token IDs.")
        require(row["generated_tokens"] == len(tokens) and 1 <= len(tokens) <= 96, "Invalid generated token count.")
        require(isinstance(row["completion"], str) and row["stop_reason"] in ("eos", "length"), "Invalid generation output.")
        require((row["stop_reason"] == "eos") == (tokens[-1] in eos), "Stop reason and EOS disagree.")
        require(not any(t in eos for t in tokens[:-1]), "Generation continued after EOS.")
        require(row["stop_reason"] == "eos" or len(tokens) == 96, "Premature length stop.")
    require(meta["eos_count"] == sum(r["stop_reason"] == "eos" for r in targets)
            and meta["length_count"] == sum(r["stop_reason"] == "length" for r in targets), "Stop-reason totals differ.")
    events = read_jsonl(ROOT / "metadata/target_events.jsonl")
    expected_names = ["attempt_started", "source_snapshot_verified", "model_loaded"] + ["batch_completed"] * 36 + ["complete"]
    require([e["event"] for e in events] == expected_names, "Target event log incomplete or unexpected.")
    require([e["completed_rows"] for e in events] == [0, 0, 0] + list(range(8, 289, 8)) + [288], "Target batch history differs.")
    require(all(timestamp(a["utc"]) <= timestamp(b["utc"]) for a, b in zip(events, events[1:])), "Target event times are not monotonic.")
    require(events[0]["utc"] == marker["created_utc"] and events[2]["utc"] == meta["inference_started_utc"], "Event/metadata start mismatch.")
    require(events[-1]["generations_sha256"] == meta["generations_sha256"], "Completion event output hash mismatch.")
    require(timestamp(meta["completed_utc"]) <= timestamp(events[-1]["utc"]), "Completion event precedes metadata completion.")
    return targets, meta, marker, audit, events


def verify_observer(observer, targets, target_meta):
    folder = ROOT / "observers/target" / observer
    lock = read_json(folder / "observation_lock.json")
    require(lock["schema_version"] == "persona-shrinkage-observation-v9" and lock["stage"] == "target"
            and lock["observer"] == observer and lock["label_rows"] == 288, "Target observation lock inventory differs.")
    for key, filename in OBSERVATION_FILES.items():
        require(digest(folder / filename) == lock[key], f"Changed target observation artifact: {observer}/{filename}")
    require(digest(folder / "rubric.md") == digest(ROOT / "rubric.md"), "Target observer rubric changed.")
    require(read_jsonl(folder / "discovery_blind.jsonl") == [], "Target discovery input must be empty.")
    source = {r["sample_id"]: r for r in targets}
    blinded = read_jsonl(folder / "validation_blind.jsonl")
    require(len(blinded) == len({r["sample_id"] for r in blinded}) == 288 and {r["sample_id"] for r in blinded} == set(source),
            "Blind target coverage differs.")
    expected_order = sorted(source, key=lambda sid: hashlib.sha256(f"persona-shrinkage-v9|blind|target|{observer}|{sid}".encode()).hexdigest())
    require([r["sample_id"] for r in blinded] == expected_order, "Observer blind shuffle differs.")
    for row in blinded:
        require(set(row) == BLIND_FIELDS and all(row[k] == source[row["sample_id"]][k] for k in BLIND_FIELDS), "Blind content differs or exposes extra fields.")
    raw = read_jsonl(folder / "labels.jsonl")
    labels = {r["sample_id"]: r for r in raw}
    require(len(raw) == len(labels) == 288 and set(labels) == set(source), "Target labels incomplete/duplicated.")
    unique_triples = {}
    for sid, label in labels.items():
        validate_label(label)
        triple = tuple(source[sid][k] for k in ("requested_answerer", "question", "completion"))
        require(triple not in unique_triples or unique_triples[triple] == six_codes(label), "Identical full triple has inconsistent codes.")
        unique_triples[triple] = six_codes(label)
    require(timestamp(target_meta["completed_utc"]) <= timestamp(lock["locked_utc"]) <= timestamp(now()), "Annotation lock chronology differs.")
    return labels, lock


def per_sample_scores(targets, labels_by_observer, forecasts):
    rows = []
    for observer in OBSERVERS:
        for target in targets:
            label = labels_by_observer[observer][target["sample_id"]]
            observed, d, e = category(label), direct(label), strict_event(label)
            base = {k: target[k] for k in META_FIELDS} | {
                "observer": observer, "observed_category": observed, "direct_event": d, "strict_event": e,
                "stop_reason": target["stop_reason"], "generated_tokens": target["generated_tokens"]}
            for algorithm in PREDICTORS:
                forecast = forecasts[observer, target["sample_id"], algorithm]
                p, r, pe = forecast["category_probabilities"], forecast["gate_probability"], forecast["strict_event_probability"]
                cb, cn = categorical_loss(p, observed)
                db, dn = binary_loss(r, d)
                conditional = -math.log(p[CATEGORIES.index(observed)] / r) if d else None
                contribution = conditional if d else 0.0
                require(abs(cn - dn - contribution) <= TOL, "Per-sample NLL decomposition failed.")
                eb, en = binary_loss(pe, e) if pe is not None else (None, None)
                rows.append(base | {"predictor": algorithm, "category_probabilities": p, "gate_probability": r,
                    "strict_event_probability": pe, "categorical_brier": cb, "categorical_nll": cn,
                    "gate_brier": db, "gate_nll": dn, "composition_nll_contribution": contribution,
                    "conditional_composition_nll": conditional, "strict_event_brier": eb, "strict_event_nll": en})
            rows.append(base | {"predictor": "E0", "category_probabilities": None, "gate_probability": None,
                "strict_event_probability": 0.0, "categorical_brier": None, "categorical_nll": None,
                "gate_brier": None, "gate_nll": None, "composition_nll_contribution": None,
                "conditional_composition_nll": None, "strict_event_brier": float(e), "strict_event_nll": None})
    require(len(rows) == 4608, "Per-sample score inventory differs.")
    return rows


LOSS_FIELDS = (("categorical", "brier", "categorical_brier"), ("categorical", "nll", "categorical_nll"),
               ("gate", "brier", "gate_brier"), ("gate", "nll", "gate_nll"),
               ("strict_event", "brier", "strict_event_brier"), ("strict_event", "nll", "strict_event_nll"))


def scalar_scores(wide):
    rows = []
    for row in wide:
        for outcome, metric, field in LOSS_FIELDS:
            if row[field] is not None:
                rows.append({k: row[k] for k in META_FIELDS} | {"observer": row["observer"], "predictor": row["predictor"],
                    "outcome": outcome, "metric": metric, "score": row[field]})
    require(len(rows) == 19008, "Scalar score count differs.")
    return rows


def paired_scores(wide):
    indexed = {(r["observer"], r["sample_id"], r["predictor"]): r for r in wide}
    pairs = []
    for row in wide:
        if row["predictor"] != "G":
            continue
        for left, right in CONTRASTS:
            for outcome, metric, field in LOSS_FIELDS[:4]:
                a, b = indexed[row["observer"], row["sample_id"], left], indexed[row["observer"], row["sample_id"], right]
                pairs.append({k: row[k] for k in META_FIELDS} | {"observer": row["observer"], "contrast": left + "-" + right,
                    "left": left, "right": right, "outcome": outcome, "metric": metric,
                    "co_primary": (left, right) in PRIMARY and outcome == "categorical" and metric == "brier",
                    "difference": a[field] - b[field]})
        for outcome, metric, field in LOSS_FIELDS[4:]:
            a, b = indexed[row["observer"], row["sample_id"], "H"], indexed[row["observer"], row["sample_id"], "G"]
            pairs.append({k: row[k] for k in META_FIELDS} | {"observer": row["observer"], "contrast": "H-G", "left": "H", "right": "G",
                "outcome": outcome, "metric": metric, "co_primary": False, "difference": a[field] - b[field]})
    require(len(pairs) == 19584, "Paired contrast inventory differs.")
    return pairs


def with_ab_means(rows, value_field, key_fields):
    grouped = defaultdict(dict)
    for row in rows:
        key = tuple(row[k] for k in key_fields)
        require(row["observer"] not in grouped[key], "Duplicate observer scalar.")
        grouped[key][row["observer"]] = row
    means = []
    for key in sorted(grouped):
        pair = grouped[key]
        require(set(pair) == set(OBSERVERS), "Missing observer branch in paired A/B mean.")
        a, b = (pair[o] for o in OBSERVERS)
        require(all(a[k] == b[k] for k in a if k not in ("observer", value_field)), "A/B metadata differs.")
        means.append(a | {"observer": "ab_mean", value_field: math.fsum((a[value_field], b[value_field])) / 2})
    return rows + means


def stats(values, signed=False):
    require(values and all(math.isfinite(x) for x in values), "Finite nonempty aggregate required.")
    result = {"n": len(values), "mean": math.fsum(values) / len(values), "median": statistics.median(values),
              "min": min(values), "max": max(values)}
    if signed:
        result |= {"n_negative": sum(x < -TOL for x in values), "n_zero": sum(abs(x) <= TOL for x in values),
                   "n_positive": sum(x > TOL for x in values), "sign_zero_tolerance": TOL}
    return result


def aggregate(rows, keys, value_field, signed=False):
    grouped = defaultdict(list)
    for row in rows:
        grouped[tuple(row[k] for k in keys)].append(row[value_field])
    return [dict(zip(keys, key)) | stats(grouped[key], signed) for key in sorted(grouped)]


def score_tables(wide, pairs):
    scalars = scalar_scores(wide)
    all_scalars = with_ab_means(scalars, "score", ("sample_id", "predictor", "outcome", "metric"))
    all_pairs = with_ab_means(pairs, "difference", ("sample_id", "contrast", "outcome", "metric"))
    score_keys = ("observer", "predictor", "outcome", "metric")
    pair_keys = ("observer", "contrast", "left", "right", "outcome", "metric", "co_primary")
    tables = {"score_summary": aggregate(all_scalars, score_keys, "score"),
              "paired_summary": aggregate(all_pairs, pair_keys, "difference", True)}
    for group, extra in GROUPS.items():
        tables[f"score_{group}_values"] = aggregate(all_scalars, score_keys + extra, "score")
        values = aggregate(all_pairs, pair_keys + extra, "difference", True)
        tables[f"paired_{group}_values"] = values
        blocks = aggregate(values, pair_keys, "mean", True)
        require(all(r["n"] == GROUP_SIZES[group] for r in blocks), f"Unexpected {group} block count.")
        means = {tuple(r[k] for k in pair_keys): r["mean"] for r in tables["paired_summary"]}
        require(all(abs(r["mean"] - means[tuple(r[k] for k in pair_keys)]) <= TOL for r in blocks),
                f"Equal-{group} and target-level weights differ.")
        tables[f"paired_{group}_summary"] = blocks
    return tables, scalars


def nll_decomposition(wide):
    rows = []
    for observer in (*OBSERVERS, "ab_mean"):
        for predictor in PREDICTORS:
            subset = [r for r in wide if r["predictor"] == predictor and (observer == "ab_mean" or r["observer"] == observer)]
            n, nd = len(subset), sum(r["direct_event"] for r in subset)
            categorical = math.fsum(r["categorical_nll"] for r in subset) / n
            gate = math.fsum(r["gate_nll"] for r in subset) / n
            total_conditional = math.fsum(r["composition_nll_contribution"] for r in subset)
            composition = total_conditional / n
            conditional_mean = total_conditional / nd if nd else None
            residual = categorical - gate - composition
            require(abs(residual) <= TOL, "Aggregated NLL decomposition failed.")
            rows.append({"observer": observer, "predictor": predictor, "n_targets": 288, "n_label_records": n,
                "n_direct_labels": nd, "direct_fraction": nd / n, "categorical_nll_mean": categorical,
                "gate_nll_mean": gate, "composition_nll_contribution_mean": composition,
                "conditional_composition_nll_mean": conditional_mean, "identity_residual": residual,
                "maximum_per_sample_identity_residual": max(abs(r["categorical_nll"] - r["gate_nll"] - r["composition_nll_contribution"]) for r in subset)})
    return rows


def outcome_count_rows(targets, labels):
    result = []
    for observer in OBSERVERS:
        groups = [("global", "all", targets)]
        for name, keys in GROUPS.items():
            values = defaultdict(list)
            for target in targets:
                values[tuple(target[k] for k in keys)].append(target)
            groups.extend((name, "|".join(str(x) for x in key), rows) for key, rows in sorted(values.items()))
        for group, group_id, rows in groups:
            h = histogram(rows, labels[observer])
            result.append({"observer": observer, "group": group, "group_id": group_id, "n": len(rows),
                           "n_direct": h["n_direct"], "n_strict_event": h["n_strict_event"],
                           **{f"n_{k}": h["category_counts"][i] for i, k in enumerate(CATEGORIES)},
                           "n_eos": sum(r["stop_reason"] == "eos" for r in rows),
                           "n_length": sum(r["stop_reason"] == "length" for r in rows)})
    return result


def observer_agreement(targets, labels):
    rows = []
    for target in targets:
        sid = target["sample_id"]
        a, b = (labels[o][sid] for o in OBSERVERS)
        rows.append({k: target[k] for k in META_FIELDS} | {
            "category_a": category(a), "category_b": category(b), "category_agrees": category(a) == category(b),
            "direct_event_a": direct(a), "direct_event_b": direct(b), "direct_event_agrees": direct(a) == direct(b),
            "strict_event_a": strict_event(a), "strict_event_b": strict_event(b), "strict_event_agrees": strict_event(a) == strict_event(b),
            "six_codes_agree": six_codes(a) == six_codes(b)})
    summary = {"n_targets": 288, "same_foundation_model_and_rubric": True, "independent_model_replications": False}
    for field in ("category_agrees", "direct_event_agrees", "strict_event_agrees", "six_codes_agree"):
        summary[field] = {"n": sum(r[field] for r in rows), "fraction": sum(r[field] for r in rows) / len(rows)}
    summary["category_confusion_matrix"] = [[sum(r["category_a"] == a and r["category_b"] == b for r in rows) for b in CATEGORIES] for a in CATEGORIES]
    summary["category_order"] = list(CATEGORIES)
    for event in ("direct_event", "strict_event"):
        summary[event + "_counts"] = {"both_positive": sum(r[event + "_a"] and r[event + "_b"] for r in rows),
            "a_only": sum(r[event + "_a"] and not r[event + "_b"] for r in rows),
            "b_only": sum(not r[event + "_a"] and r[event + "_b"] for r in rows),
            "both_negative": sum(not r[event + "_a"] and not r[event + "_b"] for r in rows)}
    disagreements = [r for r in rows if not r["six_codes_agree"]]
    return rows, summary, disagreements


def sign(value):
    return "negative" if value < -TOL else ("positive" if value > TOL else "zero")


def primary_criterion(paired_summary):
    selected = [r for r in paired_summary if r["co_primary"]]
    require(len(selected) == 6, "Expected two primary comparisons across three score branches.")
    values = {r["observer"] + ":" + r["contrast"]: {"difference": r["mean"], "sign": sign(r["mean"])} for r in selected}
    mean_negative = all(sign(r["mean"]) == "negative" for r in selected if r["observer"] == "ab_mean")
    branch_negative = all(sign(r["mean"]) == "negative" for r in selected if r["observer"] in OBSERVERS)
    branch_signs = [sign(r["mean"]) for r in selected if r["observer"] in OBSERVERS]
    return {"criterion": "Both A/B-mean five-category Brier contrasts H-G and H-F are negative with tolerance 1e-12.",
            "descriptive_pilot_support": mean_negative, "all_four_branch_comparison_signs_agree": len(set(branch_signs)) == 1,
            "all_four_branch_comparisons_negative": branch_negative, "values": values,
            "sign_zero_tolerance": TOL, "significance_claim": False, "population_confidence_intervals": False}


def synthetic_scoring_check():
    """Check complete scoring/aggregation dimensions on entirely invented rows."""
    targets, labels, forecasts = [], {o: {} for o in OBSERVERS}, {}
    g = [0.24, 0.14, 0.09, 0.05, 0.48]
    hist = {"n": 8, "n_direct": 5, "category_counts": [3, 1, 1, 0, 3]}
    for family, wording, stratum, q, rep in itertools.product(FAMILIES, (0, 1), STRATA, range(6), (0, 1)):
        i = len(targets)
        sid = f"synthetic_{i:03d}"
        targets.append({"sample_id": sid, "question_id": f"synthetic_{stratum}_{q}",
                        "question_name": f"invented_{stratum}_{q}",
                        "setting_id": f"eval_{family}_instruction_p{wording}", "family": family,
                        "paraphrase_id": wording, "evidence_stratum": stratum, "replicate_id": rep,
                        "seed": 1000 + 12 * STRATA.index(stratum) + 2 * q + rep,
                        "stop_reason": "length" if i % 4 == 0 else "eos", "generated_tokens": 96 if i % 4 == 0 else 12})
        for oi, observer in enumerate(OBSERVERS):
            cat = CATEGORIES[(i + (oi if i % 7 == 0 else 0)) % 5]
            judgment = "none" if cat == "no_direct" else cat
            label = {"sample_id": sid, "answerer_answer_mode": "none" if cat == "no_direct" else "direct",
                     "answerer_judgment": judgment,
                     "answerer_stance": "none" if cat == "no_direct" else ("mixed" if cat == "mixed" else "tentative" if cat == "withhold" else "decisive"),
                     "limit_owners": ["answerer_direct"] if cat != "no_direct" and i % 3 == 0 else [],
                     "other_answer": False, "character_description": False, "note": "Invented semantic code for a synthetic arithmetic check."}
            validate_label(label)
            labels[observer][sid] = label
            for ai, algorithm in enumerate(PREDICTORS):
                rd, rc = ("inf", "inf") if algorithm == "G" else (RHOS[ai % 4], RHOS[(ai + 1) % 4])
                p = factorized(hist, g, rd, rc)[0]
                if algorithm in ("G", "H"):
                    p["strict_event_probability"] = p["gate_probability"] * 0.2
                forecasts[observer, sid, algorithm] = p
    wide = per_sample_scores(targets, labels, forecasts)
    paired = paired_scores(wide)
    tables, scalars = score_tables(wide, paired)
    decomposition = nll_decomposition(wide)
    first = wide[0]
    expected = math.fsum((p - (i == 0)) ** 2 for i, p in enumerate(g))
    require(abs(first["categorical_brier"] - expected) <= TOL, "Synthetic known-outcome Brier differs.")
    summaries = {(r["observer"], r["predictor"], r["outcome"], r["metric"]): r["mean"] for r in tables["score_summary"]}
    for predictor, outcome, metric in {(r["predictor"], r["outcome"], r["metric"]) for r in tables["score_summary"]}:
        expected_mean = math.fsum(summaries[o, predictor, outcome, metric] for o in OBSERVERS) / 2
        require(abs(summaries["ab_mean", predictor, outcome, metric] - expected_mean) <= TOL, "A/B losses were not averaged correctly.")
    require(all(r["category_probabilities"] is None and r["strict_event_nll"] is None for r in wide if r["predictor"] == "E0"),
            "Synthetic zero baseline acquired an unspecified score.")
    primary_criterion(tables["paired_summary"])
    return {"invented_target_rows": len(targets), "per_sample_score_rows": len(wide), "scalar_score_rows": len(scalars),
            "paired_difference_rows": len(paired), "score_summary_rows": len(tables["score_summary"]),
            "paired_summary_rows": len(tables["paired_summary"]), "nll_decomposition_rows": len(decomposition),
            "all_fixed_block_counts_verified": True, "paired_AB_mean_verified": True, "E0_brier_only_verified": True}


def score():
    _, settings = check_config()
    require(not (ROOT / "results").exists(), "Preserve existing scoring directory/attempt; no overwrite or resume.")
    design, forecast_lock, plan, forecasts = verify_forecast_lock(settings)
    targets, meta, marker, audit, events = verify_target_run(design, forecast_lock, plan)
    export = read_json(ROOT / "observer_exports/target.json")
    require(export["schema_version"] == "persona-shrinkage-blind-export-v9", "Unknown observer export schema.")
    verify_hashes(export["input_hashes"])
    require(set(export["fields"]) == BLIND_FIELDS and set(export["exports"]) == set(OBSERVERS), "Blind export fields/branches differ.")
    labels, observation_locks = {}, {}
    for observer in OBSERVERS:
        labels[observer], observation_locks[observer] = verify_observer(observer, targets, meta)
        e = export["exports"][observer]
        require(e["rows"] == 288, "Blind export row count differs.")
        for field in ("rubric_sha256", "validation_blind_sha256", "discovery_blind_sha256"):
            require(e[field] == observation_locks[observer][field], "Blind export/observation lock hash mismatch.")
    inputs = dict(meta["frozen_source_hashes"])
    extra_paths = ["metadata/target.json", "metadata/target_attempt.json", "metadata/target_events.jsonl",
                   "data/target_generations.jsonl", "source_snapshots/target/SNAPSHOT_MANIFEST.json", "observer_exports/target.json"]
    for observer in OBSERVERS:
        extra_paths.extend(f"observers/target/{observer}/{p}" for p in (*OBSERVATION_FILES.values(), "observation_lock.json"))
    inputs |= {p: digest(ROOT / p) for p in extra_paths}
    wide = per_sample_scores(targets, labels, forecasts)
    paired = paired_scores(wide)
    tables, scalars = score_tables(wide, paired)
    tables["nll_decomposition"] = nll_decomposition(wide)
    tables["outcome_counts"] = outcome_count_rows(targets, labels)
    agreement, agreement_summary, disagreements = observer_agreement(targets, labels)
    tables["observer_agreement"] = agreement
    tables["observer_disagreements"] = disagreements
    criterion = primary_criterion(tables["paired_summary"])
    scoring_started = now()
    chronology = {"schema_version": "persona-shrinkage-scoring-integrity-v9", "status": "ALL_MATCH",
        "scored_utc": scoring_started, "design_locked_utc": design["locked_utc"],
        "forecast_locked_utc": forecast_lock["locked_utc"], "forecast_audited_utc": audit["audited_utc"],
        "attempt_started_utc": marker["created_utc"], "inference_started_utc": meta["inference_started_utc"],
        "generation_completed_utc": meta["completed_utc"], "event_log_completed_utc": events[-1]["utc"],
        "observation_locked_utc": {o: observation_locks[o]["locked_utc"] for o in OBSERVERS},
        "design_lock_sha256": digest(ROOT / "design_lock.json"), "forecast_lock_sha256": digest(ROOT / "predictions/forecast_lock.json"),
        "forecast_audit_sha256": digest(ROOT / "audits/forecast.json"), "input_hashes": inputs,
        "target_samples": 288, "forecast_rows": 4032, "per_sample_score_rows": len(wide),
        "scalar_score_rows": len(scalars), "paired_difference_rows": len(paired),
        "every_plan_field_preserved": True, "all_length_stops_retained": True, "all_no_direct_retained": True,
        "observation_adjudication_performed": False, "selection_refitted_on_targets": False,
        "generation_attempts": 1, "retry_or_resume_performed": False,
        "note": "Local hash/chronology audit trail, not an independently certified timestamp or public preregistration."}
    require(all(timestamp(v) <= timestamp(scoring_started) for v in chronology["observation_locked_utc"].values()), "Scoring precedes annotation locks.")
    verify_hashes(inputs)
    output = ROOT / "results"
    output.mkdir(exist_ok=False)
    write_jsonl(output / "per_sample_scores.jsonl", wide)
    write_jsonl(output / "scalar_scores.jsonl", scalars)
    write_jsonl(output / "paired_differences.jsonl", paired)
    write_csv(output / "per_sample_scores.csv", wide)
    write_csv(output / "paired_differences.csv", paired)
    write_json(output / "tables.json", tables)
    for name, rows in tables.items():
        write_csv(output / f"{name}.csv", rows)
    write_json(output / "agreement_summary.json", agreement_summary)
    write_json(output / "primary_criterion.json", criterion)
    write_json(output / "scoring_integrity.json", chronology)
    verify_hashes(inputs)
    result_hashes = {p.relative_to(ROOT).as_posix(): digest(p) for p in sorted(output.iterdir()) if p.is_file()}
    write_json(output / "score_lock.json", {"schema_version": "persona-shrinkage-score-lock-v9", "locked_utc": now(),
               "input_hashes": inputs, "output_hashes": result_hashes, "design_lock_sha256": chronology["design_lock_sha256"],
               "forecast_lock_sha256": chronology["forecast_lock_sha256"], "target_samples": 288,
               "per_sample_score_rows": len(wide), "paired_difference_rows": len(paired)})
    print(json.dumps({"status": "SCORES_LOCKED", "target_samples": 288, "per_sample_score_rows": len(wide),
                      "paired_difference_rows": len(paired), "primary_criterion": criterion,
                      "score_lock_sha256": digest(output / "score_lock.json")}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    synthetic = sub.add_parser("synthetic", help="Verify algebra on invented counts, without reading development labels.")
    synthetic.add_argument("--output", help="Optional exclusive project-relative JSON report path (normally setup/...).")
    sub.add_parser("freeze", help="Select on locked development only and freeze all target forecasts once.")
    sub.add_parser("score", help="Score a complete, audited target and two locked observers once.")
    args = parser.parse_args()
    if args.command == "synthetic":
        report = synthetic_checks()
        report["predictor_source_sha256"] = digest(Path(__file__))
        if args.output:
            require(Path(args.output).parts and Path(args.output).parts[0] == "setup", "Synthetic report must be in setup/.")
            write_json(safe_path(args.output), report)
        print(json.dumps(report, indent=2, allow_nan=False))
    elif args.command == "freeze":
        freeze()
    else:
        score()


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(json.dumps({"status": "REFUSED", "command": sys.argv[1] if len(sys.argv) > 1 else None,
                          "error_type": type(error).__name__, "message": str(error),
                          "existing_artifacts_preserved": True}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(1)

