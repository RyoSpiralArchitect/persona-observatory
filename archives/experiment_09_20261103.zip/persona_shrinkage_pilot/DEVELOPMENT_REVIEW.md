# Pre-lock semantic and provenance review

Root reviewed the full evidence and claim text of all 36 old questions and all
24 new questions before new model generation or hyperparameter selection.
The 28 selected old questions use distinct objects/tasks and do not duplicate a
single underlying scenario across support and former-target phases. Repeated
evidence templates (limited test, concurrent change, controlled support,
controlled contradiction) are intentional and define the four strata.

The seven folds therefore hold out whole semantic question instances across all
settings and seeds. They do not hold out entire evidence templates or broad
domains. No label- or score-dependent regrouping was made.

The new questions use new named tasks/objects and no old exact question text.
All 24 complete assembled questions were reviewed. Each limited item extrapolates
beyond a narrow observation; each confounded item has a concurrent change with
no separating comparison; each supportive/contradictory item bounds its claim
to the controlled comparison's tested conditions. These authored evidence types
are metadata, not a gold label for the model's expressed answer. Observers code
what the model says, including any mistaken or unsupported judgment.

The new bank is authored in English and has 47–60 words of evidence per item.
This is not an independently sampled natural-language population. It expands
the previous collection of small fictional scenarios but retains a recognizable
template structure. Generalization claims must be scoped accordingly.

The source archive, all 174 internal manifest entries, and all four original
annotation locks are verified by prepare_development.py. Selected label objects
are copied unchanged; former v8 targets are now explicitly development data.
No new target output, label, prediction or score existed at this review.
