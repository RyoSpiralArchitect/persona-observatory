# Experiment 9 — observable persona profiles with globally centered shrinkage

This package contains a prospective, output-only forecasting pilot using the
fixed SmolLM2-360M-Instruct revision
`a10cc1512eabd3dde888204e902eca88bddb4951`.

Start with **REPORT_JA.md** or **persona_shrinkage_report_20261103.html** for the
completed findings. The HTML report contains a condition/profile explorer and
all 288 new completions with both observers' labels, and works without external
network requests. **METHODS_JA.md** explains the mathematics and scope in Japanese.
**PROTOCOL.md** is the frozen prospective specification.

## What is in the package

| Path | Contents |
|---|---|
| `study_config.json`, `settings.json`, `question_bank.json` | Fixed study, six familiar instructions, 24 new fictional questions |
| `provenance/source_v8.zip` | Exact immutable previous deliverable, including original data and annotation locks |
| `development/` | Balanced 336-response subset; old v8 targets explicitly reused as development |
| `development_manifest.json` | Selection, original locks, hashes, all seven question-blocked folds |
| `design_lock.json`, `preflight.json` | Pre-selection source/input and tokenizer-only records |
| `predictions/` | CV candidates, chosen strengths, count codebook, profiles, every forecast, forecast lock |
| `FORECAST_NOTE.md` | Parameters and fixed neutral-p0 example written before target generation |
| `data/target_plan.jsonl` | 288 frozen prompt/seed jobs |
| `data/target_generations.jsonl` | Complete generated strings and token IDs, with every plan field retained |
| `metadata/` | Single attempt marker, append-only event log, complete run metadata |
| `source_snapshots/target/` | Exact copies of sources, development and predictions at target generation |
| `observers/target/` | Two separate blinded exports, frozen semantic labels and annotation notes/locks |
| `results/` | Per-output losses and contrasts, summaries, all blocks, disagreement, NLL decomposition, score lock |
| `audits/` | Independent design, forecast and final recomputations; synthetic check evidence |
| `setup/` | Exact environment/model specifications and restoration scripts/logs |
| `figures/` | Exportable PNG and SVG research figure |
| `FILE_MANIFEST.json` | Size and SHA-256 for every included file except the manifest itself |

The package intentionally excludes model weights, the Python environment,
caches and unused partial download copies. Their public source identity and
checksums are included, so they can be restored. No API credential is needed
for this public model snapshot.

## Programs and execution order

The prediction and scoring implementation is `predict.py`. The independent
auditor is `audit_shrinkage.py`; it imports none of the predictor, runner,
experiment configuration or annotation validator. Subject generation uses
`run_experiment.py` plus the byte-identical v8 `runtime.py`.

The original execution order was:

```text
prepare_development.py
predict.py synthetic --output setup/predict_synthetic_checks.json
audit_shrinkage.py synthetic
run_experiment.py prepare
audit_shrinkage.py design
run_experiment.py lock
predict.py freeze
audit_shrinkage.py forecasts
run_experiment.py generate
[two fresh observer contexts each read and label their assigned blind files]
validate_observation.py target observer_a --lock
validate_observation.py target observer_b --lock
predict.py score
audit_shrinkage.py final
build_report.py
```

Completed forecasts, generation attempts, annotations, scores and audits are
immutable. Their commands refuse to overwrite or silently resume. Do not delete
the completed files to make a command run. Use a separate working copy for any
new experiment, retain the original package, and name the new run distinctly.

After restoring the documented environment and exact model files, a read-only
independent recheck of this completed package can write a separate new audit:

```bash
.venv/bin/python audit_shrinkage.py final --output audits/independent_recheck.json
```

Use a new output filename if that one already exists. The final audit verifies
all forecasts and scores from raw labels as well as chronology and file identity;
it does not repeat subject generation.

Restoration details and exact package versions are in `setup/README.md`,
`setup/requirements.txt`, `setup/pip_freeze.txt`, `environment.json`, and the two
model manifests. Reproducing generation on another processor/software stack may
involve numerical differences even with the same random seeds; the package
preserves the actual sampled token sequences for audit.

## Core interpretation limits

- Development: 28 old questions, 336 outputs, all algorithms receive the same
  balanced pool. New test: 24 questions, 288 outputs.
- Seven predictors: G, F, H_gate, H_content, H, H_evidence, Hswap. Same-strength
  factorization equals flat shrinkage exactly; this is checked before evaluation.
- Five-category Brier is primary. D is observable direct-answer eligibility;
  strict E additionally requires speaker-attributed explicit evidence limitation.
  They are separate outcomes.
- A/B are fresh contexts using the same foundation model and rubric, not two
  humans or independent subject-model replications. The new sample size remains
  288 generated outputs.
- Instruction wording and evidence structures are familiar. This is an authored
  small English benchmark, not a random sample of natural conversation.
- No hidden states, embeddings or hidden reasoning trajectories are observed as
  predictive features in this stage. A behavioral code need not identify a unique
  internal mechanism or stable personality.
- Local hashes and timestamps provide a consistent audit trail. They are not a
  public preregistration or externally certified timestamp.

External references and the primary model card are linked in the report and
METHODS_JA.md. All numerical findings of this study originate in the included
raw data, locked forecasts and independently checked results.
