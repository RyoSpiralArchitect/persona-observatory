"""Independent staged audit: no imports from the implementation under audit."""
from __future__ import annotations
import argparse
import ast
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import itertools
import json
import math
import os
from pathlib import Path
import traceback
import zipfile

ROOT = Path(__file__).resolve().parent
STUDY = "persona-shrinkage-v9"
SOURCE_SHA = "0538ed94a04a2fa5f51195c56b66a4eabeb2ae56c0aa1cddb12787d0db8b77c8"
RUNTIME_SHA = "d164d92a51dfa436a59f330dc91e9977ce6f8b583e7271c0967cb790d37901f1"
RUBRIC_SHA = "7a28b5f7101c3e9de0367c064bec34f60154b7e7a4c9934c4685eff381d601a6"
PREFIX = "persona_topic_budget_pilot/"
OBSERVERS = ("observer_a", "observer_b")
CATEGORIES = ("support", "reject", "withhold", "mixed", "no_direct")
FAMILIES = ("neutral", "cautious", "confident")
STRATA = ("limited", "confounded", "supportive", "contradictory")
ALGORITHMS = ("G", "F", "H_gate", "H_content", "H", "H_evidence", "Hswap")
GRID = ("0.25", "1", "4", "inf")
CONTRASTS = (("H", "G"), ("H", "F"), ("F", "G"), ("H", "H_gate"),
             ("H", "H_content"), ("H", "H_evidence"), ("H", "Hswap"),
             ("H_evidence", "G"))
TIE = 1e-12
NUMERIC_TOLERANCE = 2e-11
SETTING_IDS = tuple(f"eval_{f}_instruction_p{p}" for f in FAMILIES for p in (0, 1))
LABEL_FIELDS = {"sample_id", "answerer_answer_mode", "answerer_judgment",
                "answerer_stance", "limit_owners", "other_answer",
                "character_description", "note"}
BLIND_FIELDS = {"sample_id", "requested_answerer", "question", "completion", "stop_reason"}
LABEL_ENUMS = {"answerer_answer_mode": {"direct", "reported", "both", "none"},
               "answerer_judgment": {"support", "reject", "withhold", "mixed", "none"},
               "answerer_stance": {"decisive", "tentative", "mixed", "none"}}
OWNERS = {"answerer_direct", "answerer_reported", "other", "unclear"}
LOCK_FILES = {"labels_sha256": "labels.jsonl", "rubric_sha256": "rubric.md",
              "observations_sha256": "observations.md",
              "discovery_blind_sha256": "discovery_blind.jsonl",
              "validation_blind_sha256": "validation_blind.jsonl"}
DESIGN_FILES = (
    "PROTOCOL.md", "SCHEMA.md", "study_config.json", "settings.json",
    "question_bank.json", "QUESTION_BANK_REVIEW.md", "DEVELOPMENT_REVIEW.md",
    "prepare_development.py", "development_manifest.json",
    "development/records.jsonl", "development/labels_observer_a.jsonl",
    "development/labels_observer_b.jsonl", "development/source_question_bank.json",
    "provenance/source_v8.zip", "experiment_config.py", "runtime.py",
    "run_experiment.py", "rubric.md", "validate_observation.py", "predict.py",
    "audit_shrinkage.py", "prediction_math_audit.md", "AUDIT_PLAN.md",
    "model_manifest.json", "expected_model_manifest.json", "environment.json",
    "preflight.json", "data/target_plan.jsonl", "metadata/target_plan.json",
    "audits/design_prelock.json",
)
PREDICTION_FILES = (
    "predictions/cv_scores.csv", "predictions/cv_candidate_summary.csv",
    "predictions/selection.json", "predictions/counts.json", "predictions/profiles.json",
    "predictions/forecasts.jsonl", "predictions/identity_certificate.json", "FORECAST_NOTE.md",
)
TARGET_ATTEMPT_FILES = ("metadata/target_attempt.json", "metadata/target.json",
                        "metadata/target_failure.json", "metadata/target_events.jsonl",
                        "data/target_generations.jsonl")


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha_bytes(value):
    return hashlib.sha256(value).hexdigest()


def json_lines(value):
    if isinstance(value, bytes):
        value = value.decode("utf-8")
    return [json.loads(x) for x in value.splitlines() if x.strip()]


def parse_time(value):
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("Timezone-free audit timestamp")
    return parsed


def mean(values):
    values = list(values)
    return math.fsum(values) / len(values)


def sign(value):
    return -1 if value < -TIE else (1 if value > TIE else 0)


def code(label):
    return (label["answerer_answer_mode"], label["answerer_judgment"],
            label["answerer_stance"], tuple(sorted(label["limit_owners"])),
            label["other_answer"], label["character_description"])


def category(label):
    if label["answerer_answer_mode"] in {"direct", "both"} and label["answerer_judgment"] != "none":
        return label["answerer_judgment"]
    return "no_direct"


def strict_event(label):
    return category(label) != "no_direct" and "answerer_direct" in label["limit_owners"]


def category_loss(probability, label_index):
    return math.fsum((p - (k == label_index)) ** 2 for k, p in enumerate(probability))


def binary_nll(probability, event):
    return -math.log(probability if event else 1.0 - probability)


def global_probability(counts):
    return [(c + 0.5) / (sum(counts) + 2.5) for c in counts]


def independently_factorized(counts, global_p, rho_gate, rho_content):
    """Use empirical proportions, independent of predictor implementation."""
    n = sum(counts)
    if not n:
        return list(global_p)
    empirical = [c / n for c in counts]
    gd, qd = math.fsum(global_p[:4]), math.fsum(empirical[:4])
    if rho_gate == "inf":
        gate = gd
    else:
        weight = 1.0 / (1.0 + float(rho_gate))
        gate = weight * qd + (1.0 - weight) * gd
    if rho_content == "inf":
        conditional = [p / gd for p in global_p[:4]]
    else:
        strength = float(rho_content)
        conditional = [(q + strength * p) / (qd + strength * gd)
                       for q, p in zip(empirical[:4], global_p[:4])]
    return [gate * p for p in conditional] + [1.0 - gate]


def independently_flat(counts, global_p, strength):
    if not sum(counts) or strength == "inf":
        return list(global_p)
    weight = 1 / (1 + float(strength))
    return [weight * c / sum(counts) + (1 - weight) * p for c, p in zip(counts, global_p)]


def parameter_preference(pair, algorithm):
    rg, rc = pair
    if algorithm == "F":
        return (-GRID.index(rg),)
    return (int(rg != "inf") + int(rc != "inf"), -GRID.index(rg), -GRID.index(rc))


def choose(parameters_and_scores, algorithm):
    optimum = min(value for _, value in parameters_and_scores)
    tied = [pair for pair, value in parameters_and_scores if value <= optimum + TIE]
    return min(tied, key=lambda pair: parameter_preference(pair, algorithm))


class Audit:
    def __init__(self, stage):
        self.stage, self.started = stage, utc()
        self.assertions, self.failure_count = 0, 0
        self.failures, self.sections = [], []
        self.input_hashes, self.facts = {}, {}

    def check(self, condition, label, detail=None):
        self.assertions += 1
        if not bool(condition):
            self.failure_count += 1
            if len(self.failures) < 100:
                self.failures.append({"check": label, "detail": detail})
        return bool(condition)

    def equal(self, actual, expected, label):
        return self.check(actual == expected, label, None if actual == expected else
                          {"actual": repr(actual)[:1200], "expected": repr(expected)[:1200]})

    def near(self, actual, expected, label):
        try:
            actual, expected = float(actual), float(expected)
            valid = math.isfinite(actual) and math.isfinite(expected) and math.isclose(
                actual, expected, abs_tol=NUMERIC_TOLERANCE, rel_tol=NUMERIC_TOLERANCE)
        except (TypeError, ValueError, OverflowError):
            valid = False
        return self.check(valid, label, None if valid else {"actual": actual, "expected": expected})

    def vector(self, actual, expected, label):
        self.equal(len(actual), len(expected), label + "/length")
        for k, (x, y) in enumerate(zip(actual, expected)):
            self.near(x, y, label + f"/{k}")

    def path(self, relative):
        p = Path(relative)
        if p.is_absolute() or ".." in p.parts:
            raise ValueError(f"Unsafe relative artifact path: {relative}")
        result = ROOT / p
        if not result.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError(f"Escaping artifact: {relative}")
        return result

    def digest(self, relative):
        h = hashlib.sha256()
        with self.path(relative).open("rb") as f:
            for block in iter(lambda: f.read(1024 * 1024), b""):
                h.update(block)
        value = h.hexdigest()
        previous = self.input_hashes.get(str(relative))
        if previous is not None:
            self.equal(value, previous, f"file stable during audit: {relative}")
        self.input_hashes[str(relative)] = value
        return value

    def read_json(self, relative):
        self.digest(relative)
        return json.loads(self.path(relative).read_text())

    def read_rows(self, relative):
        self.digest(relative)
        return json_lines(self.path(relative).read_text())

    def read_csv(self, relative):
        self.digest(relative)
        with self.path(relative).open(newline="") as f:
            return list(csv.DictReader(f))

    def hash_mapping(self, mapping, label):
        self.check(isinstance(mapping, dict) and bool(mapping), label + "/nonempty")
        for relative, expected in mapping.items():
            self.equal(self.digest(relative), expected, f"{label}/{relative}")

    def section(self, label):
        self.sections.append({"section": label, "assertions_before": self.assertions,
                              "failure_count_before": self.failure_count})

    def validate_label(self, row, label):
        self.equal(set(row), LABEL_FIELDS, label + "/fields")
        for field, allowed in LABEL_ENUMS.items():
            self.check(row[field] in allowed, label + "/" + field)
        owners = row["limit_owners"]
        self.check(isinstance(owners, list) and len(owners) == len(set(owners))
                   and set(owners) <= OWNERS, label + "/owners")
        self.check(type(row["other_answer"]) is bool and type(row["character_description"]) is bool,
                   label + "/boolean types")
        self.check(isinstance(row["note"], str) and bool(row["note"].strip()), label + "/note")
        self.check(len({row[field] == "none" for field in LABEL_ENUMS}) == 1, label + "/none consistency")
        self.equal(row["answerer_judgment"] == "mixed", row["answerer_stance"] == "mixed", label + "/mixed")
        if row["answerer_judgment"] == "withhold":
            self.equal(row["answerer_stance"], "tentative", label + "/withhold stance")
        self.check(not strict_event(row) or category(row) != "no_direct", label + "/E implies D")

    def duplicate_label_check(self, labels, blind, label):
        by_id = {r["sample_id"]: r for r in labels}
        self.equal(len(by_id), len(labels), label + "/unique ids")
        self.equal(set(by_id), {r["sample_id"] for r in blind}, label + "/blind id set")
        seen = {}
        for item in blind:
            sid = item["sample_id"]
            key = (item["requested_answerer"], item["question"], item["completion"])
            c = code(by_id[sid])
            if key in seen:
                self.equal(c, seen[key], label + f"/duplicate/{sid}")
            seen[key] = c
        return by_id

    def no_target(self):
        for relative in TARGET_ATTEMPT_FILES:
            self.check(not self.path(relative).exists(), f"target absent/{relative}")
        self.check(not self.path("source_snapshots/target").exists(), "target snapshot absent")
        self.check(not self.path("observers/target").exists(), "target observations absent")

    def report(self):
        core = set(DESIGN_FILES) - {"audits/design_prelock.json"}
        reported_hashes = ({k: self.input_hashes[k] for k in sorted(core) if k in self.input_hashes}
                           if self.stage == "design" else self.input_hashes)
        extra = ({k: v for k, v in self.input_hashes.items() if k not in core}
                 if self.stage == "design" else {})
        return {"schema_version": "persona-shrinkage-independent-audit-v9", "stage": self.stage,
                "started_utc": self.started, "audited_utc": utc(),
                "status": "ALL_MATCH" if not self.failure_count else "FAIL",
                "assertions": self.assertions, "failure_count": self.failure_count,
                "failures": self.failures, "sections": self.sections,
                "input_hashes": reported_hashes, "additional_verified_hashes": extra, **self.facts,
                "independence": "No imports from predictor, runner, experiment_config or observer validator; no subject model inference.",
                "limitations": "Internal consistency audit, not an independent timestamp or independent scientific replication."}


def audit_source_and_development(a):
    a.section("immutable source and balanced development provenance")
    a.equal(a.digest("provenance/source_v8.zip"), SOURCE_SHA, "source archive SHA-256")
    with zipfile.ZipFile(a.path("provenance/source_v8.zip")) as z:
        a.equal(z.testzip(), None, "source ZIP CRC")
        manifest = json.loads(z.read(PREFIX + "FILE_MANIFEST.json"))
        a.equal(len(manifest), 174, "source manifest count")
        a.equal(set(z.namelist()), {PREFIX + row["path"] for row in manifest} | {PREFIX + "FILE_MANIFEST.json"},
                "source archive exact membership")
        for item in manifest:
            payload = z.read(PREFIX + item["path"])
            a.equal(len(payload), item["bytes"], "source bytes/" + item["path"])
            a.equal(sha_bytes(payload), item["sha256"], "source hash/" + item["path"])
        source_questions = json.loads(z.read(PREFIX + "question_bank.json"))
        a.equal(a.read_json("development/source_question_bank.json"), source_questions, "old question bank unmodified")
        source_records, original_seeds = [], set()
        for phase in ("fit", "support", "target"):
            rows = json_lines(z.read(PREFIX + f"data/{phase}_generations.jsonl"))
            original_seeds.update(r["seed"] for r in rows)
            if phase == "support":
                source_records.extend(r for r in rows if r["seed"] in {2026110383, 2026110384})
            elif phase == "target":
                source_records.extend(rows)
        a.equal(len(source_records), 336, "source selected count")
        a.equal(Counter(r["phase"] for r in source_records), Counter(support=192, target=144), "source phase balance")
        original_by_id = {r["sample_id"]: r for r in source_records}
        a.equal(len(original_by_id), 336, "source selected unique IDs")
        source_labels, source_locks = {}, []
        for observer in OBSERVERS:
            combined = {}
            for stage, count in (("construction", 432), ("target", 144)):
                base = PREFIX + f"observers/{stage}/{observer}/"
                lock = json.loads(z.read(base + "observation_lock.json"))
                a.equal(lock["label_rows"], count, f"old lock count/{stage}/{observer}")
                for field, name in LOCK_FILES.items():
                    a.equal(sha_bytes(z.read(base + name)), lock[field], f"old annotation lock/{stage}/{observer}/{field}")
                a.equal(lock["rubric_sha256"], RUBRIC_SHA, f"old rubric/{stage}/{observer}")
                labels = json_lines(z.read(base + "labels.jsonl"))
                blind = json_lines(z.read(base + "validation_blind.jsonl"))
                a.equal(len(labels), count, f"old label count/{stage}/{observer}")
                indexed = a.duplicate_label_check(labels, blind, f"old duplicate consistency/{observer}/{stage}")
                a.check(not(set(combined) & set(indexed)), f"old phase unique IDs/{observer}/{stage}")
                combined.update(indexed)
                source_locks.append({"observer": observer, "stage": stage,
                    "path_in_zip": base + "observation_lock.json",
                    "sha256": sha_bytes(z.read(base + "observation_lock.json")), "original_lock": lock})
            source_labels[observer] = {sid: combined[sid] for sid in original_by_id}
        a.equal(a.digest("runtime.py"), RUNTIME_SHA, "inherited runtime unchanged")
        a.equal(a.digest("rubric.md"), RUBRIC_SHA, "inherited rubric unchanged")
        a.equal(a.path("runtime.py").read_bytes(), z.read(PREFIX + "runtime.py"), "runtime byte copy")
        a.equal(a.path("rubric.md").read_bytes(), z.read(PREFIX + "rubric.md"), "rubric byte copy")
        old_model_manifest = json.loads(z.read(PREFIX + "model_manifest.json"))
    dev = a.read_rows("development/records.jsonl")
    a.equal(len(dev), 336, "development count")
    a.equal([r["sample_id"] for r in dev], [r["sample_id"] for r in source_records], "development deterministic source order")
    question_folds = defaultdict(set)
    for row in dev:
        sid, original = row["sample_id"], original_by_id[row["sample_id"]]
        expected_fold = original["topic_index"] + (4 if original["phase"] == "target" else 0)
        a.equal(set(row), {"sample_id", "source_phase", "development_fold", "source_record"}, "development wrapper fields/" + sid)
        a.equal(row["source_phase"], original["phase"], "development source phase/" + sid)
        a.equal(row["source_record"], original, "complete original output unchanged/" + sid)
        a.equal(row["development_fold"], expected_fold, "development fold/" + sid)
        question_folds[original["question_id"]].add(row["development_fold"])
    a.equal(len(question_folds), 28, "development questions")
    a.check(all(len(folds) == 1 for folds in question_folds.values()), "question never crosses CV folds")
    a.equal(Counter((r["source_record"]["setting_id"], r["source_record"]["evidence_stratum"]) for r in dev),
            Counter({(s, e): 14 for s in SETTING_IDS for e in STRATA}), "development local balance")
    for fold in range(7):
        held = [r for r in dev if r["development_fold"] == fold]
        a.equal(len(held), 48, f"fold {fold}/validation n")
        a.equal(len({r["source_record"]["question_id"] for r in held}), 4, f"fold {fold}/questions")
        a.equal(Counter((r["source_record"]["setting_id"], r["source_record"]["evidence_stratum"]) for r in held),
                Counter({(s, e): 2 for s in SETTING_IDS for e in STRATA}), f"fold {fold}/complete balance")
    labels = {}
    for observer in OBSERVERS:
        rows = a.read_rows(f"development/labels_{observer}.jsonl")
        a.equal(len(rows), 336, "development labels count/" + observer)
        labels[observer] = {r["sample_id"]: r for r in rows}
        a.equal(labels[observer], source_labels[observer], "development labels unmodified/" + observer)
        for row in rows:
            a.validate_label(row, f"development label/{observer}/{row['sample_id']}")
    manifest = a.read_json("development_manifest.json")
    a.equal(manifest["source_archive"]["sha256"], SOURCE_SHA, "development manifest source identity")
    a.equal(manifest["source_observation_locks"], source_locks, "development manifest original locks")
    a.equal(manifest["selected_sample_ids"], [r["sample_id"] for r in dev], "development manifest IDs")
    a.equal(manifest["selection"], {"support_seeds": [2026110383, 2026110384], "support_n": 192,
        "old_target_n": 144, "old_targets_are_development": True,
        "fit_included": False, "excess_anchor_repeats_included": False}, "development inclusion rules")
    for relative, record in manifest["derived_files"].items():
        a.equal(a.digest(relative), record["sha256"], "development manifest hash/" + relative)
        a.equal(a.path(relative).stat().st_size, record["bytes"], "development manifest bytes/" + relative)
    for record in manifest["folds"]:
        fold = record["fold"]
        held = [r for r in dev if r["development_fold"] == fold]
        a.equal(record["validation_sample_ids"], [r["sample_id"] for r in held], f"manifest fold {fold}/IDs")
        a.equal(record["validation_question_ids"], sorted({r["source_record"]["question_id"] for r in held}), f"manifest fold {fold}/questions")
        a.equal(record["training_n"], 288, f"manifest fold {fold}/train count")
        a.equal(record["validation_n"], 48, f"manifest fold {fold}/validation count")
    a.facts.update(development_records=336, old_target_records_reused_for_development=144)
    return dev, labels, source_questions, original_seeds, old_model_manifest


def audit_configuration_and_plan(a, source_questions, old_seeds, old_manifest):
    a.section("configuration, pinned model, authored bank and tokenizer-only target plan")
    config = a.read_json("study_config.json")
    required = {"study_id": STUDY, "model_id": "HuggingFaceTB/SmolLM2-360M-Instruct",
        "revision": "a10cc1512eabd3dde888204e902eca88bddb4951", "answerer": "Morgan",
        "system_template": "You are {answerer}. Answer the question as yourself in two sentences. Give only your own answer.",
        "wrapper": "Active response instruction for {actor}:", "frame": "instruction",
        "selected_format": "bounded_conclusion", "max_new_tokens": 96, "temperature": 0.8,
        "top_p": 0.95, "batch_size": 8, "torch_threads": 4, "torch_interop_threads": 1,
        "expected_questions": 24, "expected_contexts": 144, "expected_samples": 288,
        "expected_development_samples": 336, "replicate_ids": [0, 1], "global_alpha": 0.5,
        "rho_grid": list(GRID), "cv_folds": 7, "selection_shared_observers": True,
        "tie_tolerance": TIE, "sign_zero_tolerance": TIE, "source_archive_sha256": SOURCE_SHA,
        "families": list(FAMILIES), "observers": list(OBSERVERS), "category_names": list(CATEGORIES),
        "evidence_strata": list(STRATA), "predictors": list(ALGORITHMS),
        "all_contrasts": [list(c) for c in CONTRASTS], "primary_contrasts": [list(c) for c in CONTRASTS[:2]],
        "required_contrasts": [list(c) for c in CONTRASTS[2:]], "strict_predictors": ["G", "H"],
        "strict_contrasts": [["H", "G"]], "strict_zero_brier_only": True,
        "worked_example_setting": "eval_neutral_instruction_p0"}
    for k, value in required.items():
        a.equal(config[k], value, "frozen configuration/" + k)
    settings = a.read_json("settings.json")
    a.equal([s["setting_id"] for s in settings], list(SETTING_IDS), "setting order")
    old_rows = a.read_rows("development/records.jsonl")
    for setting in settings:
        sid = setting["setting_id"]
        seen = [r["source_record"] for r in old_rows if r["source_record"]["setting_id"] == sid]
        for field in ("family", "paraphrase_id", "frame", "requested_answerer", "policy_text"):
            a.equal({r[field] for r in seen}, {setting[field]}, f"familiar setting unchanged/{sid}/{field}")
    bank = a.read_json("question_bank.json")
    a.equal(len(bank), 24, "new question count")
    a.equal([q["question_id"] for q in bank], [f"N{i:02d}" for i in range(1, 25)], "new question ID order")
    a.equal(len({q["topic"] for q in bank}), 24, "new topics unique")
    a.check(not({q["topic"] for q in bank} & {q["topic"] for q in source_questions}), "new topics disjoint from all 36 old topics")
    a.check(not({q["evidence"] for q in bank} & {q["evidence"] for q in source_questions}), "new evidence text disjoint")
    for i, q in enumerate(bank):
        a.equal(set(q), {"phase", "question_id", "topic", "topic_index", "evidence_stratum", "evidence", "claim"}, "question fields/" + q["question_id"])
        a.equal(q["phase"], "target", "question phase/" + q["question_id"])
        a.equal(q["evidence_stratum"], STRATA[i // 6], "question stratum/" + q["question_id"])
        a.equal(q["topic_index"], i % 6, "question index/" + q["question_id"])
        a.check(40 <= len(q["evidence"].split()) <= 65, "question evidence word budget/" + q["question_id"])
    a.equal(a.read_json("model_manifest.json"), old_manifest, "model manifest inherited")
    a.equal(a.read_json("expected_model_manifest.json"), old_manifest, "expected model manifest inherited")
    for item in old_manifest["files"]:
        relative = "model/" + item["name"]
        a.equal(a.path(relative).stat().st_size, item["size_bytes"], "model bytes/" + item["name"])
        a.equal(a.digest(relative), item["sha256"], "model SHA/" + item["name"])
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = "1"
    os.environ["HF_HOME"] = str(ROOT / ".cache" / "huggingface")
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(str(ROOT / "model"), local_files_only=True, trust_remote_code=False)
    plan, expected, streams = a.read_rows("data/target_plan.jsonl"), [], set()
    for setting in settings:
        for q in bank:
            question = q["evidence"] + "\n\nWhat can be concluded about whether " + q["claim"] + " from the stated evidence?"
            messages = [{"role": "system", "content": "You are Morgan. Answer the question as yourself in two sentences. Give only your own answer."},
                {"role": "user", "content": "Active response instruction for Morgan:\n> " + setting["policy_text"] + "\n\nQuestion: " + question}]
            prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            ids = tokenizer(prompt, add_special_tokens=False)["input_ids"]
            context = f"target_{q['question_id']}_{setting['setting_id']}_bounded_conclusion"
            for replicate in (0, 1):
                stream_bytes = hashlib.sha256(f"{STUDY}|{q['question_id']}|{replicate}".encode()).digest()
                seed = int.from_bytes(stream_bytes[:8], "big") & ((1 << 63) - 1)
                streams.add(seed)
                sid = hashlib.sha256(f"{STUDY}|{context}|{seed}".encode()).hexdigest()[:12]
                expected.append({"sample_id": sid, "context_id": context, "phase": "target",
                    "question_id": q["question_id"], "question_name": q["topic"], "question": question,
                    "evidence_stratum": q["evidence_stratum"], "format": "bounded_conclusion",
                    **setting, "topic_index": q["topic_index"], "messages": messages, "prompt": prompt,
                    "prompt_ids": ids, "prompt_tokens": len(ids), "replicate_id": replicate, "seed": seed})
    a.equal(len(plan), 288, "target plan count")
    a.equal(len({r["sample_id"] for r in plan}), 288, "target IDs unique")
    a.equal(len({r["context_id"] for r in plan}), 144, "target contexts count")
    a.equal(len(streams), 48, "distinct question replicate streams")
    a.check(not(streams & old_seeds), "new streams disjoint from old seeds")
    a.check(not({r["sample_id"] for r in plan} & {r["sample_id"] for r in old_rows}), "new IDs disjoint from development")
    for i, (actual, wanted) in enumerate(zip(plan, expected)):
        a.equal(actual, wanted, f"target plan independently reconstructed/{i}")
    a.equal(Counter(r["seed"] for r in plan), Counter({s: 6 for s in streams}), "stream paired exactly across six settings")
    metadata = a.read_json("metadata/target_plan.json")
    a.equal(metadata["target_plan_sha256"], a.digest("data/target_plan.jsonl"), "plan metadata hash")
    a.equal(metadata["expected_target_samples"], 288, "plan metadata n")
    a.equal(metadata["expected_contexts"], 144, "plan metadata contexts")
    a.equal(metadata["model_inference_performed"], False, "plan metadata no inference")
    a.equal(metadata["target_outputs_absent"], True, "plan metadata no target outputs")
    a.hash_mapping(metadata["frozen_source_hashes"], "plan source hashes")
    preflight = a.read_json("preflight.json")
    environment = a.read_json("environment.json")
    installed = {name: importlib.metadata.version(name) for name in environment["packages"]}
    a.equal(installed, environment["packages"], "installed versions match frozen environment")
    a.equal(preflight["packages"], environment["packages"], "preflight package metadata")
    a.equal(preflight["model_files_match"], True, "preflight model match")
    a.equal(preflight["model_inference_performed"], False, "preflight no subject inference")
    a.equal(preflight["internal_states_collected"], False, "preflight no states")
    a.hash_mapping(preflight["design_input_hashes"], "preflight input hashes")
    a.facts.update(target_plan_rows=len(plan), new_questions=len(bank), distinct_seed_streams=len(streams))
    return config, settings, bank, plan, tokenizer


def audit_design_integrity(a, locked):
    a.section("source completeness and frozen design integrity")
    for relative in DESIGN_FILES:
        if relative != "audits/design_prelock.json" or locked:
            a.digest(relative)
    for relative in ("prepare_development.py", "experiment_config.py", "runtime.py", "run_experiment.py",
                     "validate_observation.py", "predict.py", "audit_shrinkage.py"):
        source = a.path(relative).read_text()
        ast.parse(source, filename=relative)
        a.check(bool(source.strip()), "nonempty parseable source/" + relative)
    imported = []
    for node in ast.walk(ast.parse(a.path("audit_shrinkage.py").read_text())):
        if isinstance(node, ast.Import):
            imported.extend(n.name for n in node.names)
        elif isinstance(node, ast.ImportFrom):
            imported.append(node.module or "")
    a.check(not({n.split(".")[0] for n in imported} & {"predict", "run_experiment", "experiment_config", "validate_observation"}),
            "auditor has no implementation imports")
    if not locked:
        a.no_target()
        a.check(not a.path("predictions/forecast_lock.json").exists(), "design before forecast lock")
        for relative in PREDICTION_FILES:
            a.check(not a.path(relative).exists(), "design before fitting/" + relative)
        a.check(not a.path("design_lock.json").exists(), "prelock audit before design lock")
        return None
    lock = a.read_json("design_lock.json")
    a.equal(set(lock["input_hashes"]), set(DESIGN_FILES), "design lock exact input set")
    a.hash_mapping(lock["input_hashes"], "design lock hashes")
    a.equal(lock["expected_target_samples"], 288, "design lock target count")
    a.equal(lock["outputs_absent"], True, "design lock output absence marker")
    report = a.read_json("audits/design_prelock.json")
    a.equal(report["status"], "ALL_MATCH", "prelock independent audit passed")
    a.check(parse_time(report["audited_utc"]) <= parse_time(lock["locked_utc"]), "prelock audit precedes lock")
    for relative in DESIGN_FILES:
        if relative != "audits/design_prelock.json":
            a.equal(report["input_hashes"].get(relative), a.digest(relative), "prelock covered unchanged source/" + relative)
    a.facts["design_lock_sha256"] = a.digest("design_lock.json")
    return lock


def aggregate_counts(dev, labels, selected_ids):
    selected = [r for r in dev if r["sample_id"] in selected_ids]
    categories = Counter(category(labels[r["sample_id"]]) for r in selected)
    return {"n": len(selected), "counts": [categories[c] for c in CATEGORIES],
            "n_direct": sum(categories[c] for c in CATEGORIES[:4]),
            "n_strict": sum(strict_event(labels[r["sample_id"]]) for r in selected),
            "sample_ids": sorted(r["sample_id"] for r in selected)}


def count_bundle(dev, labels, train):
    global_counts = aggregate_counts(dev, labels, {r["sample_id"] for r in train})
    local, evidence = {}, {}
    for stratum in STRATA:
        evidence[stratum] = aggregate_counts(dev, labels, {r["sample_id"] for r in train if r["source_record"]["evidence_stratum"] == stratum})
        for setting in SETTING_IDS:
            local[(setting, stratum)] = aggregate_counts(dev, labels, {r["sample_id"] for r in train
                if r["source_record"]["setting_id"] == setting and r["source_record"]["evidence_stratum"] == stratum})
    return {"global": global_counts, "local": local, "evidence": evidence}


def recompute_cv_and_selection(a, dev, labels):
    a.section("independent blocked cross-validation and declared selection")
    cv, fold_bundles = {}, {}
    for fold in range(7):
        training = [r for r in dev if r["development_fold"] != fold]
        held = [r for r in dev if r["development_fold"] == fold]
        a.equal(len(training), 288, f"CV train n/{fold}")
        a.equal(len(held), 48, f"CV validation n/{fold}")
        a.check(not({r["source_record"]["question_id"] for r in training} & {r["source_record"]["question_id"] for r in held}),
                f"CV no question leakage/{fold}")
        for observer in OBSERVERS:
            bundle = count_bundle(dev, labels[observer], training)
            fold_bundles[(fold, observer)] = bundle
            gp = global_probability(bundle["global"]["counts"])
            for pooling in ("setting_stratum", "evidence"):
                for rg, rc in itertools.product(GRID, repeat=2):
                    briers, nlls = [], []
                    for wrapped in held:
                        row = wrapped["source_record"]
                        cell = bundle["local"][(row["setting_id"], row["evidence_stratum"])] if pooling == "setting_stratum" else bundle["evidence"][row["evidence_stratum"]]
                        p = independently_factorized(cell["counts"], gp, rg, rc)
                        yi = CATEGORIES.index(category(labels[observer][row["sample_id"]]))
                        briers.append(category_loss(p, yi))
                        nlls.append(-math.log(p[yi]))
                    cv[(fold, observer, pooling, rg, rc)] = {"n": len(held), "brier": mean(briers), "nll": mean(nlls)}
    summary = {}
    for pooling in ("setting_stratum", "evidence"):
        for rg, rc in itertools.product(GRID, repeat=2):
            scores = {}
            for metric in ("brier", "nll"):
                for observer in OBSERVERS:
                    scores[f"{observer}_{metric}"] = mean(cv[(fold, observer, pooling, rg, rc)][metric] for fold in range(7))
                scores["mean_" + metric] = mean(scores[f"{observer}_{metric}"] for observer in OBSERVERS)
            summary[(pooling, rg, rc)] = scores
    selected = {"G": ("inf", "inf")}
    for name in ("F", "H_gate", "H_content", "H", "H_evidence"):
        pooling = "evidence" if name == "H_evidence" else "setting_stratum"
        candidates = []
        for rg, rc in itertools.product(GRID, repeat=2):
            allowed = (name != "F" or rg == rc) and (name != "H_gate" or rc == "inf") and (name != "H_content" or rg == "inf")
            if allowed:
                candidates.append(((rg, rc), summary[(pooling, rg, rc)]["mean_brier"]))
        selected[name] = choose(candidates, name)
    selected["Hswap"] = selected["H"]
    final = {observer: count_bundle(dev, labels[observer], dev) for observer in OBSERVERS}
    return cv, summary, selected, fold_bundles, final


def independently_forecast(final, selected, observer, setting, stratum, algorithm):
    bundle = final[observer]
    gp = global_probability(bundle["global"]["counts"])
    if algorithm == "G":
        p = gp
    else:
        donor = setting[:-1] + str(1 - int(setting[-1])) if algorithm == "Hswap" else setting
        cell = bundle["evidence"][stratum] if algorithm == "H_evidence" else bundle["local"][(donor, stratum)]
        pair = selected[algorithm]
        p = independently_flat(cell["counts"], gp, pair[0]) if algorithm == "F" else independently_factorized(cell["counts"], gp, *pair)
    gate = math.fsum(p[:4])
    ell = (bundle["global"]["n_strict"] + .5) / (bundle["global"]["n_direct"] + 1)
    return {"category_probabilities": p, "gate_probability": gate,
            "strict_event_probability": gate * ell if algorithm in {"G", "H"} else None}


def synthetic_checks(a):
    a.section("invented-count identities and boundary conditions")
    gp = global_probability([20, 12, 9, 3, 40])
    fixtures = [[7, 1, 0, 0, 6], [0, 0, 0, 0, 14], [5, 4, 3, 2, 0], [0, 0, 0, 0, 0]]
    max_identity_error = 0.0
    for i, counts in enumerate(fixtures):
        for strength in GRID:
            f = independently_flat(counts, gp, strength)
            h = independently_factorized(counts, gp, strength, strength)
            max_identity_error = max(max_identity_error, max(abs(x-y) for x, y in zip(f, h)))
            a.vector(h, f, f"synthetic diagonal identity/{i}/{strength}")
        for rg, rc in itertools.product(GRID, repeat=2):
            p = independently_factorized(counts, gp, rg, rc)
            a.near(sum(p), 1, f"synthetic normalized/{i}/{rg}/{rc}")
            a.check(all(0 < x < 1 for x in p), f"synthetic positive/{i}/{rg}/{rc}")
            for k in range(5):
                d, gate = k < 4, math.fsum(p[:4])
                decomposition = binary_nll(gate, d) + (-math.log(p[k]/gate) if d else 0)
                a.near(-math.log(p[k]), decomposition, f"synthetic NLL decomposition/{i}/{rg}/{rc}/{k}")
        a.vector(independently_factorized(counts, gp, "inf", "inf"), gp, f"synthetic global limit/{i}")
    a.equal(choose([((rg, rc), 1.0) for rg, rc in itertools.product(GRID, repeat=2)], "H"), ("inf", "inf"), "all-equal tie favors global")
    a.equal(choose([((r, r), 1.0) for r in GRID], "F"), ("inf", "inf"), "flat tie favors strongest")
    c = fixtures[0]
    n, nd, gd = sum(c), sum(c[:4]), sum(gp[:4])
    wrong = [(nd+n*gd)/(2*n) * (c[k]+n*gp[k]/gd)/(nd+n) for k in range(4)] + [1-(nd+n*gd)/(2*n)]
    a.check(max(abs(x-y) for x,y in zip(wrong, independently_flat(c, gp, "1"))) > 1e-4, "incorrect conditional prior mass detected")
    a.facts["synthetic_max_diagonal_error"] = max_identity_error


def eligible(pooling, rg, rc):
    if pooling == "evidence":
        return ["H_evidence"]
    return [name for name in ALGORITHMS if
            (name == "G" and rg == rc == "inf") or (name == "F" and rg == rc)
            or (name == "H_gate" and rc == "inf") or (name == "H_content" and rg == "inf")
            or name == "H"]


def compare_hist(a, actual, expected, label):
    a.equal(actual["n"], expected["n"], label + "/n")
    a.equal(actual["category_counts"], expected["counts"], label + "/counts")
    a.equal(actual["n_direct"], expected["n_direct"], label + "/direct")
    a.equal(actual["n_strict_event"], expected["n_strict"], label + "/strict")
    a.equal(actual["sample_ids"], expected["sample_ids"], label + "/sample IDs")


def compare_bundle(a, actual, expected, label):
    a.equal(set(actual), {"global", "setting_stratum", "evidence"}, label + "/fields")
    compare_hist(a, actual["global"], expected["global"], label + "/global")
    local = {(r["setting_id"], r["evidence_stratum"]): r for r in actual["setting_stratum"]}
    evidence = {r["evidence_stratum"]: r for r in actual["evidence"]}
    a.equal(len(actual["setting_stratum"]), 24, label + "/local cells")
    a.equal(len(actual["evidence"]), 4, label + "/evidence cells")
    a.equal(set(local), set(expected["local"]), label + "/local keys")
    a.equal(set(evidence), set(STRATA), label + "/evidence keys")
    for key, wanted in expected["local"].items():
        compare_hist(a, local[key], wanted, label + "/local/" + repr(key))
        a.equal(local[key]["family"], key[0].split("_")[1], label + "/family/" + repr(key))
        a.equal(local[key]["paraphrase_id"], int(key[0][-1]), label + "/wording/" + repr(key))
    for key, wanted in expected["evidence"].items():
        compare_hist(a, evidence[key], wanted, label + "/evidence/" + key)


def audit_forecast_artifacts(a, dev, labels, settings, plan, design_lock):
    a.section("forecast lock provenance and pre-target ordering")
    lock = a.read_json("predictions/forecast_lock.json")
    a.equal(lock["schema_version"], "persona-shrinkage-forecast-lock-v9", "forecast lock schema")
    a.equal(set(lock["input_hashes"]), set(DESIGN_FILES) | {"design_lock.json"}, "forecast input inventory")
    a.equal(set(lock["output_hashes"]), set(PREDICTION_FILES), "forecast output inventory")
    a.hash_mapping(lock["input_hashes"], "forecast lock inputs")
    a.hash_mapping(lock["output_hashes"], "forecast lock outputs")
    a.equal(lock["design_lock_sha256"], a.digest("design_lock.json"), "forecast ties design lock")
    a.equal(lock["target_plan_sha256"], a.digest("data/target_plan.jsonl"), "forecast ties target plan")
    a.equal(lock["forecasts_sha256"], a.digest("predictions/forecasts.jsonl"), "forecast alias hash")
    for field, expected in (("forecast_rows", 4032), ("profile_rows", 48), ("expected_target_samples", 288),
                            ("observers", list(OBSERVERS)), ("predictors", list(ALGORITHMS)),
                            ("category_order", list(CATEGORIES))):
        a.equal(lock[field], expected, "forecast lock/" + field)
    for flag in ("target_attempts_absent", "target_outputs_absent", "target_labels_absent"):
        a.equal(lock[flag], True, "forecast absence marker/" + flag)
    a.check(parse_time(design_lock["locked_utc"]) <= parse_time(lock["locked_utc"]), "design before forecast lock")
    if a.stage == "forecasts":
        a.no_target()
    a.facts["forecast_lock_sha256"] = a.digest("predictions/forecast_lock.json")
    cv, summaries, selected, fold_bundles, final = recompute_cv_and_selection(a, dev, labels)
    cv_rows = a.read_csv("predictions/cv_scores.csv")
    a.equal(len(cv_rows), 448, "CV table row count")
    cv_keys = set()
    for row in cv_rows:
        key = (int(row["fold"]), row["observer"], row["pooling"], row["rho_D"], row["rho_C"])
        a.check(key not in cv_keys, "CV table no duplicate/" + repr(key))
        cv_keys.add(key)
        wanted = cv[key]
        a.equal(int(row["n"]), wanted["n"], "CV held-out count/" + repr(key))
        a.near(row["brier"], wanted["brier"], "CV Brier/" + repr(key))
        a.near(row["nll"], wanted["nll"], "CV NLL/" + repr(key))
    a.equal(cv_keys, set(cv), "CV complete candidate inventory")
    summary_rows = a.read_csv("predictions/cv_candidate_summary.csv")
    a.equal(len(summary_rows), 32, "candidate summary rows")
    summary_keys = set()
    for row in summary_rows:
        key = (row["pooling"], row["rho_D"], row["rho_C"])
        a.check(key not in summary_keys, "candidate summary unique/" + repr(key))
        summary_keys.add(key)
        for field, expected in summaries[key].items():
            a.near(row[field], expected, "candidate summary/" + repr(key) + "/" + field)
        allowed = eligible(*key)
        a.equal(json.loads(row["eligible_algorithms"]), allowed, "candidate allowed methods/" + repr(key))
        wanted_selected = [name for name in allowed if selected[name] == key[1:]]
        a.equal(json.loads(row["selected_algorithms"]), wanted_selected, "candidate selected methods/" + repr(key))
    a.equal(summary_keys, set(summaries), "candidate summary complete inventory")
    selection = a.read_json("predictions/selection.json")
    choices = selection["choices"]
    a.equal(set(choices), set(ALGORITHMS), "selected algorithm inventory")
    minimums = {}
    for name in ALGORITHMS:
        choice = choices[name]
        pair = (choice["rho_D"], choice["rho_C"])
        a.equal(pair, selected[name], "independent selected rho/" + name)
        pooling = "evidence" if name == "H_evidence" else "setting_stratum"
        a.equal(choice["pooling"], "global" if name == "G" else pooling, "selected pooling/" + name)
        a.equal(choice["global_parameters"], pair == ("inf", "inf"), "selection global flag/" + name)
        a.equal(choice["diagonal_parameters"], pair[0] == pair[1], "selection diagonal flag/" + name)
        a.equal(choice["selected_within_tolerance_of_minimum"], True, "selected numerical tie flag/" + name)
        if name == "Hswap":
            a.equal(choice["source_predictor"], "H", "Hswap inherits H")
            a.equal(choice["cv_brier_mean"], None, "Hswap no separate CV")
            a.equal(choice["minimum_cv_brier_mean"], None, "Hswap no separate minimum")
            continue
        score = summaries[(pooling, *pair)]["mean_brier"]
        minimum = min(s["mean_brier"] for key, s in summaries.items() if name in eligible(*key))
        minimums[name] = minimum
        a.near(choice["cv_brier_mean"], score, "selected CV score/" + name)
        a.near(choice["minimum_cv_brier_mean"], minimum, "candidate minimum/" + name)
        a.check(score <= minimum + TIE, "declared tie tolerance selection/" + name)
    stored_counts = a.read_json("predictions/counts.json")
    a.equal(set(stored_counts["full_fit"]), set(OBSERVERS), "final counts observer set")
    for observer in OBSERVERS:
        compare_bundle(a, stored_counts["full_fit"][observer], final[observer], "final counts/" + observer)
    a.equal(len(stored_counts["folds"]), 7, "fold count bundles")
    fold_numbers = set()
    for fold_data in stored_counts["folds"]:
        fold = fold_data["fold"]
        a.check(fold not in fold_numbers, "unique fold count bundle")
        fold_numbers.add(fold)
        a.equal(fold_data["training_sample_ids"], sorted(r["sample_id"] for r in dev if r["development_fold"] != fold), f"fold count train IDs/{fold}")
        a.equal(fold_data["validation_sample_ids"], sorted(r["sample_id"] for r in dev if r["development_fold"] == fold), f"fold count validation IDs/{fold}")
        for observer in OBSERVERS:
            compare_bundle(a, fold_data["observers"][observer], fold_bundles[(fold, observer)], f"fold counts/{fold}/{observer}")
    a.equal(fold_numbers, set(range(7)), "all count folds")
    a.section("complete compact profiles and all prospective target vectors")
    profiles_data = a.read_json("predictions/profiles.json")
    a.equal(profiles_data["category_order"], list(CATEGORIES), "profile category order")
    profiles = profiles_data["profiles"]
    a.equal(len(profiles), 48, "profile count")
    profiles_by_key = {(p["observer"], p["setting_id"], p["evidence_stratum"]): p for p in profiles}
    a.equal(set(profiles_by_key), set(itertools.product(OBSERVERS, SETTING_IDS, STRATA)), "profile complete keys")
    independent = {}
    for key, profile in profiles_by_key.items():
        observer, setting, stratum = key
        a.equal(profile["family"], setting.split("_")[1], "profile family/" + repr(key))
        a.equal(profile["paraphrase_id"], int(setting[-1]), "profile wording/" + repr(key))
        a.equal(profile["n_local"], 14, "profile local n/" + repr(key))
        a.equal(profile["n_evidence"], 84, "profile evidence n/" + repr(key))
        gp = global_probability(final[observer]["global"]["counts"])
        gd = math.fsum(gp[:4])
        ell = (final[observer]["global"]["n_strict"] + .5)/(final[observer]["global"]["n_direct"] + 1)
        a.vector(profile["global_probabilities"], gp, "profile global/" + repr(key))
        a.near(profile["pooled_limit_probability"], ell, "profile strict conditional/" + repr(key))
        a.equal(set(profile["predictors"]), set(ALGORITHMS), "profile algorithm inventory/" + repr(key))
        for algorithm in ALGORITHMS:
            wanted = independently_forecast(final, selected, *key, algorithm)
            independent[(*key, algorithm)] = wanted
            actual = profile["predictors"][algorithm]
            label = "profile/" + repr((*key, algorithm))
            a.vector(actual["category_probabilities"], wanted["category_probabilities"], label + "/categories")
            a.near(actual["gate_probability"], wanted["gate_probability"], label + "/gate")
            a.vector(actual["composition_probabilities"], [p/wanted["gate_probability"] for p in wanted["category_probabilities"][:4]], label + "/composition")
            if algorithm in {"G", "H"}:
                a.near(actual["strict_event_probability"], wanted["strict_event_probability"], label + "/strict")
                a.check(0 < actual["strict_event_probability"] <= actual["gate_probability"], label + "/strict <= direct")
            else:
                a.equal(actual["strict_event_probability"], None, label + "/no extra strict predictor")
            a.near(math.fsum(actual["category_probabilities"]), 1, label + "/normalized")
            a.check(all(0 < p < 1 for p in actual["category_probabilities"]), label + "/interior")
            donor = setting[:-1] + str(1 - int(setting[-1])) if algorithm == "Hswap" else setting
            hist = (final[observer]["global"] if algorithm == "G" else
                    final[observer]["evidence"][stratum] if algorithm == "H_evidence" else
                    final[observer]["local"][(donor, stratum)])
            rd, rc = selected[algorithm]
            expected_weights = {"gate_empirical_weight": 0.0 if rd == "inf" else 1/(1+float(rd)),
                "composition_empirical_weight": 0.0 if rc == "inf" or hist["n_direct"] == 0 else hist["n_direct"]/(hist["n_direct"] + float(rc)*hist["n"]*gd),
                "gate_prior_mass": None if rd == "inf" else float(rd)*hist["n"],
                "composition_prior_mass": None if rc == "inf" else float(rc)*hist["n"]*gd,
                "pool_n": hist["n"], "pool_n_direct": hist["n_direct"],
                "donor_setting_id": donor if algorithm == "Hswap" else None}
            for field, wanted_weight in expected_weights.items():
                actual_weight = profile["effective_weights"][algorithm][field]
                if isinstance(wanted_weight, (int, float)):
                    a.near(actual_weight, wanted_weight, label + "/weight/" + field)
                else:
                    a.equal(actual_weight, wanted_weight, label + "/weight/" + field)
    global_collapse = {name: True for name in ALGORITHMS}
    coincidences = {(x["observer"], x["setting_id"], x["evidence_stratum"]): x for x in selection["coincidences"]}
    a.equal(set(coincidences), set(profiles_by_key), "coincidence inventory")
    for key, profile in profiles_by_key.items():
        vectors = {name: profile["predictors"][name]["category_probabilities"] for name in ALGORITHMS}
        exact = [[l, r] for l, r in itertools.combinations(ALGORITHMS, 2) if vectors[l] == vectors[r]]
        approximate = [[l, r] for l, r in itertools.combinations(ALGORITHMS, 2) if max(abs(x-y) for x,y in zip(vectors[l], vectors[r])) <= TIE]
        equals_global = [name for name in ALGORITHMS if max(abs(x-y) for x,y in zip(vectors[name], vectors["G"])) <= TIE]
        a.equal(coincidences[key]["exact_equal_pairs"], exact, "exact-vector coincidences/" + repr(key))
        a.equal(coincidences[key]["equal_pairs_within_tolerance"], approximate, "numeric-vector coincidences/" + repr(key))
        a.equal(coincidences[key]["global_equal_predictors"], equals_global, "global profile equality/" + repr(key))
        for name in ALGORITHMS:
            global_collapse[name] = global_collapse[name] and name in equals_global
    a.equal(selection["global_forecast_collapse"], global_collapse, "all-profile global collapse flags")
    forecasts = a.read_rows("predictions/forecasts.jsonl")
    a.equal(len(forecasts), 4032, "prospective forecast count")
    plan_by_id = {r["sample_id"]: r for r in plan}
    keys, expected_forecasts = set(), {}
    forecast_fields = {"sample_id", "observer", "predictor", "question_id", "setting_id", "evidence_stratum",
                       "category_probabilities", "gate_probability", "strict_event_probability"}
    for row in forecasts:
        key = (row["sample_id"], row["observer"], row["predictor"])
        a.check(key not in keys, "forecast unique key/" + repr(key))
        keys.add(key)
        a.equal(set(row), forecast_fields, "forecast field inventory/" + repr(key))
        sample = plan_by_id[row["sample_id"]]
        for field in ("question_id", "setting_id", "evidence_stratum"):
            a.equal(row[field], sample[field], "forecast target metadata/" + repr(key) + "/" + field)
        wanted = independent[(row["observer"], sample["setting_id"], sample["evidence_stratum"], row["predictor"])]
        expected_forecasts[key] = wanted
        a.vector(row["category_probabilities"], wanted["category_probabilities"], "forecast categorical/" + repr(key))
        a.near(row["gate_probability"], wanted["gate_probability"], "forecast gate/" + repr(key))
        if wanted["strict_event_probability"] is None:
            a.equal(row["strict_event_probability"], None, "forecast strict absent/" + repr(key))
        else:
            a.near(row["strict_event_probability"], wanted["strict_event_probability"], "forecast strict/" + repr(key))
    a.equal(keys, set(itertools.product(plan_by_id, OBSERVERS, ALGORITHMS)), "all forecast keys covered")
    a.section("all-count algebra identities, nesting and certificate")
    diag_checks = 0
    for bidx, bundle in enumerate([*final.values(), *fold_bundles.values()]):
        gp = global_probability(bundle["global"]["counts"])
        for cidx, hist in enumerate([*bundle["local"].values(), *bundle["evidence"].values()]):
            for rho in GRID:
                diag_checks += 1
                a.vector(independently_factorized(hist["counts"], gp, rho, rho), independently_flat(hist["counts"], gp, rho),
                         f"actual-count diagonal identity/{bidx}/{cidx}/{rho}")
            a.vector(independently_factorized(hist["counts"], gp, "inf", "inf"), gp, f"actual-count global limit/{bidx}/{cidx}")
    certificate = a.read_json("predictions/identity_certificate.json")
    a.equal(certificate["status"], "ALL_MATCH", "identity certificate status")
    a.equal(certificate["target_outcomes_read"], False, "certificate no target outcomes")
    a.equal(certificate["diagonal_checks"], diag_checks, "certificate diagonal check inventory")
    for field in ("maximum_diagonal_error", "maximum_global_limit_error", "maximum_normalization_error"):
        a.check(0 <= certificate[field] <= TIE, "certificate numeric bound/" + field)
    a.check(certificate["maximum_strict_E_minus_D"] <= TIE, "certificate strict nesting bound")
    a.equal(len(certificate["candidate_nesting"]), 4, "certificate nesting comparisons")
    for entry in certificate["candidate_nesting"]:
        restricted = entry["restricted_algorithm"]
        a.check(restricted in {"G", "F", "H_gate", "H_content"}, "valid nested restricted model")
        a.near(entry["H_minimum"], minimums["H"], "H candidate minimum")
        a.near(entry["restricted_minimum"], minimums[restricted], "restricted candidate minimum/" + restricted)
        a.check(minimums["H"] <= minimums[restricted] + TIE, "candidate nesting identity/" + restricted)
        a.equal(entry["passes"], True, "candidate nesting flag/" + restricted)
    edge = certificate["synthetic_edge_checks"]
    for flag in ("invented_counts_only", "zero_direct_case_checked", "empty_cell_case_checked", "strict_event_nesting_checked", "exact_tie_global_checked"):
        a.equal(edge[flag], True, "certificate synthetic edge/" + flag)
    a.equal(edge["development_data_read"], False, "synthetic certificate no development")
    a.equal(edge["model_loaded"], False, "synthetic certificate no model")
    a.facts.update(forecast_rows=4032, profile_rows=48, cv_candidate_fold_rows=448,
                   selected_parameters={k: list(v) for k, v in selected.items()},
                   global_forecast_collapse=global_collapse)
    return lock, expected_forecasts


def audit_generation_and_observation(a, plan, tokenizer, design_lock, forecast_lock):
    a.section("immutable generation attempt, snapshots, events and chronology")
    forecast_audit = a.read_json("audits/forecast.json")
    a.equal(forecast_audit["status"], "ALL_MATCH", "prospective independent forecast audit passed")
    a.equal(forecast_audit["design_lock_sha256"], a.digest("design_lock.json"), "forecast audit ties design")
    a.equal(forecast_audit["forecast_lock_sha256"], a.digest("predictions/forecast_lock.json"), "forecast audit ties forecast")
    a.hash_mapping(forecast_audit["input_hashes"], "prospective forecast audit inputs still unchanged")
    marker = a.read_json("metadata/target_attempt.json")
    metadata = a.read_json("metadata/target.json")
    events = a.read_rows("metadata/target_events.jsonl")
    a.check(not a.path("metadata/target_failure.json").exists(), "single target attempt completed without failure")
    a.equal(marker["status"], "started", "immutable attempt marker remains original")
    a.equal(marker["retry_or_resume_allowed"], False, "attempt has no silent retry")
    a.equal(metadata["status"], "complete", "generation complete")
    a.equal(metadata["phase"], "target", "generation target only")
    a.equal(metadata["generation_count"], 288, "metadata generation count")
    a.equal(metadata["expected_samples"], 288, "metadata target design count")
    a.equal(metadata["created_utc"], marker["created_utc"], "attempt creation time preserved")
    boundaries = {"design_lock_sha256": "design_lock.json",
                  "forecast_lock_sha256": "predictions/forecast_lock.json",
                  "forecast_audit_sha256": "audits/forecast.json", "target_plan_sha256": "data/target_plan.jsonl"}
    for field, relative in boundaries.items():
        checksum = a.digest(relative)
        a.equal(marker[field], checksum, "attempt boundary/" + field)
        a.equal(metadata[field], checksum, "generation boundary/" + field)
    a.equal(metadata["attempt_marker_sha256"], a.digest("metadata/target_attempt.json"), "attempt marker hash")
    chronology = [design_lock["locked_utc"], forecast_lock["locked_utc"], forecast_audit["audited_utc"],
                  marker["created_utc"], metadata["inference_started_utc"], metadata["completed_utc"]]
    a.check(all(parse_time(x) <= parse_time(y) for x,y in zip(chronology, chronology[1:])), "lock/audit/attempt/inference/complete ordering")
    source_set = set(DESIGN_FILES) | {"design_lock.json", "predictions/forecast_lock.json", "audits/forecast.json"} | set(PREDICTION_FILES)
    a.equal(set(marker["frozen_source_hashes"]), source_set, "attempt source inventory")
    a.equal(metadata["frozen_source_hashes"], marker["frozen_source_hashes"], "generation source inventory unchanged")
    a.hash_mapping(marker["frozen_source_hashes"], "generation sources unchanged")
    snapshot = a.read_json("source_snapshots/target/SNAPSHOT_MANIFEST.json")
    a.equal(metadata["source_snapshot_manifest_sha256"], a.digest("source_snapshots/target/SNAPSHOT_MANIFEST.json"), "snapshot manifest hash")
    a.equal(snapshot["files"], marker["frozen_source_hashes"], "snapshot exact source inventory")
    for relative, checksum in snapshot["files"].items():
        a.equal(a.digest("source_snapshots/target/" + relative), checksum, "source snapshot bytes/" + relative)
    a.check(parse_time(marker["created_utc"]) <= parse_time(snapshot["created_utc"]) <= parse_time(metadata["inference_started_utc"]),
            "snapshot before inference")
    event_names = ["attempt_started", "source_snapshot_verified", "model_loaded"] + ["batch_completed"]*36 + ["complete"]
    event_counts = [0, 0, 0] + list(range(8, 289, 8)) + [288]
    a.equal([e["event"] for e in events], event_names, "generation exact event sequence")
    a.equal([e["completed_rows"] for e in events], event_counts, "generation append-only row progression")
    a.check(all(parse_time(x["utc"]) <= parse_time(y["utc"]) for x,y in zip(events, events[1:])), "generation event time monotonic")
    a.equal(events[0]["utc"], marker["created_utc"], "attempt event time")
    a.equal(events[2]["utc"], metadata["inference_started_utc"], "loaded event time")
    a.check(parse_time(metadata["completed_utc"]) <= parse_time(events[-1]["utc"]), "metadata before completed event")
    fixed = {"model_id": "HuggingFaceTB/SmolLM2-360M-Instruct", "revision": "a10cc1512eabd3dde888204e902eca88bddb4951",
        "device": "cpu", "dtype": "torch.float32", "attention_implementation": "eager", "threads": 4, "interop_threads": 1,
        "max_new_tokens": 96, "temperature": .8, "top_p": .95, "top_k": 0, "batch_size": 8,
        "expected_contexts": 144, "unique_streams": 48, "internal_states_collected": False,
        "support_text_used_in_prompts": False, "each_question_starts_fresh_chat": True, "retry_or_resume_performed": False}
    for field, expected in fixed.items():
        a.equal(metadata[field], expected, "generation declared runtime/" + field)
    a.equal(metadata["packages"], a.read_json("environment.json")["packages"], "generation exact package versions")
    a.equal(metadata["chat_template"], tokenizer.chat_template, "generation unchanged chat template")
    a.equal(metadata["seeds"], sorted({r["seed"] for r in plan}), "generation all frozen streams")
    stop = a.read_json("model/generation_config.json")["eos_token_id"]
    eos = set(stop if isinstance(stop, list) else [stop if stop is not None else tokenizer.eos_token_id])
    a.equal(metadata["eos_token_ids"], sorted(eos), "generation EOS configuration")
    samples = a.read_rows("data/target_generations.jsonl")
    a.equal(len(samples), 288, "complete output count")
    a.equal([r["sample_id"] for r in samples], [r["sample_id"] for r in plan], "all outputs exactly plan order")
    for sample, wanted in zip(samples, plan):
        sid = sample["sample_id"]
        a.equal(set(sample), set(wanted) | {"completion", "generated_ids", "generated_tokens", "stop_reason"}, "generation fields/" + sid)
        a.equal({k: sample[k] for k in wanted}, wanted, "all frozen prompt/seed fields preserved/" + sid)
        ids = sample["generated_ids"]
        a.check(isinstance(ids, list) and all(type(token) is int and token >= 0 for token in ids), "generated IDs valid/" + sid)
        a.equal(sample["generated_tokens"], len(ids), "generated token count/" + sid)
        a.check(1 <= len(ids) <= 96, "generated token budget/" + sid)
        a.equal(sample["completion"], tokenizer.decode(ids, skip_special_tokens=True), "completion decoded from tokens/" + sid)
        reason = "eos" if ids[-1] in eos else "length"
        a.equal(sample["stop_reason"], reason, "stopping reason/" + sid)
        a.check(not any(token in eos for token in ids[:-1]), "no tokens after EOS/" + sid)
        a.check(reason == "eos" or len(ids) == 96, "length stop exact cap/" + sid)
    checksum = a.digest("data/target_generations.jsonl")
    a.equal(metadata["generations_sha256"], checksum, "complete generation hash")
    a.equal(events[-1]["generations_sha256"], checksum, "complete event output hash")
    a.equal(metadata["eos_count"], sum(r["stop_reason"] == "eos" for r in samples), "EOS count metadata")
    a.equal(metadata["length_count"], sum(r["stop_reason"] == "length" for r in samples), "length count metadata")
    a.section("complete blinded observation exports, schema and immutable labels")
    exports = a.read_json("observer_exports/target.json")
    a.hash_mapping(exports["input_hashes"], "blind export source hashes")
    a.equal(set(exports["fields"]), BLIND_FIELDS, "blind export fields omit conditions and predictions")
    a.check(parse_time(exports["created_utc"]) >= parse_time(metadata["completed_utc"]), "blind export after completed outputs")
    labels, locks, blind_orders = {}, {}, {}
    for observer in OBSERVERS:
        base = f"observers/target/{observer}/"
        blind = a.read_rows(base + "validation_blind.jsonl")
        discovered = a.read_rows(base + "discovery_blind.jsonl")
        a.equal(discovered, [], "empty discovery/" + observer)
        a.equal(len(blind), 288, "complete blind export/" + observer)
        wanted = [{k: row[k] for k in BLIND_FIELDS} for row in samples]
        wanted.sort(key=lambda r: hashlib.sha256(f"{STUDY}|blind|target|{observer}|{r['sample_id']}".encode()).hexdigest())
        a.equal(blind, wanted, "independently shuffled full blind records/" + observer)
        blind_orders[observer] = [r["sample_id"] for r in blind]
        a.equal(a.digest(base + "rubric.md"), RUBRIC_SHA, "target rubric byte-identical/" + observer)
        rows = a.read_rows(base + "labels.jsonl")
        a.equal(len(rows), 288, "all targets annotated/" + observer)
        for row in rows:
            a.validate_label(row, f"target label/{observer}/{row['sample_id']}")
        labels[observer] = a.duplicate_label_check(rows, blind, "target duplicate consistency/" + observer)
        lock = a.read_json(base + "observation_lock.json")
        locks[observer] = lock
        a.equal(lock["schema_version"], "persona-shrinkage-observation-v9", "target label lock schema/" + observer)
        a.equal(lock["label_rows"], 288, "target label lock count/" + observer)
        a.equal(lock["stage"], "target", "target label lock stage/" + observer)
        a.equal(lock["observer"], observer, "target label lock branch/" + observer)
        for field, name in LOCK_FILES.items():
            a.equal(lock[field], a.digest(base + name), f"target observation lock/{observer}/{field}")
        a.check(a.path(base + "observations.md").read_text().strip() != "", "observer qualitative note/" + observer)
        a.check(parse_time(lock["locked_utc"]) >= parse_time(exports["created_utc"]), "observer locks after blind export/" + observer)
        for field in ("rubric_sha256", "validation_blind_sha256", "discovery_blind_sha256"):
            a.equal(exports["exports"][observer][field], lock[field], "blind export lock continuity/" + observer + "/" + field)
    a.check(blind_orders["observer_a"] != blind_orders["observer_b"], "observer exports have different order")
    a.facts.update(target_generation_rows=288, target_length_stops=metadata["length_count"],
                   target_eos_stops=metadata["eos_count"], observer_label_rows={o:288 for o in OBSERVERS},
                   chronology_utc={"design_locked": design_lock["locked_utc"], "forecast_locked": forecast_lock["locked_utc"],
                    "forecasts_audited": forecast_audit["audited_utc"], "attempt_started": marker["created_utc"],
                    "inference_started": metadata["inference_started_utc"], "generation_completed": metadata["completed_utc"],
                    **{o + "_locked": locks[o]["locked_utc"] for o in OBSERVERS}})
    return samples, labels, locks


META = ("sample_id", "question_id", "question_name", "setting_id", "family",
        "paraphrase_id", "evidence_stratum", "replicate_id", "seed")
GROUP_FIELDS = {"question": ("question_id", "question_name", "evidence_stratum"),
                "setting": ("setting_id", "family", "paraphrase_id"),
                "stratum": ("evidence_stratum",), "family": ("family",)}
LOSSES = (("categorical", "brier"), ("categorical", "nll"), ("gate", "brier"),
          ("gate", "nll"), ("strict_event", "brier"), ("strict_event", "nll"))


def compare_record(a, actual, expected, label, exact_keys=True):
    if exact_keys:
        a.equal(set(actual), set(expected), label + "/fields")
    for field, value in expected.items():
        got = actual[field]
        if isinstance(value, bool) or value is None or isinstance(value, (str, int)):
            a.equal(got, value, label + "/" + field)
        elif isinstance(value, float):
            a.near(got, value, label + "/" + field)
        elif isinstance(value, list) and all(isinstance(x, (int, float)) for x in value):
            a.vector(got, value, label + "/" + field)
        else:
            a.equal(got, value, label + "/" + field)


def independently_scored_rows(samples, labels, forecasts):
    expected = {}
    for observer in OBSERVERS:
        for sample in samples:
            sid = sample["sample_id"]
            label = labels[observer][sid]
            cat = category(label)
            d, e = cat != "no_direct", strict_event(label)
            base = {field: sample[field] for field in META}
            base.update(observer=observer, observed_category=cat, direct_event=d,
                        strict_event=e, stop_reason=sample["stop_reason"],
                        generated_tokens=sample["generated_tokens"])
            for algorithm in (*ALGORITHMS, "E0"):
                row = {**base, "predictor": algorithm}
                if algorithm == "E0":
                    row.update(category_probabilities=None, gate_probability=None,
                        strict_event_probability=0.0, categorical_brier=None, categorical_nll=None,
                        gate_brier=None, gate_nll=None, composition_nll_contribution=None,
                        conditional_composition_nll=None, strict_event_brier=float(e), strict_event_nll=None)
                else:
                    forecast = forecasts[(sid, observer, algorithm)]
                    p, gate, pe = forecast["category_probabilities"], forecast["gate_probability"], forecast["strict_event_probability"]
                    yi = CATEGORIES.index(cat)
                    conditional = -math.log(p[yi]/gate) if d else None
                    row.update(forecast)
                    row.update(categorical_brier=category_loss(p, yi), categorical_nll=-math.log(p[yi]),
                        gate_brier=(gate-int(d))**2, gate_nll=binary_nll(gate, d),
                        composition_nll_contribution=conditional if d else 0.0,
                        conditional_composition_nll=conditional,
                        strict_event_brier=(pe-int(e))**2 if pe is not None else None,
                        strict_event_nll=binary_nll(pe, e) if pe is not None else None)
                expected[(sid, observer, algorithm)] = row
    return expected


def independently_paired_rows(samples, scores):
    paired = {}
    for sample in samples:
        sid = sample["sample_id"]
        for observer in OBSERVERS:
            for left, right in CONTRASTS:
                for outcome, metric in LOSSES[:4]:
                    key = (sid, observer, left + "-" + right, outcome, metric)
                    paired[key] = {**{f: sample[f] for f in META}, "observer": observer,
                        "contrast": left + "-" + right, "left": left, "right": right,
                        "outcome": outcome, "metric": metric,
                        "co_primary": (left, right) in CONTRASTS[:2] and (outcome, metric) == ("categorical", "brier"),
                        "difference": scores[(sid, observer, left)][outcome+"_"+metric] - scores[(sid, observer, right)][outcome+"_"+metric]}
            for outcome, metric in LOSSES[4:]:
                paired[(sid, observer, "H-G", outcome, metric)] = {
                    **{f: sample[f] for f in META}, "observer": observer, "contrast": "H-G",
                    "left": "H", "right": "G", "outcome": outcome, "metric": metric, "co_primary": False,
                    "difference": scores[(sid, observer, "H")][outcome+"_"+metric] - scores[(sid, observer, "G")][outcome+"_"+metric]}
    return paired


def independent_stats(values, signed=False):
    values = sorted(values)
    n = len(values)
    middle = values[n//2] if n % 2 else (values[n//2 - 1]+values[n//2])/2
    result = {"n": n, "mean": math.fsum(values)/n, "median": middle, "min": values[0], "max": values[-1]}
    if signed:
        result.update(n_negative=sum(sign(v) == -1 for v in values), n_zero=sum(sign(v) == 0 for v in values),
                      n_positive=sum(sign(v) == 1 for v in values), sign_zero_tolerance=TIE)
    return result


def independent_aggregate(rows, fields, value, signed=False):
    grouped = defaultdict(list)
    for row in rows:
        grouped[tuple(row[k] for k in fields)].append(row[value])
    return [dict(zip(fields, key)) | independent_stats(values, signed) for key, values in sorted(grouped.items())]


def compare_table(a, actual, expected, fields, label):
    ai = {tuple(r[k] for k in fields): r for r in actual}
    ei = {tuple(r[k] for k in fields): r for r in expected}
    a.equal(len(ai), len(actual), label + "/unique rows")
    a.equal(set(ai), set(ei), label + "/complete rows")
    for key in ei:
        compare_record(a, ai[key], ei[key], label + "/" + repr(key))


def ab_rows(rows, identity, value):
    indexed = {(r["observer"], *(r[k] for k in identity)): r for r in rows}
    result = list(rows)
    for row in rows:
        if row["observer"] == "observer_a":
            key = ("observer_b", *(row[k] for k in identity))
            result.append({**row, "observer": "ab_mean", value: (row[value]+indexed[key][value])/2})
    return result


def verify_csv_mirror(a, relative, canonical):
    rows = a.read_csv(relative)
    a.equal(len(rows), len(canonical), relative + "/CSV row count")
    for i, (actual, expected) in enumerate(zip(rows, canonical)):
        a.equal(set(actual), set(expected), relative + f"/{i}/fields")
        for field, value in expected.items():
            cell = actual[field]
            label = relative + f"/{i}/{field}"
            if value is None:
                a.equal(cell, "", label)
            elif isinstance(value, (dict, list)):
                a.equal(json.loads(cell), value, label)
            elif isinstance(value, bool):
                a.equal(cell, str(value), label)
            elif isinstance(value, int):
                a.equal(int(cell), value, label)
            elif isinstance(value, float):
                a.near(cell, value, label)
            else:
                a.equal(cell, value, label)


def audit_scoring(a, samples, labels, observation_locks, forecasts):
    a.section("independent every-output scoring and fixed paired comparisons")
    wide = a.read_rows("results/per_sample_scores.jsonl")
    expected_wide = independently_scored_rows(samples, labels, forecasts)
    a.equal(len(wide), 4608, "wide score count")
    actual_keys = set()
    for row in wide:
        key = (row["sample_id"], row["observer"], row["predictor"])
        a.check(key not in actual_keys, "wide score no duplicates/" + repr(key))
        actual_keys.add(key)
        compare_record(a, row, expected_wide[key], "score/" + repr(key))
        if row["predictor"] != "E0":
            a.near(row["categorical_nll"], row["gate_nll"] + row["composition_nll_contribution"],
                   "every-output NLL decomposition/" + repr(key))
    a.equal(actual_keys, set(expected_wide), "all outputs and algorithms scored")
    paired = a.read_rows("results/paired_differences.jsonl")
    expected_pairs = independently_paired_rows(samples, expected_wide)
    a.equal(len(paired), 19584, "paired differences count")
    actual_keys = set()
    for row in paired:
        key = (row["sample_id"], row["observer"], row["contrast"], row["outcome"], row["metric"])
        a.check(key not in actual_keys, "paired no duplicate/" + repr(key))
        actual_keys.add(key)
        compare_record(a, row, expected_pairs[key], "paired difference/" + repr(key))
    a.equal(actual_keys, set(expected_pairs), "all fixed paired contrasts scored")
    expected_scalars = []
    for row in expected_wide.values():
        for outcome, metric in LOSSES:
            value = row[outcome+"_"+metric]
            if value is not None:
                expected_scalars.append({**{f: row[f] for f in META}, "observer": row["observer"],
                    "predictor": row["predictor"], "outcome": outcome, "metric": metric, "score": value})
    scalars = a.read_rows("results/scalar_scores.jsonl")
    a.equal(len(scalars), 19008, "scalar loss count")
    compare_table(a, scalars, expected_scalars, ("sample_id", "observer", "predictor", "outcome", "metric"), "scalar losses")
    a.section("question/setting/stratum/family summaries and A/B averaging")
    tables = a.read_json("results/tables.json")
    expected_table_names = {"score_summary", "paired_summary", "nll_decomposition", "outcome_counts", "observer_agreement", "observer_disagreements"}
    for group in GROUP_FIELDS:
        expected_table_names.update({f"score_{group}_values", f"paired_{group}_values", f"paired_{group}_summary"})
    a.equal(set(tables), expected_table_names, "result table inventory")
    all_scalars = ab_rows(expected_scalars, ("sample_id", "predictor", "outcome", "metric"), "score")
    all_pairs = ab_rows(list(expected_pairs.values()), ("sample_id", "contrast", "outcome", "metric"), "difference")
    score_fields = ("observer", "predictor", "outcome", "metric")
    pair_fields = ("observer", "contrast", "left", "right", "outcome", "metric", "co_primary")
    score_summary = independent_aggregate(all_scalars, score_fields, "score")
    pair_summary = independent_aggregate(all_pairs, pair_fields, "difference", True)
    compare_table(a, tables["score_summary"], score_summary, score_fields, "score summary")
    compare_table(a, tables["paired_summary"], pair_summary, pair_fields, "paired summary")
    for group, extra in GROUP_FIELDS.items():
        svalues = independent_aggregate(all_scalars, (*score_fields, *extra), "score")
        pvalues = independent_aggregate(all_pairs, (*pair_fields, *extra), "difference", True)
        pblocks = independent_aggregate(pvalues, pair_fields, "mean", True)
        compare_table(a, tables[f"score_{group}_values"], svalues, (*score_fields, *extra), "score blocks/" + group)
        compare_table(a, tables[f"paired_{group}_values"], pvalues, (*pair_fields, *extra), "paired blocks/" + group)
        compare_table(a, tables[f"paired_{group}_summary"], pblocks, pair_fields, "paired block sign summary/" + group)
        nblocks = {"question": 24, "setting": 6, "stratum": 4, "family": 3}[group]
        a.check(all(r["n"] == nblocks for r in pblocks), "expected block count/" + group)
    a.section("weighted NLL decomposition, outcomes and measurement agreement")
    expected_nll = []
    for observer in (*OBSERVERS, "ab_mean"):
        for algorithm in ALGORITHMS:
            rows = [r for r in expected_wide.values() if r["predictor"] == algorithm and
                    (observer == "ab_mean" or r["observer"] == observer)]
            n, nd = len(rows), sum(r["direct_event"] for r in rows)
            cat = mean(r["categorical_nll"] for r in rows)
            gate = mean(r["gate_nll"] for r in rows)
            total_conditional = math.fsum(r["composition_nll_contribution"] for r in rows)
            contribution = total_conditional/n
            expected_nll.append({"observer": observer, "predictor": algorithm, "n_targets":288,
                "n_label_records":n, "n_direct_labels":nd, "direct_fraction":nd/n,
                "categorical_nll_mean":cat, "gate_nll_mean":gate, "composition_nll_contribution_mean":contribution,
                "conditional_composition_nll_mean":total_conditional/nd if nd else None,
                "identity_residual":cat-gate-contribution,
                "maximum_per_sample_identity_residual":max(abs(r["categorical_nll"]-r["gate_nll"]-r["composition_nll_contribution"]) for r in rows)})
    compare_table(a, tables["nll_decomposition"], expected_nll, ("observer","predictor"), "NLL decomposition table")
    expected_outcomes = []
    for observer in OBSERVERS:
        groups = {("global", "all"): list(samples)}
        for group, fields in GROUP_FIELDS.items():
            for sample in samples:
                key = group, "|".join(str(sample[field]) for field in fields)
                groups.setdefault(key, []).append(sample)
        for (group, group_id), rows in groups.items():
            cats = Counter(category(labels[observer][r["sample_id"]]) for r in rows)
            expected_outcomes.append({"observer":observer, "group":group, "group_id":group_id, "n":len(rows),
                "n_direct":len(rows)-cats["no_direct"], "n_strict_event":sum(strict_event(labels[observer][r["sample_id"]]) for r in rows),
                **{"n_"+cat:cats[cat] for cat in CATEGORIES},
                "n_eos":sum(r["stop_reason"]=="eos" for r in rows), "n_length":sum(r["stop_reason"]=="length" for r in rows)})
    compare_table(a, tables["outcome_counts"], expected_outcomes, ("observer","group","group_id"), "outcome counts")
    expected_agreement = []
    for sample in samples:
        first, second = (labels[o][sample["sample_id"]] for o in OBSERVERS)
        ca, cb = category(first), category(second)
        da, db = ca != "no_direct", cb != "no_direct"
        ea, eb = strict_event(first), strict_event(second)
        expected_agreement.append({**{f:sample[f] for f in META},
            "category_a":ca, "category_b":cb, "category_agrees":ca==cb,
            "direct_event_a":da, "direct_event_b":db, "direct_event_agrees":da==db,
            "strict_event_a":ea, "strict_event_b":eb, "strict_event_agrees":ea==eb,
            "six_codes_agree":code(first)==code(second)})
    disagreements = [r for r in expected_agreement if not r["six_codes_agree"]]
    compare_table(a, tables["observer_agreement"], expected_agreement, ("sample_id",), "every-output agreement")
    compare_table(a, tables["observer_disagreements"], disagreements, ("sample_id",), "all disagreements retained")
    agreement = a.read_json("results/agreement_summary.json")
    expected_agreement_summary = {"n_targets":288, "same_foundation_model_and_rubric":True, "independent_model_replications":False}
    for field in ("category_agrees","direct_event_agrees","strict_event_agrees","six_codes_agree"):
        count = sum(r[field] for r in expected_agreement)
        expected_agreement_summary[field] = {"n":count, "fraction":count/288}
    expected_agreement_summary["category_confusion_matrix"] = [[sum(r["category_a"]==ca and r["category_b"]==cb for r in expected_agreement) for cb in CATEGORIES] for ca in CATEGORIES]
    expected_agreement_summary["category_order"] = list(CATEGORIES)
    for event in ("direct_event","strict_event"):
        counts = Counter((r[event+"_a"],r[event+"_b"]) for r in expected_agreement)
        expected_agreement_summary[event+"_counts"] = {"both_positive":counts[True,True],
            "a_only":counts[True,False], "b_only":counts[False,True], "both_negative":counts[False,False]}
    a.equal(agreement, expected_agreement_summary, "full agreement summary")
    criterion = a.read_json("results/primary_criterion.json")
    primary_values = [r for r in pair_summary if r["co_primary"]]
    a.equal(len(primary_values), 6, "co-primary endpoints only two Brier contrasts")
    numeric_sign = {-1:"negative", 0:"zero", 1:"positive"}
    wanted_values = {r["observer"]+":"+r["contrast"]:{"difference":r["mean"], "sign":numeric_sign[sign(r["mean"])]} for r in primary_values}
    a.equal(set(criterion["values"]), set(wanted_values), "co-primary branch inventory")
    for key, value in wanted_values.items():
        compare_record(a, criterion["values"][key], value, "co-primary reported difference/" + key)
    avg_signs = [sign(r["mean"]) for r in primary_values if r["observer"]=="ab_mean"]
    branch_signs = [sign(r["mean"]) for r in primary_values if r["observer"]!="ab_mean"]
    a.equal(criterion["descriptive_pilot_support"], all(s==-1 for s in avg_signs), "co-primary descriptive criterion")
    a.equal(criterion["all_four_branch_comparison_signs_agree"], len(set(branch_signs))==1, "branch signs agree criterion")
    a.equal(criterion["all_four_branch_comparisons_negative"], all(s==-1 for s in branch_signs), "all four negative criterion")
    a.equal(criterion["significance_claim"], False, "no inferential significance claim")
    a.equal(criterion["population_confidence_intervals"], False, "no population confidence claim")
    a.section("canonical CSV mirrors and final scoring lock")
    verify_csv_mirror(a, "results/per_sample_scores.csv", wide)
    verify_csv_mirror(a, "results/paired_differences.csv", paired)
    for name, rows in tables.items():
        verify_csv_mirror(a, "results/"+name+".csv", rows)
    integrity = a.read_json("results/scoring_integrity.json")
    score_lock = a.read_json("results/score_lock.json")
    a.equal(integrity["status"], "ALL_MATCH", "scoring integrity status")
    a.equal(integrity["input_hashes"], score_lock["input_hashes"], "scoring input inventory consistent")
    original_target_meta = a.read_json("metadata/target.json")
    expected_score_inputs = set(original_target_meta["frozen_source_hashes"]) | {
        "metadata/target.json", "metadata/target_attempt.json", "metadata/target_events.jsonl",
        "data/target_generations.jsonl", "source_snapshots/target/SNAPSHOT_MANIFEST.json", "observer_exports/target.json"}
    for observer in OBSERVERS:
        expected_score_inputs.update(f"observers/target/{observer}/{name}" for name in (*LOCK_FILES.values(), "observation_lock.json"))
    a.equal(set(score_lock["input_hashes"]), expected_score_inputs, "complete scoring input inventory")
    a.hash_mapping(score_lock["input_hashes"], "scoring locked input hashes")
    a.hash_mapping(score_lock["output_hashes"], "scoring locked output hashes")
    expected_output_paths = {"results/"+p for p in ("per_sample_scores.jsonl","scalar_scores.jsonl","paired_differences.jsonl",
        "per_sample_scores.csv","paired_differences.csv","tables.json","agreement_summary.json","primary_criterion.json","scoring_integrity.json")}
    expected_output_paths.update("results/"+name+".csv" for name in tables)
    a.equal(set(score_lock["output_hashes"]), expected_output_paths, "scoring complete output inventory")
    for field, expected in (("target_samples",288),("forecast_rows",4032),("per_sample_score_rows",4608),
                            ("scalar_score_rows",19008),("paired_difference_rows",19584),("generation_attempts",1)):
        a.equal(integrity[field], expected, "scoring inventory/" + field)
    for field in ("every_plan_field_preserved","all_length_stops_retained","all_no_direct_retained"):
        a.equal(integrity[field], True, "scoring retention/" + field)
    for field in ("observation_adjudication_performed","selection_refitted_on_targets","retry_or_resume_performed"):
        a.equal(integrity[field], False, "scoring no adaptation/" + field)
    for observer in OBSERVERS:
        a.equal(integrity["observation_locked_utc"][observer], observation_locks[observer]["locked_utc"], "scoring annotation timestamp/" + observer)
        a.check(parse_time(observation_locks[observer]["locked_utc"]) <= parse_time(integrity["scored_utc"]), "labels locked before scoring/" + observer)
    a.check(parse_time(integrity["scored_utc"]) <= parse_time(score_lock["locked_utc"]), "score lock after computation")
    recorded_times = {"design_locked_utc":a.read_json("design_lock.json")["locked_utc"],
        "forecast_locked_utc":a.read_json("predictions/forecast_lock.json")["locked_utc"],
        "forecast_audited_utc":a.read_json("audits/forecast.json")["audited_utc"],
        "attempt_started_utc":a.read_json("metadata/target_attempt.json")["created_utc"],
        "inference_started_utc":original_target_meta["inference_started_utc"],
        "generation_completed_utc":original_target_meta["completed_utc"],
        "event_log_completed_utc":a.read_rows("metadata/target_events.jsonl")[-1]["utc"]}
    for field, timestamp in recorded_times.items():
        a.equal(integrity[field], timestamp, "scoring chronology copied correctly/" + field)
    for field, relative in (("design_lock_sha256","design_lock.json"),("forecast_lock_sha256","predictions/forecast_lock.json")):
        a.equal(score_lock[field], a.digest(relative), "scoring original prediction lock/" + field)
    a.facts.update(per_sample_score_rows=4608, scalar_score_rows=19008, paired_difference_rows=19584,
        same_foundation_model_observer_branches=True, independent_model_replications=False,
        category_agreement=expected_agreement_summary["category_agrees"],
        direct_event_agreement=expected_agreement_summary["direct_event_agrees"],
        strict_event_agreement=expected_agreement_summary["strict_event_agrees"],
        descriptive_pilot_support=criterion["descriptive_pilot_support"],
        primary_comparisons=criterion["values"], score_lock_sha256=a.digest("results/score_lock.json"))


def run(stage):
    a = Audit(stage)
    try:
        a.digest("audit_shrinkage.py")
        synthetic_checks(a)
        if stage != "synthetic":
            dev, labels, old_questions, old_seeds, old_manifest = audit_source_and_development(a)
            _, settings, _, plan, tokenizer = audit_configuration_and_plan(a, old_questions, old_seeds, old_manifest)
            design_lock = audit_design_integrity(a, locked=stage != "design")
            if stage in {"forecasts", "final"}:
                forecast_lock, expected_forecasts = audit_forecast_artifacts(a, dev, labels, settings, plan, design_lock)
                if stage == "final":
                    samples, target_labels, observation_locks = audit_generation_and_observation(a, plan, tokenizer, design_lock, forecast_lock)
                    audit_scoring(a, samples, target_labels, observation_locks, expected_forecasts)
        a.check(a.digest("audit_shrinkage.py") == a.input_hashes["audit_shrinkage.py"], "auditor source stable")
    except Exception as error:
        a.check(False, "audit execution exception", {"type":type(error).__name__, "message":str(error),
                "traceback":traceback.format_exc()})
    return a.report()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", nargs="?", choices=("synthetic", "design", "forecasts", "final"))
    parser.add_argument("--stage", dest="stage_option", choices=("synthetic", "design", "forecasts", "final"))
    parser.add_argument("--output", help="Exclusive project-relative report path under audits/ or setup/.")
    args = parser.parse_args()
    stage = args.stage_option or args.stage
    if not stage or (args.stage_option and args.stage and args.stage_option != args.stage):
        parser.error("Choose exactly one audit stage.")
    defaults = {"synthetic":"setup/audit_synthetic_checks.json", "design":"audits/design_prelock.json",
                "forecasts":"audits/forecast.json", "final":"audits/final.json"}
    path = Path(args.output or defaults[stage])
    if path.is_absolute() or ".." in path.parts or path.parts[0] not in {"audits","setup"}:
        parser.error("Report path must remain inside audits/ or setup/.")
    destination = ROOT / path
    if destination.exists():
        raise SystemExit("Existing audit report preserved; choose another explicit output path.")
    result = run(stage)
    if result["status"] != "ALL_MATCH" and not args.output:
        suffix = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        destination = destination.with_name(destination.stem + "_FAILED_" + suffix + ".json")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status":result["status"],"stage":stage,"assertions":result["assertions"],
        "failure_count":result["failure_count"],"failures":result["failures"],
        "report":destination.relative_to(ROOT).as_posix()},ensure_ascii=False,indent=2))
    if result["status"] != "ALL_MATCH":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
