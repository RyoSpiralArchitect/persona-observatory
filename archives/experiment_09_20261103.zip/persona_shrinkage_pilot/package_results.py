#!/usr/bin/env python3
"""Package the completed, audited study without weights, environment or caches."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import zipfile

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent/'artifacts'
SKIP_DIRS={'.venv','.cache','__pycache__','model','unexpected_download_temporaries'}


def sha(data):return hashlib.sha256(data).hexdigest()


def main():
    audit=json.loads((ROOT/'audits/final.json').read_text())
    assert audit['status']=='ALL_MATCH' and audit['failures']==[]
    for name in ['design_lock.json','predictions/forecast_lock.json','results/score_lock.json']:
        lock=json.loads((ROOT/name).read_text())
        for key in ['input_hashes','output_hashes']:
            for rel,digest in lock.get(key,{}).items():
                assert sha((ROOT/rel).read_bytes())==digest, rel
    assert (ROOT/'REPORT_JA.md').is_file()
    assert (ROOT/'report_build.json').is_file()
    files=[]
    for parent,dirs,names in os.walk(ROOT):
        dirs[:]=sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith('.'))
        for name in sorted(names):
            if name.startswith('.') or name.endswith(('.pyc','.part')) or name=='FILE_MANIFEST.json':continue
            p=Path(parent)/name
            assert not p.is_symlink(), 'No symlinks in the deliverable'
            rel=p.relative_to(ROOT).as_posix()
            data=p.read_bytes()
            assert len(data)<100_000_000, 'Unexpected oversized artifact: '+rel
            files.append({'path':rel,'bytes':len(data),'sha256':sha(data)})
    files.sort(key=lambda v:v['path'])
    manifest=ROOT/'FILE_MANIFEST.json'
    with manifest.open('x') as f:json.dump(files,f,ensure_ascii=False,indent=2);f.write('\n')
    OUT.mkdir(exist_ok=True)
    zip_path=OUT/'persona_shrinkage_pilot_20261103.zip'
    assert not zip_path.exists()
    with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for entry in files:
            z.write(ROOT/entry['path'],ROOT.name+'/'+entry['path'])
        z.write(manifest,ROOT.name+'/FILE_MANIFEST.json')
    with zipfile.ZipFile(zip_path) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(files)+1
        assert json.loads(z.read(ROOT.name+'/FILE_MANIFEST.json'))==files
        for entry in files:
            data=z.read(ROOT.name+'/'+entry['path'])
            assert len(data)==entry['bytes'] and sha(data)==entry['sha256']
    for rel in ['persona_shrinkage_report_20261103.html','figures/persona_shrinkage_summary_20261103.png']:
        source=ROOT/rel;dest=OUT/source.name
        assert not dest.exists();shutil.copyfile(source,dest)
        assert sha(source.read_bytes())==sha(dest.read_bytes())
    print(json.dumps({'status':'PACKAGE_VERIFIED','archive_files':len(files)+1,
        'files':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
                 for p in [OUT/'persona_shrinkage_report_20261103.html',zip_path,OUT/'persona_shrinkage_summary_20261103.png']]},indent=2))


if __name__=='__main__':main()
